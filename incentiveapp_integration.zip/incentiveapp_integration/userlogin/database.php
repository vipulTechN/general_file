<?php include('htmlopen.php'); ?>
<?php include('header.php'); ?>
<!-- Main Content -->
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="table-container">
          <table id="example" class="stripe row-border order-column display" cellspacing="0" style="width:100%">
            <thead class="maintheading">
              <tr>
                <th>ID</th>
                <th>Booking Date</th>
                <th>Month</th>
                <th>Builder</th>
                <th>Project</th>
                <th>Customer Name.</th>
                <th>Contact No.</th>
                <th>Email Id</th>
                <th>Type</th>
                <th>Unit No.</th>
                <th>Size</th>
                <th>Agreement Value</th>
                <th>Commission %</th>
                <th>Total Revenue</th>
                <th>CashBack %</th>
                <th>Actual Revenue</th>
                <th>Status</th>
                <th>Received Amt.</th>
                <th>Sales Person</th>
                <th>Action</th>
              </tr>
            </thead>
            <thead class="scndhead">
              <tr class="group-header">
                <td colspan="20">
                  <div class="wrappsps d-flex justify-content-start">
                    <div class="border border-dark d-inline p-2 bg-warning text-dark font-weight-bold">Financial
                      Year/Bookings: 2023-2024/(15)</div>
                    <div class="border border-dark d-inline p-2 bg-primary text-white font-weight-bold">Total
                      Revenue: ₹ 35406666</div>
                    <div class="border border-dark d-inline p-2 bg-info text-white font-weight-bold">Actual Revenue:
                      ₹ 28292188</div>
                    <div class="border border-dark d-inline p-2 bg-primary text-white font-weight-bold">Remaning
                      Revenue: ₹ 0</div>
                    <div class="border border-dark d-inline p-2 bg-success text-white font-weight-bold">Recived
                      Amount: ₹ 28292188</div>
                    <div class="border border-dark d-inline p-2 bg-secondary text-white font-weight-bold">Amount To
                      be Pay: ₹ 2107215</div>
                    <div class="border border-dark d-inline p-2 bg-info text-white font-weight-bold">Total Paid Amt:
                      ₹ 2107213</div>
                  </div>
                </td>
              </tr>
            </thead>
            <tbody id="pagedataaas">
              <tr>
                <td>1</td>
                <td>2024-03-09</td>
                <td>March</td>
                <td>ABC Builders</td>
                <td>Project XYZ</td>
                <td>John Doe</td>
                <td>1234567890</td>
                <td>john.doe@example.com</td>
                <td>Residential</td>
                <td>101</td>
                <td>1200 sqft</td>
                <td>$200,000</td>
                <td>5%</td>
                <td>$10,000</td>
                <td>2%</td>
                <td>$9,800</td>
                <td>
                  <p class="status delivered">Processed</p>
                </td>
                <td>$5,000</td>
                <td>Jane Doe</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>2</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>
                  <p class="status cancelled">Cancelled</p>
                </td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>3</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>poiu Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>4</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>qwe Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>5</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>asd Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>6</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>lkjh Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>7</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>cv Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>8</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>9</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>10</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>11</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>12</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>13</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>14</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>dfgh Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>15</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>mn Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>16</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>qas Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>17</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jacxvne Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>18</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>JZxcane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>19</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jafdsne Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>20</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>bnb Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>21</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>vbv Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>22</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>vcbane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>23</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>bgtJane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>24</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>eeJane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>25</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>ccJane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>26</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>ssJane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>27</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jxcane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>28</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane cSmith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>29</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smfgith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>30</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane fmith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <th>ID</th>
              <th>Booking Date</th>
              <th>Month</th>
              <th>Builder</th>
              <th>Project</th>
              <th>Customer Name.</th>
              <th>Contact No.</th>
              <th>Email Id</th>
              <th>Type</th>
              <th>Unit No.</th>
              <th>Size</th>
              <th>Agreement Value</th>
              <th>Commission %</th>
              <th>Total Revenue</th>
              <th>CashBack %</th>
              <th>Actual Revenue</th>
              <th>Status</th>
              <th>Received Amt.</th>
              <th>Sales Person</th>
              <th>Action</th>
            </tfoot>
          </table>
          <button id="scroll-left"><i class='bx bx-left-arrow-alt'></i></button>
          <button id="scroll-right"><i class='bx bx-right-arrow-alt'></i></button>
        </div>
      </div>
    </div>
  </div>
</div>
<!--End Main Content -->

<?php include('htmlclose.php'); ?>