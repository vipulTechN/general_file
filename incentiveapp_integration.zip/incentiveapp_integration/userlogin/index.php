<?php include('htmlopen.php'); ?>

<?php include('header.php'); ?>
<!-- Main Content -->
<div class="content">
  <div class="container">
    <div class="row">

    <div class="col-lg-6 chart-col-lg">
        <div class="custom-select mb-2" >
          <select>
            <option value="">Open this select menu</option>
            <option value="">2022</option>
            <option value="">2023</option>
            <option value="">2024</option>
          </select>
        </div>
        <div class="chartcmmnstyle" id="barchart_material"></div>
      </div>
      
      <div class="col-lg-6 chart-col-lg">
      <div class="custom-select mb-2">
          <select>
            <option value="">Open this select menu</option>
            <option value="">2022</option>
            <option value="">2023</option>
            <option value="">2024</option>
          </select>
        </div>
        <div class="chartcmmnstyle" id="chart_line"></div>
      </div>
      
    </div>
    <div class="row  mt-3">
      <div class="col-lg-12 indexbooktable">
        <h4>Booking Status</h4>
        <a href="/user/database.php">
          <div class="panel-body">
            <table id="example" class="display" style="width:100%">
              <thead class="maintheading">
                <tr class="filters">
                  <th>ID</th>
                  <th>Booking Date</th>
                  <th>Month</th>
                  <th>Builder</th>
                  <th>Project</th>
                  <th>Customer Name.</th>
                  <th>Contact No.</th>
                  <th>Email Id</th>
                  <th>Type</th>
                  <th>Unit No.</th>
                  <th>Size</th>
                  <th>Agreement Value</th>
                  <th>Commission %</th>
                  <th>Total Revenue</th>
                  <th>CashBack %</th>
                  <th>Actual Revenue</th>
                  <th>Status</th>
                  <th>Received Amt.</th>
                  <th>Sales Person</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody id="pagedata">

                <tr data-status="Received">
                  <td>1</td>
                  <td>2024-03-09</td>
                  <td>March</td>
                  <td>ABC Builders</td>
                  <td>Project XYZ</td>
                  <td>John Doe</td>
                  <td>1234567890</td>
                  <td>john.doe@example.com</td>
                  <td>Residential</td>
                  <td>101</td>
                  <td>1200 sqft</td>
                  <td>$200,000</td>
                  <td>5%</td>
                  <td>$10,000</td>
                  <td>2%</td>
                  <td>$9,800</td>
                  <td>
                    <p class="status delivered">Processed</p>
                  </td>
                  <td>$5,000</td>
                  <td>Jane Doe</td>
                  <td>
                    <ul class="tableul">
                      <li class="tableli">
                        <i class="bi bi-cloud-arrow-down-fill"></i>
                      </li>
                      <li class="tableli">
                        <i class="bi bi-trash-fill"></i>
                      </li>
                      <li class="tableli" data-toggle="modal" data-target="#editUserModal">
                        <i class="bi bi-clipboard-check-fill"></i>
                      </li>
                    </ul>
                  </td>
                </tr>
                <tr data-status="Received">
                  <td>2</td>
                  <td>2024-03-10</td>
                  <td>April</td>
                  <td>XYZ Developers</td>
                  <td>Project ABC</td>
                  <td>Jane Smith</td>
                  <td>9876543210</td>
                  <td>jane.smith@example.com</td>
                  <td>Commercial</td>
                  <td>202</td>
                  <td>1500 sqft</td>
                  <td>$300,000</td>
                  <td>7%</td>
                  <td>$21,000</td>
                  <td>3%</td>
                  <td>$20,400</td>
                  <td>
                    <p class="status cancelled">Cancelled</p>
                  </td>
                  <td>$15,000</td>
                  <td>John smith</td>
                  <td>
                    <ul class="tableul">
                      <li class="tableli">
                        <i class="bi bi-cloud-arrow-down-fill"></i>
                      </li>
                      <li class="tableli">
                        <i class="bi bi-trash-fill"></i>
                      </li>
                      <li class="tableli">
                        <i class="bi bi-clipboard-check-fill"></i>
                      </li>
                    </ul>
                  </td>
                </tr>
                <tr data-status="Received">
                  <td>3</td>
                  <td>2024-03-10</td>
                  <td>April</td>
                  <td>XYZ Developers</td>
                  <td>Project ABC</td>
                  <td>poiu Smith</td>
                  <td>9876543210</td>
                  <td>jane.smith@example.com</td>
                  <td>Commercial</td>
                  <td>202</td>
                  <td>1500 sqft</td>
                  <td>$300,000</td>
                  <td>7%</td>
                  <td>$21,000</td>
                  <td>3%</td>
                  <td>$20,400</td>
                  <td>Inactive</td>
                  <td>$15,000</td>
                  <td>John smith</td>
                  <td>
                    <ul class="tableul">
                      <li class="tableli">
                        <i class="bi bi-cloud-arrow-down-fill"></i>
                      </li>
                      <li class="tableli">
                        <i class="bi bi-trash-fill"></i>
                      </li>
                      <li class="tableli">
                        <i class="bi bi-clipboard-check-fill"></i>
                      </li>
                    </ul>
                  </td>
                </tr>
                <tr data-status="Received">
                  <td>4</td>
                  <td>2024-03-10</td>
                  <td>April</td>
                  <td>XYZ Developers</td>
                  <td>Project ABC</td>
                  <td>qwe Smith</td>
                  <td>9876543210</td>
                  <td>jane.smith@example.com</td>
                  <td>Commercial</td>
                  <td>202</td>
                  <td>1500 sqft</td>
                  <td>$300,000</td>
                  <td>7%</td>
                  <td>$21,000</td>
                  <td>3%</td>
                  <td>$20,400</td>
                  <td>Inactive</td>
                  <td>$15,000</td>
                  <td>John smith</td>
                  <td>
                    <ul class="tableul">
                      <li class="tableli">
                        <i class="bi bi-cloud-arrow-down-fill"></i>
                      </li>
                      <li class="tableli">
                        <i class="bi bi-trash-fill"></i>
                      </li>
                      <li class="tableli">
                        <i class="bi bi-clipboard-check-fill"></i>
                      </li>
                    </ul>
                  </td>
                </tr>
                <tr data-status="Received">
                  <td>5</td>
                  <td>2024-03-10</td>
                  <td>April</td>
                  <td>XYZ Developers</td>
                  <td>Project ABC</td>
                  <td>asd Smith</td>
                  <td>9876543210</td>
                  <td>jane.smith@example.com</td>
                  <td>Commercial</td>
                  <td>202</td>
                  <td>1500 sqft</td>
                  <td>$300,000</td>
                  <td>7%</td>
                  <td>$21,000</td>
                  <td>3%</td>
                  <td>$20,400</td>
                  <td>Inactive</td>
                  <td>$15,000</td>
                  <td>John smith</td>
                  <td>
                    <ul class="tableul">
                      <li class="tableli">
                        <i class="bi bi-cloud-arrow-down-fill"></i>
                      </li>
                      <li class="tableli">
                        <i class="bi bi-trash-fill"></i>
                      </li>
                      <li class="tableli">
                        <i class="bi bi-clipboard-check-fill"></i>
                      </li>
                    </ul>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </a>
      </div>
    </div>
  </div>
 
</div>
<!--End Main Content -->
<script src="../assets/js/chartloader.js"></script>
<script src=".//js/chart.js"></script>
<?php include('htmlclose.php'); ?>