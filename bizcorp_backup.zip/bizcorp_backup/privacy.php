<?php include 'header.php';?>
		
		<!-- Breadcrumbs -->
		<div class="breadcrumbs overlay aboutus">
			<div class="container">
				<div class="bread-inner">
					<div class="row">
						<div class="col-12">
							<h2>Privacy Policy</h2>
							<ul class="bread-list">
								<li><a href="index.php">Home</a></li>
								<li><i class="icofont-simple-right"></i></li>
								<li class="active">Privacy Policy</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Breadcrumbs -->
		<!-- Single News -->
		<section class="news-single section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-12">
						<div class="row">
							<div class="col-12">
								<div class="single-main">
									<div class="news-text">
									 <h6><b> Effective Date: 26-11-2024 </b> </h6>
                                     <br>
                                     <p class="text-justify">
                                        BizCropGlobal is committed to protecting your privacy and ensuring your personal information is handled responsibly. This Privacy Policy outlines how we collect, use, and safeguard your information when you interact with our websites, blogs, social media platforms, or apps (collectively, the “Sites”).
                                        <br><br>
                                        By accessing or using our Sites, you consent to the practices described in this Privacy Policy. If you do not agree, please do not provide any personal information or interact with the Sites.
                                    </p>
                                    <h6><b> Information We Collect </b></h6>
                                    <br>
                                    <p class="text-justify">
                                        We collect information to enhance your experience and provide you with tailored services.
                                    </p>
                                    <h6 class="mb-2">Categories of Information Collected</h6>
                                    <ul>
                                        <li class="mb-2">
                                           <b> 1. Personal Information Provided by You</b>
                                            <ul class="mt-2">
                                                <li>  Name, email address, mailing address, phone number.</li>
                                                <li>Payment details (e.g., credit card information) and business information for service transactions.</li>
                                                <li>Information is submitted via forms, live chat, support tickets, surveys, or registration.</li>
                                            </ul>
                                        </li>
                                        <li class="mb-2">
                                            <b>2. Automatically Collected Information</b>
                                            <ul class="mt-2">
                                                <li>IP address, browser type, device type, and operating system.</li>
                                                <li>Pages viewed, links clicked, and time spent on our Sites.</li>
                                                <li>Referring to websites or links.</li>
                                            </ul>
                                        </li>
                                        <li class="mb-2">
                                            <b>3. Public Information</b>
                                            <ul class="mt-2">
                                                <li>Information available in public records or published by government entities.</li>
                                            </ul>
                                        </li>
                                    </ul>
                                    <br>
                                    <h6><b> How We Use Your Information </b></h6>
                                    <br>
                                    <ul>
                                        <li class="mb-2">
                                           <b>We use the collected information to:</b>
                                            <ul class="mt-2">
                                              <li>a. Personalize your experience and deliver relevant content.</li>
                                              <li>b. Improve our Sites, products, and services.</li>
                                              <li>c. Process transactions and deliver services.</li>
                                              <li>d. Respond to inquiries, reviews, or customer service requests.</li>
                                              <li>e. Administer promotions, surveys, or other features.</li>
                                              <li>f. Comply with legal obligations or protect our rights.</li>
                                            </ul>
                                        </li>
                                    </ul>
                                    <br>
                                    <h6><b>Information Sharing and Disclosure</b></h6>
                                    <br>
                                    <ul>
                                        <li class="mb-2">
                                           <b>We do not sell or trade your personally identifiable information. However, we may share it in the following cases:</b>
                                            <ul class="mt-2 mb-2">
                                              <li>a. To fulfil service requests.</li>
                                              <li>b. With trusted partners, such as payment processors, who agree to maintain confidentiality.</li>
                                              <li>c. To comply with legal obligations, court orders, or legal processes.</li>
                                              <li>d. In connection with business transfers (e.g., mergers or acquisitions).</li>
                                            </ul>
                                            <b>We also share non-personally identifiable information with third parties for analytics, marketing, or other purposes.</b>
                                        </li>
                                    </ul>
                                    <br>
                                    <h6><b>Cookies and Web Beacons</b></h6>
                                    <br>
                                    <ul>
                                        <li class="mb-2">
                                            <b>We use cookies to:</b>
                                            <ul class="mt-2 mb-2">
                                              <li>a. Recognize your browser and remember your preferences.</li>
                                              <li>b. Track site activity to improve functionality.</li>
                                              <li>c. Compile aggregate data for analytics.</li>
                                            </ul>
                                            <p>You can adjust cookie settings in your browser. However, disabling cookies may affect your site experience.
                                            <br>
                                              We also use web beacons in emails or on our Sites to measure engagement and effectiveness.</p>
                                        </li>
                                    </ul>
                                    <br>
                                    <h6><b>Security Measures</b></h6>
                                    <br>
                                    <ul>
                                        <li class="mb-2">
                                           <b>We implement industry-standard security practices to protect your information, including:</b>
                                            <ul class="mt-2 mb-2">
                                              <li>a. Data encryption via Secure Socket Layer (SSL) technology.</li>
                                              <li>b. Secure networks with limited access to authorized personnel.</li>
                                              <li>c. Regular malware scans.</li>
                                            </ul>
                                            <b>All payment transactions are processed through PCI-compliant gateways and are not stored on our servers.</b>
                                        </li>
                                    </ul>
                                    <br>
                                    <h6><b>Your Rights</b></h6>
                                    <br>
                                    <p>You may review, update, or delete your personal information by logging into your account or contacting us at <a href="" style="text-decoration: underline; color: blue;">xyz@BizCropGlobal.com.</a></p>
                                    <br>
                                    <h6><b>Third-Party Links and Policies</b></h6>
                                    <br>
                                    <p>Our Sites may link to third-party websites with their privacy policies. We are not responsible for the practices of these third parties.</p>
                                    <br>
                                    <h6><b>Legal Compliance</b></h6>
                                    <br>
                                    <ul>
                                        <li class="mb-2">
                                           <b>We comply with applicable laws, including:</b>
                                            <ul class="mt-2 mb-2">
                                              <li>a. California Online Privacy Protection Act (CalOPPA).</li>
                                              <li>b. Children’s Online Privacy Protection Act (COPPA).</li>
                                              <li>c. CAN-SPAM Act.</li>
                                            </ul>
                                        </li>
                                    </ul>
                                    <br>
                                    <h6><b>Dispute Resolution</b></h6>
                                    <p>All disputes arising from this Privacy Policy or your use of our Sites will be resolved through binding arbitration by the Judicial Arbitration and Mediation Service (JAMS), as per their rules. You waive the right to file lawsuits or participate in class actions unless prohibited by law.</p>
                                    <br>
                                    <h6><b>Legal Compliance</b></h6>
                                    <p>Our liability to you is limited to the total payments you made to us in the 12 months before a claim arose.</p>                                
                                    <br>
                                    <h6><b>Contact Us</b></h6>
                                    <br>
                                    <ul>
                                        <li class="mb-2">
                                           <b>For any questions regarding this Privacy Policy, contact us at:</b>
                                            <ul class="mt-2 mb-2">
                                              <li><h6>BizCropGlobal</h6></li>
                                              <li><h6>Email: <a href="" style="text-decoration: underline; color: blue;">xyz@BizCropGlobal.com.</a></h6></li>
                                              <li><h6>Address : Lorem ipsum dolor sit.</h6></li>
                                            </ul>
                                        </li>
                                    </ul>
                                    <br>
                                    <p> <b> Thank You for Choosing BizCropGlobal </b><br>
                                        We appreciate your trust in BizCropGlobal and remain committed to providing exceptional service. Our motto is to support your business with the same passion and dedication that can bring to your endeavours.
                                        <br><br> If you have any questions or need further assistance, please feel free to call us .
                                        <br><br> Warm regards,
                                        <br>
                                       <b>The BizCropGlobal Team </b>
                                    </p>
                                </div>
									<div class="blog-bottom mt-5">
										<ul class="social-share">
											<li class="facebook"><a href="#"><i class="fa fa-facebook"></i><span>Facebook</span></a></li>
											<li class="twitter"><a href="#"><i class="fa fa-twitter"></i><span>Twitter</span></a></li>
											<li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
											<li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
											<li class="pinterest"><a href="#"><i class="fa fa-pinterest"></i></a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Single News -->
	<?php include 'footer.php';?>