function addButtonClickListener(containerId, buttonClass, activeClass) {
    var container = document.getElementById(containerId);
    var buttons = container.getElementsByClassName(buttonClass);
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].addEventListener("click", function() {
        var currentActive = document.getElementsByClassName(activeClass);
        for (var j = 0; j < currentActive.length; j++) {
          currentActive[j].classList.remove(activeClass);
        }
        this.classList.add(activeClass);
      });
    }
  }
  addButtonClickListener("mid1buttss", "obabutns", "active");
  addButtonClickListener("mid2buttss", "srlbutns", "actived");
