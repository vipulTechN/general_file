<?php 
if(isset($_POST['Submit'])){ 
      
    $from = $_POST['email']; // this is the sender's Email address
    $name = $_POST['name'];
    $message ="";
    $property="";
    $email = $_POST['email'];
    $mobile = $_POST['phone'];
    $enquiry = $_POST['enquiry'];
    $propertieslist = $_POST['propertieslist'];
    $subject = " Assetz Properties Landing Page";
    $message = "Name : ".$name ."\n"."Email : ". $email ."\n" . "Mobile : ".$mobile."\n" ."property:" .$propertieslist ."\n"."Message: ".$enquiry."\n" . $_POST['message']."\n "."\n";
    $message .= "This email is coming from Assetz Properties Landing Page Form Submission";
     include_once("class.phpmailer.php");
         $mail = new PHPMailer();
         
         

         $mail->Priority = 1;
    $mail->From = $from;
    $mail->FromName = $name;
    $mail->Sender = $from;
    $mail->ReturnPath = $from;
    $mail->AddReplyTo($from, $from);
    // $mail->AddBCC("vipulmishra@searchhomesindia.com , vipulmishra@searchhomesindia.com");
    $mail->AddAddress("itsupport@searchhomesindia.com, itsupport@searchhomesindia.com");
    
    //$mail->AddBCC("digitalrakeshdasi@gmail.com, digitalrakeshdasi@gmail.com");
     //$mail->AddBCC("ganesh.smrholdings@gmail.com, ganesh.smrholdings@gmail.com");
    // $mail->AddBCC("nandithahema@gmail.com, nandithahema@gmail.com");
    // $mail->BCCAddress("digitalrakeshdasi@gmail.com");
     
         $mail->Body = $message;
         
             $mail->AltBody = "";
         $mail->Subject = $subject ;

                $sent =$mail->Send();
                
                            $fields = array(
    "sender_id" => "SHHOME",
    "message" => "Property-.$propertieslist. , Mobile-.$mobile., Email- .$email. 
Regards, SearchHomes india pvt ltd ",
    "template_id" => "1207163731895114985",
    "entity_id" => "1201159178483176795",
    "route" => "dlt_manual",
    "numbers" => "8951927450",
);
// ,8638868550,6264159415,
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($fields),
  CURLOPT_HTTPHEADER => array(
    "authorization: 4MCYHbX8d52ezAPFJfWkpmwair7GuvQxUcBDgNhO103SloyKZtkCfwsc2DARNTzFMOHViW6u8yeBplPj",
    "accept: */*",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
    
					?>
						<script>
							window.location.href='thank_you.php';
						</script>
					<?php
    }
?>