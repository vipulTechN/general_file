<?php include('htmlopen.php'); ?>
<?php include('header.php'); ?>
<!-- Main Content -->
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="table-container">
          <table id="example" class="stripe row-border order-column display" cellspacing="0" style="width:100%">
            <thead>
              <tr>
                <th>ID</th>
                <th>Facebook Exp.</th>
                <th>Google Exp.</th>
                <th>Hr Exp.</th>
                <th>Accountant Exp.</th>
                <th>IT Exp.</th>
                <th>Total Exp.</th>
              </tr>
            </thead>
            <tbody id="expenses">
              <tr>
                <td>1</td>
                <td>130000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>7600000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>150000</td>
                <td>6500000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1020</td>
                <td>3200460</td>
              </tr>
              <tr>
                <td>3</td>
                <td>1530</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>32876000</td>
              </tr>
              <tr>
                <td>4</td>
                <td>150000</td>
                <td>3009800</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3202300</td>
              </tr>
              <tr>
                <td>5</td>
                <td>150000</td>
                <td>30065400</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>320340</td>
              </tr>
              <td>6</td>
              <td>150000</td>
              <td>3000000</td>
              <td>10000</td>
              <td>21000</td>
              <td>1000</td>
              <td>3200000</td>
              </tr>
              <tr>
                <td>7</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
              </tr>
              <tr>
                <td>8</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
              </tr>
              <tr>
                <td>9</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
              </tr>
              <tr>
                <td>10</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
              </tr>
              <tr>
                <td>11</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
              </tr>
              <tr>
                <td>12</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
              <tr>
                <td>13</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
              </tr>
              <tr>
                <td>14</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <td>ID</td>
                <td>Facebook Exp.</td>
                <td>Google Exp.</td>
                <td>Hr Exp.</td>
                <td>Accountant Exp.</td>
                <td>IT Exp.</td>
                <td>Total Exp.</td>
              </tr>
            </tfoot>
          </table>
          <button id="scroll-left"><i class='bx bx-left-arrow-alt'></i></button>
          <button id="scroll-right"><i class='bx bx-right-arrow-alt'></i></button>
        </div>
      </div>
    </div>
    <!-- Filter Rows Modal Start -->
    <div class="modal fade" tabindex="-1" id="filterModal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Filter Data</h5>
            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close" id="closeFilter"></button>
          </div>
          <div class="modal-body">
            <div class="container p-0">
              <div class="row">
                <!-- Filter inputs -->
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterID" placeholder="ID">
                  <input type="text" class="form-control mb-2" id="FacebookExp" placeholder="Facebook Expenses">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="GoogleExp" placeholder="Google Expenses">
                  <input type="text" class="form-control mb-2" id="HrExp" placeholder="Hr Expenses">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="AccountantExp" placeholder="Accountant Expenses">
                  <input type="text" class="form-control mb-2" id="ItExp" placeholder="It Expenses">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="TotalExp" placeholder="Total Expenses">
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <!-- Close Modal button -->
            <button type="button" class="btn btn-secondary" data-dismiss="modal" id="cancleFilter">Close</button>
            <!-- Clear Filters button -->
            <button type="button" class="btn btn-danger" id="clearFiltersBtn">Clear Filters</button>
            <!-- Apply Filters button -->
            <button type="button" class="btn btn-primary" id="applyFiltersBtn">Apply Filters</button>
          </div>
        </div>
      </div>
    </div>
    <!-- filter rows Modal End -->
  </div>
</div>
<!--End Main Content -->
<script>
  function applyFilters() {
    var filterInputs = [{
        id: "filterID",
        columnIndex: 0
      },
      {
        id: "FacebookExp",
        columnIndex: 1
      },
      {
        id: "GoogleExp",
        columnIndex: 2
      },
      {
        id: "HrExp",
        columnIndex: 3
      },
      {
        id: "AccountantExp",
        columnIndex: 4
      },
      {
        id: "ItExp",
        columnIndex: 5
      },
      {
        id: "TotalExp",
        columnIndex: 6
      },
    ];
    activeFilters = [];
    $("#expenses tr").each(function() {
      var row = $(this);
      var showRow = true;
      filterInputs.forEach(function(inputInfo) {
        var input = $("#" + inputInfo.id);
        var filterValue = input.val().toLowerCase();
        var cellValue = row.find("td:eq(" + inputInfo.columnIndex + ")").text().toLowerCase();
        if (cellValue.indexOf(filterValue) === -1) {
          showRow = false;
          return false;
        }
        if (filterValue.trim() !== "") {
          activeFilters.push(filterValue);
        }
      });
      if (showRow) {
        row.addClass("custom-filtered-row");
      } else {
        row.removeClass("custom-filtered-row");
      }
    });
    $("#expenses tr").hide();
    applyCustomFilter();
  };
  applyCustomFilter();

  function applyCustomFilter() {
    $(".custom-filtered-row").show();
  }
  $(".filterable .btn-filter1").click(function() {
    $("#filterModal").modal("show");
  });
  $("#applyFiltersBtn").click(function() {
    $("#filterModal").modal("hide");
    applyFilters();
  });
  $("#filterModal").on("hidden.bs.modal", function() {
    $(".filterable .filters input").val("");
    applyFilters();
  });
  $("#closeFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $("#cancleFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $(document).ready(function() {
    $("#clearFiltersBtn").click(function() {
      $("#filterID,#FacebookExp,#GoogleExp,#HrExp,#AccountantExp,#ItExp,#TotalExp").val("");
    });
  });
  $("#clearFiltersBtn").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
</script>
<?php include('htmlclose.php'); ?>
