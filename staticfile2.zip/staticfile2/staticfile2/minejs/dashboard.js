$(window).on('resize', function () {

  if ($(this).width() < 1600) {
    $('tr td:first-child').click(function () {

      $(this).siblings().css({ 'display': 'inline-block' });

      var $this = $(this);
      setTimeout(function () {
        $this.siblings().css('transform', 'translateY(0)');
      }, 0);

      $('tr td:first-child').not($(this)).siblings().css({ 'display': 'none', 'transform': 'translateY(-9999px)' });
    });
  }

}).resize();



const dashsell = document.getElementById("dashsell")
const dsbtn = document.getElementById("dashsellbutn")
const dashrent = document.getElementById("dashrent")
const drbtn = document.getElementById("dashrentbutn")
const dashpg = document.getElementById("dashpg")
const dpbtn = document.getElementById("dashpgbutn")

dsbtn.addEventListener("click", function () {
  dashsell.style.display = "block";
  dashrent.style.display = "none"
  dashpg.style.display = "none"
})

drbtn.addEventListener("click", function () {
  dashrent.style.display = "block";
  dashpg.style.display = "none"
  dashsell.style.display = "none";
})

dpbtn.addEventListener("click", function () {
  dashpg.style.display = "block";
  dashrent.style.display = "none"
  dashsell.style.display = "none";
})


function initializeSwiper10(selector, slidesPerView, spaceBetween, autoplayDelay) {
  return new Swiper(selector, {
    slidesPerView: slidesPerView, // preview slider
    spaceBetween: spaceBetween,
    autoplay: {
      delay: autoplayDelay,
      disableOnInteraction: false,
    },
    loop: true,
    lazy: true,
    freemode: true,
    speed: 400,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
      dynamicBullets: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    breakpoints: {
      768: {
        slidesPerView: 2.2,
      },
      540: {
        slidesPerView: 2,
      },
      320: {
        slidesPerView: 1.2,
      },
    },
  });
}
var swiper15 = initializeSwiper10(".mySwiper", 3.2, 30, 2000);
var swiper16 = initializeSwiper10(".mySwiper1", 2, 20, 2500);
var swiper17 = initializeSwiper10(".mySwiper13", 3.2, 40, 4000);

var dashbuttonContainer = document.getElementById("up3");
var dashboardbutton = dashbuttonContainer.getElementsByClassName("dashbutton");
for (var i = 0; i < dashboardbutton.length; i++) {
  dashboardbutton[i].addEventListener("click", function () {
    var dashneocurrent = document.getElementsByClassName("activeded");
    dashneocurrent[0].className = dashneocurrent[0].className.replace(" activeded", "");
    this.className += " activeded";
  });
}