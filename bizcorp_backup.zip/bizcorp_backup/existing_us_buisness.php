<?php include 'header.php'; ?>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
<link href="css/services.css" rel="stylesheet" />
 <style>
        /* Global CSS Variables */
        :root {
            --color-primary: #2c3e50;
            --color-secondary: #34495e;
            --color-accent: #3c6bb6;
            --color-success: #2ecc71;
            --color-text-primary: #2c3e50;
            --color-text-secondary: #7f8c8d;
            --color-background: #ecf0f1;
            --color-white: #ffffff;

            --spacing-xs: 0.5rem;
            --spacing-sm: 1rem;
            --spacing-md: 2rem;
            --spacing-lg: 3rem;
            --spacing-xl: 4rem;

            --shadow-small: 0 2px 4px rgba(0, 0, 0, 0.1);
            --shadow-medium: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-large: 0 10px 15px rgba(0, 0, 0, 0.1);

            --transition-default: all 0.3s ease;
            --border-radius-sm: 4px;
            --border-radius-md: 8px;
            --border-radius-lg: 16px;
        }

        .service-contents h4{
            font-weight: 600;
        }

        .services-2 .content-title {
            margin-bottom: 15px;
        }

        /* Welcome Section */
        .welcome-section {
            position: relative;
            /* min-height: 100vh; */
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: var(--spacing-md);
        }

        .welcome-content {
            max-width: 1200px;
            text-align: center;
            color: var(--color-white);
        }

        .welcome-title {
            font-size: 35px;
            font-weight: 700;
            margin-bottom: var(--spacing-md);
            background: linear-gradient(to right, var(--color-white), #e0e0e0);
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .welcome-description {
            font-size:16px;
            max-width: 800px;
            margin: 0 auto var(--spacing-lg);
            opacity: 0;
            color: #fff;
            animation-delay: 0.3s;
        }

        .welcome-cta {
            opacity: 0;
            animation-delay: 0.6s;
        }

        .welcome-content-btn {
            display: inline-block;
            padding: var(--spacing-sm) var(--spacing-lg);
            background: var(--color-accent);
            color: var(--color-white);
            border-radius: var(--border-radius-lg);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition-default);
            box-shadow: var(--shadow-medium);
        }

        .welcome-content-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-large);
            background: color-mix(in srgb, var(--color-accent) 90%, white);
        }

        /* Vision Section */
        .vision-section {
            background: var(--color-white);
            padding: var(--spacing-xl) var(--spacing-md);
            position: relative;
        }

        .vision-container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .vision-text {
            font-size: 1.25rem;
            color: var(--color-text-secondary);
            padding: var(--spacing-md);
            border-left: 4px solid var(--color-accent);
            background: color-mix(in srgb, var(--color-background) 15%, white);
            border-radius: 0 var(--border-radius-md) var(--border-radius-md) 0;
        }

        /* Services Section */
        .services-section {
            background: var(--color-background);
            padding: var(--spacing-xl) var(--spacing-md);
        }

        .services-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .services-title {
            text-align: center;
            color: var(--color-text-primary);
            font-size:35px;
            font-weight:600;
            margin-bottom: var(--spacing-xl);
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: var(--spacing-md);
        }

        .service-item {
            background: var(--color-white);
            border-radius: var(--border-radius-md);
            padding: var(--spacing-md);
            box-shadow: var(--shadow-small);
            transition: var(--transition-default);
        }

        .service-item:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-medium);
        }

        .stats .content-title {
            font-weight: 600;
        }

        .service-item__title {
            font-weight: 600;
            color: var(--color-primary);
            font-size: 1.25rem;
            margin-bottom: var(--spacing-md);
            padding-bottom: var(--spacing-sm);
            border-bottom: 2px solid var(--color-background);
        }

        .service-item__list {
            list-style: none;
        }

        .service-item__list li {
            margin: var(--spacing-xs) 0;
            padding-left: var(--spacing-md);
            position: relative;
            color: #3c6bb6;
        }

        .service-item__list li::before {
            content: "→";
            position: absolute;
            left: 0;
            color: var(--color-accent);
        }

        /* Animation Keyframes */
        @keyframes slideInUp {
            from {
                transform: translateY(20px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.05);
            }

            100% {
                transform: scale(1);
            }
        }

        .animate-slideIn {
            animation: slideInUp 0.6s ease-out forwards;
        }

        .animate-fadeIn {
            animation: fadeIn 0.8s ease-out forwards;
        }

        .animate-pulse {
            animation: pulse 2s infinite;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .services-grid {
                grid-template-columns: 1fr;
            }

            .vision-text {
                font-size: 1.1rem;
                padding: var(--spacing-sm);
            }
        }
         
            .get-started:hover {
                border-color: var(--accent-color);
                background-color: transparent;
                color: var(--accent-color);
            }
            .get-started {
                background-color: var(--accent-color);
                color: var(--contrast-color);
                border-radius: 30px;
                padding: 8px 30px;
                border: 2px solid transparent;
                transition: 0.3s all ease-in-out;
                font-size: 14px;
            }
        
            .service-item__list1 li{
                color: var(--color-text-secondarycolor-text-secondary);
            }
        
            .lead ul li{
                list-style: disc;
                font-size: 17px;
            }
            .headerul {
                padding-left: 2rem;
            }
            .headerul li {
                list-style: disc;
            }
        
    </style>
<main class="main">
    <!-- About Section -->
    <section id="about" class="about section">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-6 mb-5 mb-lg-0 order-lg-2">
                    <div class="swiper init-swiper">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <img src="./images/eub-first-img.webp" alt="Image" class="img-fluid">
                            </div>
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
                <div class="col-lg-6 order-lg-1">
                    <!-- <span class="section-subtitle" >Welcome</span> -->
                    <h1 class="mb-4">
                        Effortless Compliance Management with BizCorpGlobal
                    </h1>
                    <p class="text-justify">
                        BizCorpGlobal simplifies your U.S. market entry with expert compliance and guidance. Our free Compliance Portal helps you stay on top of deadlines and tasks, ensuring your business stays on track.
                    </p>
                    <ul class="headerul">
                        <li>File annual reports online</li>
                        <li>Get alerts for filings & deadlines</li>
                        <li>Manage tax due dates with ease</li>
                        <li>Access all documents in one place</li>
                    </ul>
                    <p class="mt-5">
                        <a href="https://mktg.bizcorpglobal.com/bsw-survey-page" class="btn btn-get-started">Launch Your Wizard</a>
                    </p>
                </div>
            </div>
        </div>
    </section><!-- /About Section -->

   

    <main class="page-wrapper">
        <!-- Welcome Section -->
        <section class="welcome-section">
            <div class="welcome-content">
                <h2 class="welcome-title animate-slideIn">Accelerate Your U.S. Business Setup with BizCorpGlobal</h5>
                    <p class="welcome-description animate-fadeIn">At BizCorpGlobal, we provide comprehensive business filing services to help you launch, manage, and grow your business seamlessly.</p>
            </div>
        </section>

        <!-- Vision Section -->
        <section class="vision-section">
            <div class="vision-container">
                <p class="vision-text">
                    Our mission is to serve as your reliable partner and guide at every stage of your business journey. From registration to compliance, BizCorpGlobal ensures your business stays on track, allowing you to focus on what matters most—achieving your goals. We’re here to simplify the process and support your success every step of the way.
                </p>
            </div>
        </section>

        <!-- Services Section -->
        <section id="services" class="services-section">
            <div class="services-container">
                <h2 class="services-title">Our Services</h2>
                <div class="services-grid">
                    <article class="service-item">
                        <h3 class="service-item__title">Formation Services</h3>
                        <ul class="service-item__list">
                            <li> <a href="initial_reports"> Initial Reports </a></li>
                            <li> <a href="annual_reports"> Annual Reports</a></li>
                            <li> <a href="registered_agent_services"> Registered Agent Services</a></li>
                            <li> <a href="s_corporation_elections"> S Corporation Elections</a></li>
                        </ul>
                    </article>

                    <article class="service-item">
                        <h3 class="service-item__title">Compliance Solutions</h3>
                        <ul class="service-item__list">
                            <li> <a href="foreign_qualification"> Foreign Qualification</a></li>
                            <li> <a href="articles_of_mendment"> Articles of Amendment</a></li>
                            <li> <a href="articles_of_conversion"> Articles of Conversion</a></li>
                            <li> <a href="domestication"> Domestication</a></li>
                        </ul>
                    </article>

                    <article class="service-item">
                        <h3 class="service-item__title">Documentation</h3>
                        <ul class="service-item__list">
                            <li> <a href="certificates_good_standing"> Certificates Of Good Standing</a></li>
                            <li> <a href="apostille_certification"> Apostille Certification</a></li>
                            <li> <a href="articles_of_dissolution"> Articles Of Dissolution</a></li>
                            <li> <a href="beneficial_ownership_reporting"> Beneficial Ownership Reporting</a></li>
                        </ul>
                    </article>
                </div>
            </div>
        </section>
    </main>


    <section id="stats" class="stats section light-background">
        <div class="container">
          <div class="row gy-4 justify-content-center">
            <div class="col-lg-5">
              <div class="images-overlap">
                <img src="./images/eub-second-img.webp" alt="student" class="img-fluid img-1">
              </div>
            </div>
             
            <div class="col-lg-5 ">
            <h2 class="content-title">Simplify the Management of Your U.S. Business Entities Seamlessly.</h2>
              <p>Do you handle the corporate compliance and business filings for multiple organizations?</p>
              <div class="lead text-justify p-3">
                <ul>
                    <li>
                        If you're an entrepreneur, compliance expert, or professional managing filings for multiple business entities, 
                        BizCorpGlobal's Compliance Portal makes compliance seamless and efficient.
                    </li>
                    <br> 
                    <li>
                        Join the <span style="color: #3c6bb6;"> BizCorpGlobal </span>Partner today and unlock free access to our powerful compliance management tool for business entities. Free to join, with no strings attached.
                    </li>
                </ul>
                <p class="about mt-4">
                        <a href="https://mktg.bizcorpglobal.com/bsw-survey-page" class="btn btn-get-started">Launch Your Wizard</a>
                </p>
              </div>
              
            </div>
          </div>
        </div>
      </section>

    <section class="services-section">
            <div class="services-container">
                <h2 class="services-title" style="margin-bottom:10px">Registered Agent Services Across All 50 States</h2>
                <p class="text-center" style="margin-bottom:50px">Ensure your business stays compliant with BizCorpGlobal's trusted Registered Agent Services, available nationwide.</p>
                <div class="services-grid">
                    <article class="service-item">
                        <h3 class="service-item__title text-center">Fast</h3>
                        <ul class="service-item__list1">
                            <li class="text-justify">
                            When you choose BizCorpGlobal as your Registered Agent, we prioritize your filing requests, ensuring they move straight to the front of the line.Our team actively monitors your business entity for compliance risks and sends timely alerts as important deadlines approach, keeping you on track.
                            </li>
                        </ul>
                    </article>

                    <article class="service-item">
                        <h3 class="service-item__title text-center">Reliable</h3>
                        <ul class="service-item__list1">
                            <li class="text-justify">
                            At BizCorpGlobal, we are the trusted choice for corporations and LLCs. We take pride in our services and ensure that any service of process or compliance-related communication is promptly and securely delivered to you without delay.
                            </li>
                        </ul>
                    </article>
                    
                    <article class="service-item">
                        <h3 class="service-item__title text-center">Affordable</h3>
                        <ul class="service-item__list1">
                            <li class="text-justify">
                            Our extensive network of affiliate offices spans all 50 states, enabling us to provide representation wherever you need it. If you require services in multiple states, contact us today, and we’ll match or beat any legitimate price for comparable services.
                            </li>
                        </ul>
                    </article>
                </div>
            </div>
        </section>
        

    <!-- Tabs Section -->
    <section id="tabs" class="tabs section light-background">

        <div class="container">
            <div class="row gap-x-lg-4 justify-content-between">
                <div class="col-lg-12 js-custom-dots">
                    <a href="#" class="service-item link horizontal d-flex active ">
                        <div class="service-contents p-5">
                            <h4>Simplify Your Business Filings with Our Experts
                            </h4>
                            <p class="mt-4 text-justify">
                                Schedule a Free Consultation with a BizCorpGlobal Specialist to streamline your business filings, save valuable time, and minimize costs effectively.
                                <br><br>
                                Schedule a Free Consultation online or call us at <b> +91 9840777207 </b>
                            </p>

                            <button class="get-started mt-4">Get Free Consultation</button>
                        </div>
                        <!-- /.service-contents-->
                    </a>
                    <!-- /.service -->
                    
                </div>

            </div>
        </div>
    </section>
    <!-- /Tabs Section -->

</main>

<!-- Scroll Top -->
<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<script src="vendor/bootstrap/css/bootstrap.bundle.min.js"></script>

<?php include 'footer.php'; ?>