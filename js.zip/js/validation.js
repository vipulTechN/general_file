setTimeout(() => {
  var startPos;
  var geoSuccess = function(position) {
    startPos = position;
    document.getElementById('startLat').value = startPos.coords.latitude;
    document.getElementById('startLon').value = startPos.coords.longitude;
  };
  navigator.geolocation.getCurrentPosition(geoSuccess);
}, 4000);