</head>

<body>
  <!-- incentive main start -->
  <div class="incentivemain">

    <!-- Navbar -->
    <nav class="navbar">

      <i class="bi bi-sliders2 dashopen" onclick="toggleleftsidebar()"></i>

      <div class="incentivelogo">
        <a href="#" class="logo">
          <img class="shilogo" src="../assets/images/shilogo.png" alt="" />
        </a>
      </div>

      <form action="#" id="lapserach">
        <div class="inputwrap d-block position-relative">
          <div class="form-input d-flex">
            <input type="text" id="searchInput" placeholder="Search..." onkeyup="filterOptions()" />
            <button class="search-btn" type="submit">
              <i class="bx bx-search"></i>
            </button>
          </div>

          <ul id="optionul">

            <li class="optionli">
              <a href="/user/hrlogin/dashboard.php">Dashboard</a>
            </li>

            <li class="optionli">
              <a href="/user/hrlogin/tracking.php">Incentive-Tracker</a>
            </li>

            <li class="optionli">
              <a href="/user/hrlogin/incentiveuser.php">Incentive-User</a>
            </li>

            <li class="optionli">
              <a href="/user/hrlogin/payment_table.php">Payment-Tracker</a>
            </li>

            <li class="optionli">
              <a href="/user/hrlogin/companyassets.php">Company Assets</a>
            </li>

            <li class="optionli">
              <a href="/user/hrlogin/createaccount.php">Create Account</a>
            </li>

          </ul>
        </div>
      </form>

      <div id="mob_search_icon" onclick="openSearchPopup()">
        <i class="bx bx-search"></i>
      </div>

      <div id="search-popup" class="search-popup">
        <form>
          <input type="text" placeholder="Type your search...">
          <div class="mob-pop-flex">
            <button type="submit">Search</button>
            <button onclick="closeSearchPopup()">Close</button>
          </div>
        </form>
      </div>

      <a href="#" class="notif" id="more_notif_icon">
        <i class="bx bx-bell"></i>
        <span class="count">0</span>
      </a>

      <div class="notif-content" id="notif-content_box">
        <ul>
          <div class="closebtn"><i class="bi bi-x-circle-fill"></i></div>
          <li>
            <span>
              <h6>You have 3 notification</h6>
            </span>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>today</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>yesterday</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
        </ul>
      </div>

      <a href="#" class="profile" id="more_profile_icon">
        <i class="bi bi-person-fill"></i>
      </a>

      <div class="profile-content" id="profile-content_box">
        <ul>
          <div class="closebtn1"><i class="bi bi-x-circle-fill"></i></div>
          <li>
            <span>
              <i class="bi bi-person-fill"></i>
              Welcome Pratham!
            </span>
          </li>
          <li>
            <span>
              <i class="bi bi-lock-fill"></i>
              Forget Password
            </span>
          </li>
          <li>
            <span>
              <i class="bi bi-box-arrow-right"></i>
              User-login
            </span>
          </li>

          <li>
            <button class="profile-logout">
              <i class="bx bx-log-out-circle"></i>
              Logout
            </button>
          </li>
        </ul>
      </div>

      <a href="#" class="setting" id="togglerightsidebar">
        <i class="bi bi-sliders"></i>
      </a>

      <!-- Right Sidebar -->
      <aside id="rightsidebar" class="pmd-sidebar">
        <i class="bi bi-x-circle-fill close-btn" id="close-btn"></i>
        <ul class="pmd-sidebar-ul">
          <li class="pmd-sidebar-li" data-toggle="modal" data-target="#filterModal">
            <i class="bi bi-funnel-fill"></i>
            <span>Filter</span>
          </li>
          <li class="pmd-sidebar-li" data-toggle="modal" data-target="#calculatorModal">
            <i class="bi bi-calculator"></i>
            <span>Calculator</span>
          </li>
          <li class="pmd-sidebar-li" type="button" id="downloadCsvBtn">
            <i class="bi bi-cloud-arrow-down-fill"></i>
            <span>Download</span>
          </li>

        </ul>

      </aside>

    </nav>
    <!-- End of Navbar -->

    <!--Left Sidebar -->
    <div class="sidebar" id="sidebar">
      <ul class="side-menu" id="side-menu">

        <li class="sidemenuli sideactive">
          <a href="/user/hrlogin/index.php">
            <i class="bx bxs-dashboard"></i>
            Dashboard
          </a>
        </li>

        <li class="sidemenuli">
          <a href="/user/hrlogin/tracking.php"><i class="bx bx-message-square-dots"></i>Incentive-Tracker</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/hrlogin/incentiveuser.php"><i class='bx bxs-user-pin'></i>Incentive-User</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/hrlogin/payment_table.php"><i class='bx bx-rupee'></i>Payment-Tracker</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/hrlogin/companyassets.php"><i class='bx bx-laptop'></i>Company Assets</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/hrlogin/companyassets.php"><i class='bx bxs-user-account'></i>Create Account</a>
        </li>

        <li class="sidemenuli">
          <a href="#"><i class="bi bi-lightbulb-fill"></i>
            <input type="checkbox" id="theme-toggle" hidden />
            <label for="theme-toggle" class="theme-toggle"></label>
          </a>
        </li>

        <li class="sidemenuli">
          <a href="" class="logout"><i class="bx bx-log-out-circle"></i>Logout</a>
        </li>

      </ul>
    </div>
    <!-- End of Left Sidebar -->
    <!-- Filter Rows Modal Start -->
    <div class="modal fade" tabindex="-1" id="filterModal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Filter Data</h5>
            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close" id="closeFilter"></button>
          </div>
          <div class="modal-body">
            <div class="container p-0">
              <div class="row">
                <!-- Filter inputs -->
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterID" placeholder="ID">
                  <input type="text" class="form-control mb-2" id="filterBookingDate" placeholder="Booking Date">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterMonth" placeholder="Month">
                  <input type="text" class="form-control mb-2" id="filterBuilder" placeholder="Builder Name">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterProject" placeholder="Project Name">
                  <input type="text" class="form-control mb-2" id="filterCustumername" placeholder="Customer Name">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterContactnumber" placeholder="Contact No.">
                  <input type="text" class="form-control mb-2" id="filterEmail" placeholder="Email Id">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterType" placeholder="Unit Type">
                  <input type="text" class="form-control mb-2" id="filterUnit" placeholder="Unit No.">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterSize" placeholder="Unit Size">
                  <input type="text" class="form-control mb-2" id="filterAgreement" placeholder="Agreement Value">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterCommission" placeholder="Commission %">
                  <input type="text" class="form-control mb-2" id="filterTrevenue" placeholder="Total Revenue">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterCashBack" placeholder="CashBack %">
                  <input type="text" class="form-control mb-2" id="filterActualRevenue" placeholder="Actual Revenue">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterReceived" placeholder="Received Amt.">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterStatus" placeholder="Status">
                </div>
                <div class="col-md-12">
                  <input type="text" class="form-control mb-2" id="filterSales" placeholder="Sales person">
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <!-- Close Modal button -->
            <button type="button" class="btn btn-secondary" data-dismiss="modal" id="cancleFilter">Close</button>
            <!-- Clear Filters button -->
            <button type="button" class="btn btn-danger" id="clearFiltersBtn">Clear Filters</button>
            <!-- Apply Filters button -->
            <button type="button" class="btn btn-primary" id="applyFiltersBtn">Apply Filters</button>
          </div>
        </div>
      </div>
    </div>
    <!-- filter rows Modal End -->
    <script>
      function applyFilters() {
        var filterInputs = [{
            id: "filterID",
            columnIndex: 0
          },
          {
            id: "filterBookingDate",
            columnIndex: 1
          },
          {
            id: "filterMonth",
            columnIndex: 2
          },
          {
            id: "filterBuilder",
            columnIndex: 3
          },
          {
            id: "filterProject",
            columnIndex: 4
          },
          {
            id: "filterCustumername",
            columnIndex: 5
          },
          {
            id: "filterContactnumber",
            columnIndex: 6
          },
          {
            id: "filterEmail",
            columnIndex: 7
          },
          {
            id: "filterType",
            columnIndex: 8
          },
          {
            id: "filterUnit",
            columnIndex: 9
          },
          {
            id: "filterSize",
            columnIndex: 10
          },
          {
            id: "filterAgreement",
            columnIndex: 11
          },
          {
            id: "filterCommission",
            columnIndex: 12
          },
          {
            id: "filterTrevenue",
            columnIndex: 13
          },
          {
            id: "filterCashBack",
            columnIndex: 14
          },
          {
            id: "filterActualRevenue",
            columnIndex: 15
          },
          {
            id: "filterStatus",
            columnIndex: 16
          },
          {
            id: "filterReceived",
            columnIndex: 17
          },
          {
            id: "filterSales",
            columnIndex: 18
          },
        ];
        activeFilters = [];
        $("#pagedataaas tr").each(function() {
          var row = $(this);
          var showRow = true;
          filterInputs.forEach(function(inputInfo) {
            var input = $("#" + inputInfo.id);
            var filterValue = input.val().toLowerCase();
            var cellValue = row.find("td:eq(" + inputInfo.columnIndex + ")").text().toLowerCase();
            if (cellValue.indexOf(filterValue) === -1) {
              showRow = false;
              return false;
            }
            if (filterValue.trim() !== "") {
              activeFilters.push(filterValue);
            }
          });
          if (showRow) {
            row.addClass("custom-filtered-row");
          } else {
            row.removeClass("custom-filtered-row");
          }
        });
        var totalTotalRevenue = 0;
        var totalActualRevenue = 0;
        var counterRow = 0;
        $(".custom-filtered-row").each(function() {
          var totalRevenue = parseFloat($(this).find("td:eq(13)").text());
          var actualRevenue = parseFloat($(this).find("td:eq(15)").text());
          if (!isNaN(totalRevenue)) {
            totalTotalRevenue += totalRevenue;
            counterRow += 1;
          }
          if (!isNaN(actualRevenue)) {
            totalActualRevenue += actualRevenue;
          }
        });

        $("#counter").text(counterRow);
        $("#totalTotalRevenue").text(totalTotalRevenue.toLocaleString());
        $("#totalActualRevenue").text(totalActualRevenue.toLocaleString());
        $("#pagedataaas tr").hide();
        applyCustomFilter();
      }
      applyCustomFilter();

      function applyCustomFilter() {
        $(".custom-filtered-row").show();
      }
      $(".filterable .btn-filter1").click(function() {
        $("#filterModal").modal("show");
      });
      $("#applyFiltersBtn").click(function() {
        $("#filterModal").modal("hide");
        applyFilters();
      });
      $("#filterModal").on("hidden.bs.modal", function() {
        $(".filterable .filters input").val("");
        applyFilters();
      });
      $("#closeFilter").click(function() {
        applyFilters();
        $("#filterModal").modal("hide");
      });
      $("#cancleFilter").click(function() {
        applyFilters();
        $("#filterModal").modal("hide");
      });
      $(document).ready(function() {
        $("#clearFiltersBtn").click(function() {
          $("#filterID, #filterBookingDate, #filterMonth, #filterBuilder, #filterProject, #filterContactnumber, #filterCustumername, #filterEmail, #filterType, #filterUnit, #filterSize, #filterAgreement, #filterCommission, #filterTrevenue, #filterCashBack, #filterActualRevenue, #filterStatus, #filterReceived, #filterSales").val("");
        });
      });
      $("#clearFiltersBtn").click(function() {
        applyFilters();
        $("#filterModal").modal("hide");
      });
    </script>
    <!-- Calculator Modal -->
    <div class="modal fade" id="calculatorModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Incentive Calculator</h5>
                  <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>

                </div>
                <div class="modal-body">
                  <form id="calculator-form">
                    <div class="form-group">
                      <label for="d1" class="font-weight-bold">Current Salary:</label>
                      <input type="number" class="form-control" id="d1" required>
                    </div>
                    <div class="form-group">
                      <label for="d2" class="font-weight-bold">Generated Revenue</label>
                      <input type="number" class="form-control" id="d2" required>
                    </div>
                  </form>
                  <div class="mt-3">
                    <!-- <p>Incentive:</p> -->
                    <div class="border border-dark d-inline p-2 m-1 bg-success text-white font-weight-bold">Amount:
                      ₹<span id="result">0.00</span></div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" form="calculator-form" class="btn btn-primary">Calculate</button>
                </div>
              </div>
            </div>
          </div>
          <!-- calculator modal End -->