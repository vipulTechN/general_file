<?php 
if(isset($_POST['submit'])){ 
      
    $from = $_POST['email']; // this is the sender's Email address
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $mobile = htmlspecialchars($_POST['phone']);
    $ipaddress = htmlspecialchars($_POST['ipaddress']);
    $property = htmlspecialchars($_POST['mgh']);
    $message = htmlspecialchars($_POST['message']);

    // SearchHomes API Call
    $apiUrl = "https://www.searchhomesindia.in/superadmin/myapicontainer/v2/api/googleads_leads";
    $apiKey = "ee900232f2e601ef6e9904fa71a73c5e";

    // Data to be sent
    $postData = [
        "name" => $name,
        "email" => $email,
        "number" => $mobile,
        "location" => $ipaddress
    ];

    // API Headers
    $headers = [
        "Content-Type: application/json",
        "API-Key: $apiKey"
    ];

    // Initialize cURL
    $ch = curl_init($apiUrl);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Debugging: Print request data
    // echo "<h3>Debugging Request:</h3>";
    // echo "<pre>Headers Sent:\n" . print_r($headers, true) . "</pre>";
    // echo "<pre>Payload Sent:\n" . json_encode($postData, JSON_PRETTY_PRINT) . "</pre>";

    // Execute the cURL request
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // if ($response === false) {
    //     echo "cURL Error: " . curl_error($ch);
    // } else {
    //     echo "<h3>API Response:</h3>";
    //     echo "<pre>HTTP Status Code: $httpCode</pre>";
    //     echo "<pre>Response Body:\n" . htmlspecialchars($response) . "</pre>";
    // }
    // SHI CRM API CALLED END           
                
  $fields = array(
    "sender_id" => "SHHOME",
    "message" => "Property- .$property. Name- .$name., Mobile-.$mobile., Email- .$email. 
    Regards, SearchHomes india pvt ltd",
    "template_id" => "1207163731895114985",
    "entity_id" => "1201159178483176795",
    "route" => "dlt_manual",
    "numbers" => "8147267372",
);
// ,8638868550,6264159415,8951927450, 8147267372, 9036611811
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($fields),
  CURLOPT_HTTPHEADER => array(
    "authorization: RKnKg7po5EXg8lVwwYLYnZHFcoBBHEqWKfh4juLfSuuuZCCbPj4nFjzsSnGV",
    "accept: */*",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

// if ($err) {
//   echo "cURL Error #:" . $err;
// } else {
//   echo $response;
// }

      ?>
						<script>
							window.location.href='thank_you.php';
						</script>
			<?php
    }
?>