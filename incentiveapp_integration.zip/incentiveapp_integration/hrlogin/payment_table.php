<?php
session_start();

// Check if the user is logged in and is a superadmin
if (!(isset($_SESSION['loggedin']) && isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] === true)) {
  header('Location: access_denied.html'); // Redirect to an access denied page or another page
  exit;
}

$servername = "localhost"; // Change this to your MySQL server name
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$dbname = "insentive_app"; // Change this to your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the ggdata table
$sql = "SELECT id, overall_earn, overall_paid, advance_pay, remaning_payment, user_name, bookin_number FROM payment_table";
$result = $conn->query($sql);
?>

<?php include('htmlopen.php'); ?>
<?php include('header.php'); ?>
<!-- Main Content -->
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="table-container">
          <table id="example" class="stripe row-border order-column display" cellspacing="0" style="width:100%">
            <thead>
              <tr>
                <th>ID</th>
                <th>Overall Earning</th>
                <th>Overall Build</th>
                <th>Advance Amount</th>
                <th>Remaining Payment</th>
                <th>Booking Number</th>
                <th>User Name</th>
              </tr>
            </thead>
            <tbody id="paymenttable">
              <?php
              if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                  echo "<tr>";
                  echo "<td>" . $row['id'] . "</td>";
                  echo "<td>" . $row['overall_earn'] . "</td>";
                  echo "<td>₹ " . $row['overall_paid'] . "</td>";

                  // Add an input field for editing the advance_pay
                  echo "<td><input type='text' id='edit_advance_pay_" . $row['id'] . "' value='" . $row['advance_pay'] . "'></td>";

                  echo "<td>₹ " . $row['remaning_payment'] . "</td>";
                  echo "<td> " . $row['bookin_number'] . "</td>";
                  echo "<td>" . $row['user_name'] . "</td>";

                  // Add an Edit button to submit changes
                  echo "<td><button onclick='editAdvancePay(" . $row['id'] . ")'>Save</button></td>";

                  echo "</tr>";
                }
              } else {
                echo "<tr><td colspan='8'>No data found</td></tr>";
              }
              ?>
            </tbody>
            <tfoot>
              <tr>
                 <th>ID</th>
                <th>Overall Earning</th>
                <th>Overall Build</th>
                <th>Advance Amount</th>
                <th>Remaining Payment</th>
                <th>Booking Number</th>
                <th>User Name</th>
              </tr>
            </tfoot>
          </table>
          <button id="scroll-left"><i class='bx bx-left-arrow-alt'></i></button>
          <button id="scroll-right"><i class='bx bx-right-arrow-alt'></i></button>
        </div>
      </div>
    </div>
    <!-- Filter Rows Modal Start -->
    <div class="modal fade" tabindex="-1" id="filterModal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Filter Data</h5>
            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close" id="closeFilter"></button>
          </div>
          <div class="modal-body">
            <div class="container p-0">
              <div class="row">
                <!-- Filter inputs -->
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterID" placeholder="ID">
                  <input type="text" class="form-control mb-2" id="Overallearn" placeholder="Overall earn">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="Overallpaid" placeholder="Overall paid">
                  <input type="text" class="form-control mb-2" id="Advancepay" placeholder="Advance pay">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="Remaningpay" placeholder="Remaning payment">
                  <input type="text" class="form-control mb-2" id="Username" placeholder="User name">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="Bookingno" placeholder="Booking number">
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <!-- Close Modal button -->
            <button type="button" class="btn btn-secondary" data-dismiss="modal" id="cancleFilter">Close</button>
            <!-- Clear Filters button -->
            <button type="button" class="btn btn-danger" id="clearFiltersBtn">Clear Filters</button>
            <!-- Apply Filters button -->
            <button type="button" class="btn btn-primary" id="applyFiltersBtn">Apply Filters</button>
          </div>
        </div>
      </div>
    </div>
    <!-- filter rows Modal End -->
  </div>
</div>
<!--End Main Content -->
<script>
  function applyFilters() {
    var filterInputs = [{
        id: "filterID",
        columnIndex: 0
      },
      {
        id: "Overallearn",
        columnIndex: 1
      },
      {
        id: "Overallpaid",
        columnIndex: 2
      },
      {
        id: "Advancepay",
        columnIndex: 3
      },
      {
        id: "Remaningpay",
        columnIndex: 4
      },
      {
        id: "Username",
        columnIndex: 5
      },
      {
        id: "Bookingno",
        columnIndex: 6
      }
    ];
    activeFilters = [];
    $("#paymenttable tr").each(function() {
      var row = $(this);
      var showRow = true;
      filterInputs.forEach(function(inputInfo) {
        var input = $("#" + inputInfo.id);
        var filterValue = input.val().toLowerCase();
        var cellValue = row.find("td:eq(" + inputInfo.columnIndex + ")").text().toLowerCase();
        if (cellValue.indexOf(filterValue) === -1) {
          showRow = false;
          return false;
        }
        if (filterValue.trim() !== "") {
          activeFilters.push(filterValue);
        }
      });
      if (showRow) {
        row.addClass("custom-filtered-row");
      } else {
        row.removeClass("custom-filtered-row");
      }
    });
    $("#paymenttable tr").hide();
    applyCustomFilter();
  };
  applyCustomFilter();

  function applyCustomFilter() {
    $(".custom-filtered-row").show();
  }
  $(".filterable .btn-filter1").click(function() {
    $("#filterModal").modal("show");
  });
  $("#applyFiltersBtn").click(function() {
    $("#filterModal").modal("hide");
    applyFilters();
  });
  $("#filterModal").on("hidden.bs.modal", function() {
    $(".filterable .filters input").val("");
    applyFilters();
  });
  $("#closeFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $("#cancleFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $(document).ready(function() {
    $("#clearFiltersBtn").click(function() {
      $("#filterID,#Overallearn,#Overallpaid,#Advancepay,#Remaningpay,#Username,#Bookingno").val("");
    });
  });
  $("#clearFiltersBtn").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
</script>
<script>
  function editAdvancePay(id) {
    var newAdvancePay = document.getElementById('edit_advance_pay_' + id).value;

    // Assuming you have an AJAX function to send the updated value to the server
    // You need to implement the updateAdvancePay function in your action.php file
    updateAdvancePay(id, newAdvancePay);
  }

  function updateAdvancePay(id, newAdvancePay) {
    // Use AJAX to send the updated value to the server
    // You can use jQuery.ajax or fetch API for this purpose
    // Send an AJAX request to update the "advance_pay" in the database
    // Example using jQuery.ajax:
    $.ajax({
      type: 'POST',
      url: 'action.php',
      data: {
        action: 'update_advance_pay',
        id: id,
        newAdvancePay: newAdvancePay
      },
      success: function(response) {
        // Handle the response from the server (e.g., show a success message)
        console.log(response);
      },
      error: function(error) {
        // Handle the error (e.g., show an error message)
        console.error(error);
      }
    });
  }
</script>
<?php include('htmlclose.php'); ?>
<?php
// Close the connection
$conn->close();
?>