</head>
<body>
  <!-- incentive main start -->
  <div class="incentivemain">
     <!-- Navbar -->
     <nav class="navbar">
      <i class="bi bi-sliders2 dashopen" onclick="toggleleftsidebar()"></i>
      <div class="incentivelogo">
        <a href="#" class="logo">
          <img class="shilogo" src="../assets/images/shilogo.png" alt="" />
        </a>
      </div>

    <form action="#" id="lapserach">
      <div class="inputwrap d-block position-relative">
        <div class="form-input d-flex">
          <input type="text" id="searchInput" placeholder="Search..." onkeyup="filterOptions()"  />
          <button class="search-btn" type="submit">
            <i class="bx bx-search"></i>
          </button>
        </div>

      <ul id="optionul">

        <li class="optionli">
          <a href="/user/userlogin/database.php">Booking</a>
        </li>

        <li class="optionli">
          <a href="/user/userlogin/paid.php">Paid</a>
        </li>

        <li class="optionli">
          <a href="/user/userlogin/processing.php">Processing</a>
        </li>

        <li class="optionli">
          <a href="/user/userlogin/cancel.php">Cancel</a>
        </li>

      </ul>
      </div>
    </form>

      <div id="mob_search_icon" onclick="openSearchPopup()">
        <i class="bx bx-search"></i>
      </div>

      <div id="search-popup" class="search-popup">
        <form>
          <input type="text" placeholder="Type your search...">
          <div class="mob-pop-flex">
            <button type="submit">Search</button>
            <button onclick="closeSearchPopup()">Close</button>
          </div>
        </form>
      </div>

      <a href="#" class="notif" id="more_notif_icon">
        <i class="bx bx-bell"></i>
        <span class="count">0</span>
      </a>

      <div class="notif-content" id="notif-content_box">
        <ul>
          <div class="closebtn"><i class="bi bi-x-circle-fill"></i></div>
          <li>
            <span>
              <h6>You have 3 notification</h6>
            </span>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>today</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>yesterday</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
        </ul>
      </div>

      <a href="#" class="profile" id="more_profile_icon">
        <i class="bi bi-person-fill"></i>
      </a>

      <div class="profile-content" id="profile-content_box">
        <ul>
          <div class="closebtn1"><i class="bi bi-x-circle-fill"></i></div>
          <li>
            <span>
              <i class="bi bi-person-fill"></i>
              Welcome Pratham!
            </span>
          </li>
          <li>
            <span>
              <i class="bi bi-lock-fill"></i>
              Forget Password
            </span>
          </li>
          <li>
            <span>
              <i class="bi bi-box-arrow-right"></i>
              User-login
            </span>
          </li>

          <li>
            <button class="profile-logout">
              <i class="bx bx-log-out-circle"></i>
              Logout
            </button>
          </li>

        </ul>
      </div>

      <a href="#" class="setting" id="togglerightsidebar">
        <i class="bi bi-sliders"></i>
      </a>

      <!-- Right Sidebar -->
      <aside id="rightsidebar" class="pmd-sidebar">
        <i class="bi bi-x-circle-fill close-btn" id="close-btn"></i>
        <ul class="pmd-sidebar-ul">
        <li class="pmd-sidebar-li" type="button" data-toggle="modal" data-target="#addNewUserModal">
            <i class="bi bi-person-fill-add"></i>
            <span>Add Booking</span>
          </li>
<!-- Add New User Modal Start -->
<div class="modal fade" tabindex="-1" id="addNewUserModal">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Add New Booking</h5>
                  <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form id="add-user-form" name="myform" class="p-2" novalidate>
                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="date" name="bdate" class="form-control form-control-lg" required>
                        <div class="invalid-feedback">Date is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="month" name="bmonth" class="form-control form-control-lg" required>
                        <div class="invalid-feedback">Month is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="text" name="developer" class="form-control form-control-lg"
                          placeholder="Enter Builder Name" required>
                        <div class="invalid-feedback">Builder name is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="text" name="bproject" class="form-control form-control-lg"
                          placeholder="Enter Project Name" required>
                        <div class="invalid-feedback">Project name is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="username" name="cname" class="form-control form-control-lg"
                          placeholder="Enter Customer Name" required>
                        <div class="invalid-feedback">Customer name is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="number" name="cnumber" class="form-control form-control-lg"
                          placeholder="Enter Contact Number" required>
                        <div class="invalid-feedback">Contact Number is required!</div>
                      </div>
                    </div>

                    <div class="col-11 mb-3 mx-auto">
                      <input type="email" name="cemail" class="form-control form-control-lg"
                        placeholder="Enter E-mail" required>
                      <div class="invalid-feedback">E-mail is required!</div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="text" name="tproject" class="form-control form-control-lg"
                          placeholder="Enter Project Tpye" required>
                        <div class="invalid-feedback">Project Tpye is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="text" name="unitno" class="form-control form-control-lg"
                          placeholder="Enter Unit Number" required>
                        <div class="invalid-feedback">Unit Number is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="number" name="psize" class="form-control form-control-lg"
                          placeholder="Enter Project Size" required>
                        <div class="invalid-feedback">Project Size is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="number" name="cagreement" class="form-control form-control-lg"
                          placeholder="Enter Agreement Value" required>
                        <div class="invalid-feedback">Agreement Value is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="text" name="ccashback" class="form-control form-control-lg"
                          placeholder="Enter Commission %" onkeyup="addCalculate(this.value)" required>
                        <div class="invalid-feedback">Commission % is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="number" name="crevenue" class="form-control form-control-lg"
                          placeholder="Total Revenue Amount" required>
                        <div class="invalid-feedback">Revenue Amount is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="text" name="cccashback" class="form-control form-control-lg"
                          placeholder="Enter Cashback %" onkeyup="addCalculate(this.value)" required>
                        <div class="invalid-feedback">Cashback % is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="number" name="ccrevenue" class="form-control form-control-lg"
                          placeholder="Actual Revenue Amount" required>
                        <div class="invalid-feedback">Actual Amount is required!</div>
                      </div>
                    </div>

                    <div class="mb-3">
                      <input type="checkbox" class="btn-check Processing" name="cstatus" id="btn-check-2-outlined"
                        value="Processing" checked>
                      <label class="btn btn-outline-primary" for="btn-check-2-outlined">Processing</label><br><br>

                      <input type="radio" class="btn-check Received" name="cstatus" id="success-outlined"
                        value="Received">
                      <label class="btn btn-outline-success" for="success-outlined">Received</label>

                      <input type="radio" class="btn-check Cancled" name="cstatus" id="danger-outlined"
                        value="Cancled">
                      <label class="btn btn-outline-danger" for="danger-outlined">Cancled</label>
                      <div class="invalid-feedback">Status is required!</div>
                    </div>

                    <div class="mb-3">
                      <input type="number" name="brecived" class="form-control form-control-lg"
                        placeholder="Enter Enter Received Amt.">
                      <div class="invalid-feedback">Enter Received Amt. is required!</div>
                    </div>

                    <div class="mb-3">
                      <input type="submit" value="Add Booking" class="btn btn-primary btn-block btn-lg"
                        id="add-user-btn">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <!-- Add New User Modal End -->
          <li class="pmd-sidebar-li" data-toggle="modal" data-target="#filterModal">
            <i class="bi bi-funnel-fill"></i>
            <span>Filter</span>
          </li>
        </ul>
      </aside>
    </nav>
    <!-- End of Navbar -->

    <!--Left Sidebar -->
    <div class="sidebar" id="sidebar">
      <ul class="side-menu" id="side-menu">

        <li class="sidemenuli sideactive">
         <a href="/user/userlogin/index.php">
          <i class="bx bxs-dashboard"></i>
          Dashboard
         </a>
        </li>

        <li class="sidemenuli">
          <a href="/user/userlogin/database.php"><i class='bx bx-book-add'></i>Booking</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/userlogin/paid.php"><i class="bx bx-message-square-dots"></i>Paid</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/userlogin/processing.php"><i class='bx bxs-user-pin'></i>Processing</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/userlogin/cancel.php"><i class='bx bx-rupee'></i>Cancel</a>
        </li>

        <li class="sidemenuli">
          <a href="#"><i class="bi bi-lightbulb-fill"></i>
            <input type="checkbox" id="theme-toggle" hidden />
            <label for="theme-toggle" class="theme-toggle"></label>
          </a>
        </li>

        <li class="sidemenuli">
          <a href="" class="logout"><i class="bx bx-log-out-circle"></i>Logout</a>
        </li>
        
      </ul>
    </div>
    <!-- End of Left Sidebar -->
    <!-- Filter Rows Modal Start -->
    <div class="modal fade" tabindex="-1" id="filterModal">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Filter Data</h5>
              <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close" id="closeFilter"></button>
            </div>
            <div class="modal-body">
              <div class="container p-0">
                <div class="row">
                  <!-- Filter inputs -->
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterID" placeholder="ID">
                    <input type="text" class="form-control mb-2" id="filterBookingDate" placeholder="Booking Date">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterMonth" placeholder="Month">
                    <input type="text" class="form-control mb-2" id="filterBuilder" placeholder="Builder Name">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterProject" placeholder="Project Name">
                    <input type="text" class="form-control mb-2" id="filterCustumername" placeholder="Customer Name">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterContactnumber" placeholder="Contact No.">
                    <input type="text" class="form-control mb-2" id="filterEmail" placeholder="Email Id">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterType" placeholder="Unit Type">
                    <input type="text" class="form-control mb-2" id="filterUnit" placeholder="Unit No.">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterSize" placeholder="Unit Size">
                    <input type="text" class="form-control mb-2" id="filterAgreement" placeholder="Agreement Value">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterCommission" placeholder="Commission %">
                    <input type="text" class="form-control mb-2" id="filterTrevenue" placeholder="Total Revenue">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterCashBack" placeholder="CashBack %">
                    <input type="text" class="form-control mb-2" id="filterActualRevenue" placeholder="Actual Revenue">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterReceived" placeholder="Received Amt.">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterStatus" placeholder="Status">
                  </div>
                  <div class="col-md-12">
                    <input type="text" class="form-control mb-2" id="filterSales" placeholder="Sales person">
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <!-- Close Modal button -->
              <button type="button" class="btn btn-secondary" data-dismiss="modal" id="cancleFilter">Close</button>
              <!-- Clear Filters button -->
              <button type="button" class="btn btn-danger" id="clearFiltersBtn">Clear Filters</button>
              <!-- Apply Filters button -->
              <button type="button" class="btn btn-primary" id="applyFiltersBtn">Apply Filters</button>
            </div>
          </div>
        </div>
      </div>
      <!-- filter rows Modal End -->
    <script>
  function applyFilters() {
    var filterInputs = [{
        id: "filterID",
        columnIndex: 0
      },
      {
        id: "filterBookingDate",
        columnIndex: 1
      },
      {
        id: "filterMonth",
        columnIndex: 2
      },
      {
        id: "filterBuilder",
        columnIndex: 3
      },
      {
        id: "filterProject",
        columnIndex: 4
      },
      {
        id: "filterCustumername",
        columnIndex: 5
      },
      {
        id: "filterContactnumber",
        columnIndex: 6
      },
      {
        id: "filterEmail",
        columnIndex: 7
      },
      {
        id: "filterType",
        columnIndex: 8
      },
      {
        id: "filterUnit",
        columnIndex: 9
      },
      {
        id: "filterSize",
        columnIndex: 10
      },
      {
        id: "filterAgreement",
        columnIndex: 11
      },
      {
        id: "filterCommission",
        columnIndex: 12
      },
      {
        id: "filterTrevenue",
        columnIndex: 13
      },
      {
        id: "filterCashBack",
        columnIndex: 14
      },
      {
        id: "filterActualRevenue",
        columnIndex: 15
      },
      {
        id: "filterStatus",
        columnIndex: 16
      },
      {
        id: "filterReceived",
        columnIndex: 17
      },
      {
        id: "filterSales",
        columnIndex: 18
      },
    ];
    activeFilters = [];
    $("#pagedataaas tr").each(function() {
      var row = $(this);
      var showRow = true;
      filterInputs.forEach(function(inputInfo) {
        var input = $("#" + inputInfo.id);
        var filterValue = input.val().toLowerCase();
        var cellValue = row.find("td:eq(" + inputInfo.columnIndex + ")").text().toLowerCase();
        if (cellValue.indexOf(filterValue) === -1) {
          showRow = false;
          return false;
        }
        if (filterValue.trim() !== "") {
          activeFilters.push(filterValue);
        }
      });
      if (showRow) {
        row.addClass("custom-filtered-row");
      } else {
        row.removeClass("custom-filtered-row");
      }
    });
    var totalTotalRevenue = 0;
    var totalActualRevenue = 0;
    var counterRow = 0;
    $(".custom-filtered-row").each(function() {
      var totalRevenue = parseFloat($(this).find("td:eq(13)").text());
      var actualRevenue = parseFloat($(this).find("td:eq(15)").text());
      if (!isNaN(totalRevenue)) {
        totalTotalRevenue += totalRevenue;
        counterRow += 1;
      }
      if (!isNaN(actualRevenue)) {
        totalActualRevenue += actualRevenue;
      }
    });

    $("#counter").text(counterRow);
    $("#totalTotalRevenue").text(totalTotalRevenue.toLocaleString());
    $("#totalActualRevenue").text(totalActualRevenue.toLocaleString());
    $("#pagedataaas tr").hide();
    applyCustomFilter();
  }
  applyCustomFilter();

  function applyCustomFilter() {
    $(".custom-filtered-row").show();
  }
  $(".filterable .btn-filter1").click(function() {
    $("#filterModal").modal("show");
  });
  $("#applyFiltersBtn").click(function() {
    $("#filterModal").modal("hide");
    applyFilters();
  });
  $("#filterModal").on("hidden.bs.modal", function() {
    $(".filterable .filters input").val("");
    applyFilters();
  });
  $("#closeFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $("#cancleFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $(document).ready(function() {
    $("#clearFiltersBtn").click(function() {
      $("#filterID, #filterBookingDate, #filterMonth, #filterBuilder, #filterProject, #filterContactnumber, #filterCustumername, #filterEmail, #filterType, #filterUnit, #filterSize, #filterAgreement, #filterCommission, #filterTrevenue, #filterCashBack, #filterActualRevenue, #filterStatus, #filterReceived, #filterSales").val("");
    });
  });
  $("#clearFiltersBtn").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
</script>