// Define the validateForm function globally
function validateForm() {
    // Reset all validation messages
    resetValidationMessages();

    let isValid = true;

    function displayError(input, validFeedback, invalidFeedback, condition) {
        const validElement = document.getElementById(validFeedback);
        const invalidElement = document.getElementById(invalidFeedback);

        if (condition) {
            invalidElement.style.display = 'block';
            isValid = false;
        } else {
            validElement.style.display = 'block';
        }
    }

    // Obtain references to form elements
    const name = document.getElementById('name');
    const email = document.getElementById('email');
    const phone = document.getElementById('phone');
    const vacancy = document.getElementById('vacancy');
    const position = document.getElementById('position');
    const message = document.getElementById('message');
    const resume = document.getElementById('resume');

    // Validate Name
    displayError(name, 'namevalid', 'nameinvalid', name.value.trim() === '');

    // Validate Email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    displayError(email, 'emailvalid', 'emailinvalid', !emailRegex.test(email.value.trim()));

    // Validate Phone
    const phoneRegex = /^\d{10}$/;
    displayError(phone, 'phonevalid', 'phoneinvalid', !phoneRegex.test(phone.value.trim()));

    // Validate Vacancy
    displayError(vacancy, 'vacancyvalid', 'vacancyinvalid', vacancy.value === '-1');

    // Validate Position
    displayError(position, 'positionvalid', 'positioninvalid', position.value.trim() === '');

    // Validate Message
    displayError(message, 'messagevalid', 'messageinvalid', message.value.trim() === '');

    // Validate Resume
    displayError(resume, 'filevalid', 'fileinvalid', resume.value.trim() === '');

    return isValid;
}
function resetValidationMessages() {
    const elements = document.getElementsByClassName('valid-feedback');
    for (const element of elements) {
        element.style.display = 'none';
    }

    const invalidElements = document.getElementsByClassName('invalid-feedback');
    for (const element of invalidElements) {
        element.style.display = 'none';
    }
}
function submitForm() {
    console.log('submitForm function called');
    const formData = new FormData(form);  // Create FormData object inside the function

    const csrfToken = document.getElementsByName('csrfmiddlewaretoken')[0].value;

    fetch('/carrierdata/', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRFToken': csrfToken,
        },
    })
    .then(response => response.json())
    .then(data => {
        console.log('Form submission result:', data);
        if (data.success) {
            // Form submission was successful, show success message
            successMessage.style.display = 'block';
            // Hide success message after 5 seconds and refresh the page
            setTimeout(function () {
                successMessage.style.display = 'none';
                location.reload();
            }, 5000);
        } else {
            // Form submission failed, show failure message
            failureMessage.style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Error during form submission:', error);
    })
    .finally(() => {
        submitButton.disabled = false;  // Re-enable submit button after AJAX request completes
    });
}

// Move the form variable outside of the DOMContentLoaded event listener
const form = document.getElementById('Contactform');
const submitButton = document.getElementById('submit');
const successMessage = document.getElementById('success');
const failureMessage = document.getElementById('failure');

document.addEventListener('DOMContentLoaded', function () {
    console.log('DOMContentLoaded event triggered.');

    // Hide success and failure messages on page load
    successMessage.style.display = 'none';
    failureMessage.style.display = 'none';

    form.addEventListener('submit', function (event) {
        console.log('Form:', form);
        console.log('Submit Button:', submitButton);
        console.log('Success Message:', successMessage);
        console.log('Failure Message:', failureMessage);
        if (!validateForm()) {
            console.log('submitForm function not called');
            event.preventDefault();  // Prevent form submission if validation fails
        } else {
            submitButton.disabled = true;  // Disable submit button during the AJAX request
            console.log('submitForm function called');
            submitForm();
        }
    });
});