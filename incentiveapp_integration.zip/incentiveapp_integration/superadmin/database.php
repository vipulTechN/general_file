<?php include('htmlopen.php'); ?>
<?php include('header.php'); ?>
<!-- Main Content -->
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="table-container">
          <table id="example" class="stripe row-border order-column display" cellspacing="0" style="width:100%">
            <thead class="maintheading">
              <tr>
                <th>ID</th>
                <th>Booking Date</th>
                <th>Month</th>
                <th>Builder</th>
                <th>Project</th>
                <th>Customer Name.</th>
                <th>Contact No.</th>
                <th>Email Id</th>
                <th>Type</th>
                <th>Unit No.</th>
                <th>Size</th>
                <th>Agreement Value</th>
                <th>Commission %</th>
                <th>Total Revenue</th>
                <th>CashBack %</th>
                <th>Actual Revenue</th>
                <th>Status</th>
                <th>Received Amt.</th>
                <th>Sales Person</th>
                <th>Action</th>
              </tr>
            </thead>
            <thead class="scndhead">
              <tr class="group-header">
                <td colspan="20">
                  <div class="wrappsps d-flex justify-content-start">
                    <div class="border border-dark d-inline p-2 bg-warning text-dark font-weight-bold">Financial
                      Year/Bookings: 2023-2024/(15)</div>
                    <div class="border border-dark d-inline p-2 bg-primary text-white font-weight-bold">Total
                      Revenue: ₹ 35406666</div>
                    <div class="border border-dark d-inline p-2 bg-info text-white font-weight-bold">Actual Revenue:
                      ₹ 28292188</div>
                    <div class="border border-dark d-inline p-2 bg-primary text-white font-weight-bold">Remaning
                      Revenue: ₹ 0</div>
                    <div class="border border-dark d-inline p-2 bg-success text-white font-weight-bold">Recived
                      Amount: ₹ 28292188</div>
                    <div class="border border-dark d-inline p-2 bg-secondary text-white font-weight-bold">Amount To
                      be Pay: ₹ 2107215</div>
                    <div class="border border-dark d-inline p-2 bg-info text-white font-weight-bold">Total Paid Amt:
                      ₹ 2107213</div>
                  </div>
                </td>
              </tr>
            </thead>
            <tbody id="pagedataaas">
              <tr>
                <td>1</td>
                <td>2024-03-09</td>
                <td>March</td>
                <td>ABC Builders</td>
                <td>Project XYZ</td>
                <td>John Doe</td>
                <td>1234567890</td>
                <td>john.doe@example.com</td>
                <td>Residential</td>
                <td>101</td>
                <td>1200 sqft</td>
                <td>$200,000</td>
                <td>5%</td>
                <td>$10,000</td>
                <td>2%</td>
                <td>$9,800</td>
                <td>
                  <p class="status delivered">Processed</p>
                </td>
                <td>$5,000</td>
                <td>Jane Doe</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>2</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>
                  <p class="status cancelled">Cancelled</p>
                </td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>3</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>poiu Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>4</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>qwe Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>5</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>asd Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>6</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>lkjh Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>7</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>cv Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>8</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>9</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>10</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>11</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>12</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>13</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>14</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>dfgh Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>15</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>mn Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>16</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>qas Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>17</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jacxvne Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>18</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>JZxcane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>19</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jafdsne Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>20</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>bnb Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>21</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>vbv Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>22</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>vcbane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>23</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>bgtJane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>24</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>eeJane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>25</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>ccJane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>26</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>ssJane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>27</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jxcane Smith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>28</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane cSmith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>29</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane Smfgith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>30</td>
                <td>2024-03-10</td>
                <td>April</td>
                <td>XYZ Developers</td>
                <td>Project ABC</td>
                <td>Jane fmith</td>
                <td>9876543210</td>
                <td>jane.smith@example.com</td>
                <td>Commercial</td>
                <td>202</td>
                <td>1500 sqft</td>
                <td>$300,000</td>
                <td>7%</td>
                <td>$21,000</td>
                <td>3%</td>
                <td>$20,400</td>
                <td>Inactive</td>
                <td>$15,000</td>
                <td>John smith</td>
                <td>
                  <ul class="tableul">
                    <li class="tableli">
                      <i class="bi bi-cloud-arrow-down-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-trash-fill"></i>
                    </li>
                    <li class="tableli">
                      <i class="bi bi-clipboard-check-fill"></i>
                    </li>
                  </ul>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <th>ID</th>
              <th>Booking Date</th>
              <th>Month</th>
              <th>Builder</th>
              <th>Project</th>
              <th>Customer Name.</th>
              <th>Contact No.</th>
              <th>Email Id</th>
              <th>Type</th>
              <th>Unit No.</th>
              <th>Size</th>
              <th>Agreement Value</th>
              <th>Commission %</th>
              <th>Total Revenue</th>
              <th>CashBack %</th>
              <th>Actual Revenue</th>
              <th>Status</th>
              <th>Received Amt.</th>
              <th>Sales Person</th>
              <th>Action</th>
            </tfoot>
          </table>
          <button id="scroll-left"><i class='bx bx-left-arrow-alt'></i></button>
          <button id="scroll-right"><i class='bx bx-right-arrow-alt'></i></button>
        </div>
      </div>
      <!-- Filter Rows Modal Start -->
      <div class="modal fade" tabindex="-1" id="filterModal">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Filter Data</h5>
              <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close" id="closeFilter"></button>
            </div>
            <div class="modal-body">
              <div class="container p-0">
                <div class="row">
                  <!-- Filter inputs -->
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterID" placeholder="ID">
                    <input type="text" class="form-control mb-2" id="filterBookingDate" placeholder="Booking Date">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterMonth" placeholder="Month">
                    <input type="text" class="form-control mb-2" id="filterBuilder" placeholder="Builder Name">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterProject" placeholder="Project Name">
                    <input type="text" class="form-control mb-2" id="filterCustumername" placeholder="Customer Name">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterContactnumber" placeholder="Contact No.">
                    <input type="text" class="form-control mb-2" id="filterEmail" placeholder="Email Id">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterType" placeholder="Unit Type">
                    <input type="text" class="form-control mb-2" id="filterUnit" placeholder="Unit No.">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterSize" placeholder="Unit Size">
                    <input type="text" class="form-control mb-2" id="filterAgreement" placeholder="Agreement Value">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterCommission" placeholder="Commission %">
                    <input type="text" class="form-control mb-2" id="filterTrevenue" placeholder="Total Revenue">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterCashBack" placeholder="CashBack %">
                    <input type="text" class="form-control mb-2" id="filterActualRevenue" placeholder="Actual Revenue">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterReceived" placeholder="Received Amt.">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterStatus" placeholder="Status">
                  </div>
                  <div class="col-md-12">
                    <input type="text" class="form-control mb-2" id="filterSales" placeholder="Sales person">
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <!-- Close Modal button -->
              <button type="button" class="btn btn-secondary" data-dismiss="modal" id="cancleFilter">Close</button>
              <!-- Clear Filters button -->
              <button type="button" class="btn btn-danger" id="clearFiltersBtn">Clear Filters</button>
              <!-- Apply Filters button -->
              <button type="button" class="btn btn-primary" id="applyFiltersBtn">Apply Filters</button>
            </div>
          </div>
        </div>
      </div>
      <!-- filter rows Modal End -->
    </div>
  </div>
</div>
<!--End Main Content -->
<script>
  function applyFilters() {
    var filterInputs = [{
        id: "filterID",
        columnIndex: 0
      },
      {
        id: "filterBookingDate",
        columnIndex: 1
      },
      {
        id: "filterMonth",
        columnIndex: 2
      },
      {
        id: "filterBuilder",
        columnIndex: 3
      },
      {
        id: "filterProject",
        columnIndex: 4
      },
      {
        id: "filterCustumername",
        columnIndex: 5
      },
      {
        id: "filterContactnumber",
        columnIndex: 6
      },
      {
        id: "filterEmail",
        columnIndex: 7
      },
      {
        id: "filterType",
        columnIndex: 8
      },
      {
        id: "filterUnit",
        columnIndex: 9
      },
      {
        id: "filterSize",
        columnIndex: 10
      },
      {
        id: "filterAgreement",
        columnIndex: 11
      },
      {
        id: "filterCommission",
        columnIndex: 12
      },
      {
        id: "filterTrevenue",
        columnIndex: 13
      },
      {
        id: "filterCashBack",
        columnIndex: 14
      },
      {
        id: "filterActualRevenue",
        columnIndex: 15
      },
      {
        id: "filterStatus",
        columnIndex: 16
      },
      {
        id: "filterReceived",
        columnIndex: 17
      },
      {
        id: "filterSales",
        columnIndex: 18
      },
    ];
    activeFilters = [];
    $("#pagedataaas tr").each(function() {
      var row = $(this);
      var showRow = true;
      filterInputs.forEach(function(inputInfo) {
        var input = $("#" + inputInfo.id);
        var filterValue = input.val().toLowerCase();
        var cellValue = row.find("td:eq(" + inputInfo.columnIndex + ")").text().toLowerCase();
        if (cellValue.indexOf(filterValue) === -1) {
          showRow = false;
          return false;
        }
        if (filterValue.trim() !== "") {
          activeFilters.push(filterValue);
        }
      });
      if (showRow) {
        row.addClass("custom-filtered-row");
      } else {
        row.removeClass("custom-filtered-row");
      }
    });
    var totalTotalRevenue = 0;
    var totalActualRevenue = 0;
    var counterRow = 0;
    $(".custom-filtered-row").each(function() {
      var totalRevenue = parseFloat($(this).find("td:eq(13)").text());
      var actualRevenue = parseFloat($(this).find("td:eq(15)").text());
      if (!isNaN(totalRevenue)) {
        totalTotalRevenue += totalRevenue;
        counterRow += 1;
      }
      if (!isNaN(actualRevenue)) {
        totalActualRevenue += actualRevenue;
      }
    });

    $("#counter").text(counterRow);
    $("#totalTotalRevenue").text(totalTotalRevenue.toLocaleString());
    $("#totalActualRevenue").text(totalActualRevenue.toLocaleString());
    $("#pagedataaas tr").hide();
    applyCustomFilter();
  }
  applyCustomFilter();

  function applyCustomFilter() {
    $(".custom-filtered-row").show();
  }
  $(".filterable .btn-filter1").click(function() {
    $("#filterModal").modal("show");
  });
  $("#applyFiltersBtn").click(function() {
    $("#filterModal").modal("hide");
    applyFilters();
  });
  $("#filterModal").on("hidden.bs.modal", function() {
    $(".filterable .filters input").val("");
    applyFilters();
  });
  $("#closeFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $("#cancleFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $(document).ready(function() {
    $("#clearFiltersBtn").click(function() {
      $("#filterID, #filterBookingDate, #filterMonth, #filterBuilder, #filterProject, #filterContactnumber, #filterCustumername, #filterEmail, #filterType, #filterUnit, #filterSize, #filterAgreement, #filterCommission, #filterTrevenue, #filterCashBack, #filterActualRevenue, #filterStatus, #filterReceived, #filterSales").val("");
    });
  });
  $("#clearFiltersBtn").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
</script>
<?php include('htmlclose.php'); ?>