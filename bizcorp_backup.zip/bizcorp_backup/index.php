<?php include 'header.php';?>

	<!-- Slider Area -->
		<section class="slider">
			<div class="hero-sliderrr">
				<!-- Start Single Slider -->
				<div class="single-slider" style="background-image:url('./images/B-1.webp')">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="text">
									<h1>Seamless Expansion for <span> Indian Businesses </span> in the USA</h1>
									<p>
										BizcorpGlobal simplifies your transition from India to the U.S., ensuring compliance and success every step of the way.
									</p>
									<style>
										.text ul li {
											list-style:disc;
											font-weight:500;
										}
										.text p{
											font-weight:500!important;
										}
									</style>
									<ul class="mt-2 pl-3">
										<li>
											Tailored strategies for U.S. market entry
										</li>
										<li>
											Comprehensive compliance support
										</li>
										<li>
											Fast, reliable & Affordable
										</li>
										<li>
											Live experts at your service
										</li>
									</ul>
									<div class="button">
										<a href="#" class="btn" data-toggle="modal" data-target="#consultationModal">Get Free Consultation</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<!-- End Single Slider -->
				<!-- Start Single Slider
				<div class="single-slider" style="background-image:url('./images/B-2.webp')">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="text">
									<h1>Your Partner in Crossing Borders and Achieving <span> Success</span> </h1>
									<p>
										With our expertise, navigate the complexities of U.S. market entry and thrive in your new business landscape.
									</p>
									<div class="button">
										<a href="#" class="btn">Start Your Business Today</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
					Start End Slider -->
				<!-- Start Single Slider
				<div class="single-slider" style="background-image:url('./images/B-3.webp')">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="text">
									<h1> Efficient <span>U.S. Business </span> Filings for Indian Companies</h1>
									<p>
										Transform your vision into a flourishing U.S. enterprise with BizcorpGlobal’s bespoke strategies and compliance support.
									</p>
									<div class="button">
										<a href="#" class="btn">Start Your Business Today</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
					End Single Slider -->
			</div>
		</section>
	<!--/ End Slider Area -->

	<!-- Start Schedule Area 
		<section class="schedule">
			<div class="container">
				<div class="schedule-inner">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-12 ">
							<div class="single-schedule first">
								<div class="inner">
									<div class="icon">
										<i class="fa fa-ambulance"></i>
									</div>
									<div class="single-content">
										<h4>LLC Formations</h4>
										<p>
											An LLC is a business structure offering asset protection like a corporation but with fewer formalities, blending features of corporations and sole proprietorships or partnerships, making it a popular choice for business owners.
											<br> <br>To learn more about LLC business structures, the benefits of forming an LLC, and where to create one, visit our Form an LLC section.
										</p>
										<a href="#">LLC business<i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-12">
							<div class="single-schedule middle">
								<div class="inner">
									<div class="icon">
										<i class="icofont-prescription"></i>
									</div>
									<div class="single-content">
										<h4>Incorporations</h4>
										<p>
											Incorporating a business can be a quick, straightforward, and cost-effective way to start. Explore the benefits of incorporation and understand the various business structures available, such as C Corporations, S Corporations, and more.
											<br> <br>Explore everything you need to know about starting a business in our detailed incorporation section.
										</p>
										<a href="#">Incorporation section<i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	End Start schedule Area -->

	<!-- Start Feautes -->
		<section class="Feautes section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="text-center ">
						<!--<h6>
								 BizCropGlobal streamlines business formation for LLCs, Corporations, Non-Profits, and DBAs. With fast, affordable, and accurate filings, we ensure satisfaction. Start today and bring your business dreams to life!
							</h6>
							<img src="images/section-img.webp" alt="#">-->
							<h2 class="mt-5 mb-4">
								Our Popular Services
							</h2>
							<img src="images/section-img.webp" alt="#">
						</div>
					</div>
				</div>
				<div class="row" style="margin-top:4rem">
					<div class="col-lg-3 col-12">
						<!-- Start Single features -->
						<div class="single-features">
							<div class="signle-icon">
								<img class="icofont-home" src="./new_icon/business_formation_services.png"> </img>
							</div>
							<h3>Business Formation Services</h3>
							<p>"Tailored guidance for Indian companies on U.S. entity selection and documentation."</p>
						</div>
						<!-- End Single features -->
					</div>
					<div class="col-lg-3 col-12">
						<!-- Start Single features -->
						<div class="single-features">
							<div class="signle-icon">
								<img class="icofont-home" src="./new_icon/payrol_tax.png"> </img>
							</div>
							<h3>Payroll Tax Registration Services</h3>
							<p>"Beginning compliance with payroll tax regulations without hassle."</p>
						</div>
						<!-- End Single features -->
					</div>
					<div class="col-lg-3 col-12">
						<!-- Start Single features -->
						<div class="single-features">
							<div class="signle-icon">
								<img class="icofont-home" src="./new_icon/registered_agent.png"> </img>
							</div>
							<h3>Registered Agent Services</h3>
							<p>"Dependable handling of legal documents for your U.S. operations."</p>
						</div>
						<!-- End Single features -->
					</div>
					<div class="col-lg-3 col-12">
						<!-- Start Single features -->
						<div class="single-features last">
							<div class="signle-icon">
								<img class="icofont-home" src="./new_icon/corporate-_compliance.png"> </img>
							</div>
							<h3>Corporate Compliance Solutions</h3>
							<p>"Stay ahead with services adapted to U.S. regulatory requirements."</p>
						</div>
						<!-- End Single features -->
					</div>
				</div>
			</div>
		</section>
	<!--/ End Feautes -->
	
	<!-- Start Fun-facts -->
		<div id="fun-facts" class="fun-facts section overlay">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Fun -->
						<div class="single-fun">
							<img src="./images/Expertguidance.webp" alt="Expertguidance">
							<div class="content">
								<!-- <span class="counter">3468</span> -->
								<p>Expert <br> Guidance </p>
							</div>
						</div>
						<!-- End Single Fun -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Fun -->
						<div class="single-fun">
							<img src="./images/guaranteedsatisfaction.webp" alt="guaranteedsatisfaction">
							<div class="content">
								<!-- <span class="counter">557</span> -->
								<p>Guaranteed <br> Satisfaction
								</p>
							</div>
						</div>
						<!-- End Single Fun -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Fun -->
						<div class="single-fun">
							<img src="./images/transparencyservice.webp" alt="transparencyservice">
							<div class="content">
								<!-- <span class="counter">4379</span> -->
								<p>Transparency In<br> Service</p>
							</div>
						</div>
						<!-- End Single Fun -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Fun -->
						<div class="single-fun">
							<img src="./images/effortlessexperience.webp" alt="effortlessexperience">
							<div class="content">
								<!-- <span class="counter">32</span> -->
								<p>Effortless <br> Experience</p>
							</div>
						</div>
						<!-- End Single Fun -->
					</div>
				</div>
			</div>
		</div>
	<!--/ End Fun-facts -->

	<!-- Start Why choose -->
		<section class="why-choose section" >
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>Your Trusted Ally for U.S. Business Formation and Compliance</h3>
							<p>BizcorpGlobal offers a streamlined approach for Indian businesses aiming to establish a presence in the U.S. Experience transparent pricing, straight forward processes, and unparalleled customer support, all tailored to help you succeed in the U.S. market. Leverage our robust solutions endorsed by professional firms and industry leaders.</p>
							<div class="get-quote">
								<a href="#." type="button" class="btn show-modal" data-toggle="modal" data-target="#consultationModal">Get Free Consultation</a>
							</div>
							<!--<span>
								<h6>Key Points</h6>
							</span>
							// <div class="row">
							// 	<div class="col-lg-6">
							// 		<ul class="list">
							// 			<li><i class="fa fa-caret-right"></i>Trusted partner for entrepreneurs</li>
							// 			<li><i class="fa fa-caret-right"></i>Experienced and professional team</li>
							// 			<li><i class="fa fa-caret-right"></i>Specializing in business formation & compliance</li>
							// 		</ul>
							// 	</div>
							// 	<div class="col-lg-6">
							// 		<ul class="list">
							// 			<li><i class="fa fa-caret-right"></i>Tailored solutions for your business</li>
							// 			<li><i class="fa fa-caret-right"></i>Passionate about empowering business owners</li>
							// 			<li><i class="fa fa-caret-right"></i>Expertise in managing and growing ventures</li>
							// 		</ul>
							// 	</div>
							// </div>-->
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right">
							<!--<div class="video-image">
								Video Animation
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								End Video Animation 
								<a href="https://www.youtube.com/" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>-->
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
	<!--/ End Why choose -->
	
	<!-- Start portfolio
		<section class="portfolio section" >
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>Why Choose BizCropGlobal</h2>
							<img src="images/section-img.webp" alt="#">
							<p>Empowering Your Business Growth with Global Expertise.</p>
						</div>
					</div>
				</div>
			</div>
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-12 col-12">
						<div class="owl-carousel portfolio-slider">
							
							<div class="single-pf">
								<img src="https://plus.unsplash.com/premium_photo-1673491311241-ac5e8a595bd3?q=80&w=1791&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="#">
								<a href="portfolio-details.html" class="btn">View Details</a>
							</div>
							<div class="single-pf">
								<img src="https://images.unsplash.com/photo-1563373270-6f4a70c096b9?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="#">
								<a href="portfolio-details.html" class="btn">View Details</a>
							</div>
							<div class="single-pf">
								<img src="https://images.unsplash.com/photo-1478515940002-d9d96d21e720?q=80&w=1764&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="#">
								<a href="portfolio-details.html" class="btn">View Details</a>
							</div>
							<div class="single-pf">
								<img src="https://images.unsplash.com/photo-1533094509717-c3529dadc51c?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="#">
								<a href="portfolio-details.html" class="btn">View Details</a>
							</div>
							
							<div class="single-pf">
								<img src="https://plus.unsplash.com/premium_photo-1673491311241-ac5e8a595bd3?q=80&w=1791&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="#">
								<a href="portfolio-details.html" class="btn">View Details</a>
							</div>
							<div class="single-pf">
								<img src="https://images.unsplash.com/photo-1533094509717-c3529dadc51c?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="#">
								<a href="portfolio-details.html" class="btn">View Details</a>
							</div>
							<div class="single-pf">
								<img src="https://images.unsplash.com/photo-1478515940002-d9d96d21e720?q=80&w=1764&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="#">
								<a href="portfolio-details.html" class="btn">View Details</a>
							</div>
							<div class="single-pf">
								<img src="https://images.unsplash.com/photo-1533094509717-c3529dadc51c?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="#">
								<a href="portfolio-details.html" class="btn">View Details</a>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</section>
	End portfolio -->
	
	<!-- Start service -->
		<section class="services section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>Popular Business Structures We Help You Create</h2>
							<img src="images/section-img.webp" alt="#">
							<p>Choosing the right structure is crucial for your success in the U.S. Our experts simplify the process of incorporating popular business entities, including</p>
						</div>
					</div>
				</div>
				<style>
					.feature-icon img{
						height: 50px;
						margin-bottom: 10px;
					}
				</style>
				<div class="feature-grid">
					<div class="feature-item">
						<div class="feature-icon">	<img src="./new_icon/sole_proprietorship.png" alt="CheckNameAvailability"> </div>
							<h3 class="feature-title">Sole Proprietorship</h3>
					</div>
					<div class="feature-item">
						<div class="feature-icon">
							<img src="./new_icon/partnership.png" alt="Assign-a-Registered-Agent">
						</div>
							<h3 class="feature-title">Partnership</h3>
					</div>
					<div class="feature-item">
						<!-- Start Single Service -->
						<div class="feature-icon">
							<img src="./new_icon/llp.png" alt="File-Formation-Papers">
							</div>
							<h3 class="feature-title">Limited Liability Partnership (LLP)</h3>	

						<!-- End Single Service -->
					</div>
					<div class="feature-item">
						<!-- Start Single Service -->
						<div class="feature-icon">
							<img src="./new_icon/llc.png" alt="File-BOI-Report">
							</div>
							<h3 class="feature-title">Limited Liability Company (LLC)</h3>

						<!-- End Single Service -->
					</div>
					<div class="feature-item">
						<div class="feature-icon">
							<img src="./new_icon/pllc.png" alt="Get-an-EIN">
							</div>
							<h3 class="feature-title">Professional Limited Liability Company (PLLC)</h3>
					
					</div>
					<div class="feature-item">
						<div class="feature-icon">
							<img src="./new_icon/c_corporation.png" alt="Acquire-Licenses-Permits">
							</div>
							<h3 class="feature-title">C Corporation</h3>
				
					</div>
					<div class="feature-item">
						<!-- Start Single Service -->
						<div class="feature-icon">
							<img src="./new_icon/s_corporation.png" alt="Register-for-Payroll-Taxes">
							</div>
							<h3 class="feature-title">S Corporation</h3>
					
						<!-- End Single Service -->
					</div>
					<div class="feature-item">
						<!-- Start Single Service -->
						<div class="feature-icon">
							<img src="./new_icon/professional_corporation.png" alt="Maintain-Compliance">
							</div>
							<h3 class="feature-title">Professional Corporation</h3>
					
						<!-- End Single Service -->
					</div>
					<div class="feature-item mx-auto">
						<!-- Start Single Service -->
						<div class="feature-icon">
							<img src="./new_icon/nonprofi.png" alt="Maintain-Compliance">
							</div>
							<h3 class="feature-title">Nonprofit Corporation</h3>
					
						<!-- End Single Service -->
					</div>
				</div>
			</div>
		</section>
	<!--/ End service -->
	
	<!-- Pricing Table -->
	<!-- <section class="pricing-table section">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title">
						<h2>Pricing</h2>
						<img src="images/section-img.webp" alt="#">
						<p>Transparent Pricing, Tailored for Your Business Success!</p>
					</div>
				</div>
			</div>
			<div class="row">
				
				<div class="col-lg-4 col-md-12 col-12">
					<div class="single-table">
						
						<div class="table-head">
							<div class="icon">
								<i class="icofont icofont-eye-alt"></i>
							</div>
							<h4 class="title">Lorem ipsum</h4>
							<div class="price">
								<p class="amount">$199<span>/ Per Visit</span></p>
							</div>	
						</div>
						
						<ul class="table-list">
							<li><i class="icofont icofont-ui-check"></i>Lorem ipsum dolor sit</li>
							<li><i class="icofont icofont-ui-check"></i>Cubitur sollicitudin fentum</li>
							<li class="cross"><i class="icofont icofont-ui-close"></i>Nullam interdum enim</li>
							<li class="cross"><i class="icofont icofont-ui-close"></i>Donec ultricies metus</li>
							<li class="cross"><i class="icofont icofont-ui-close"></i>Pellentesque eget nibh</li>
						</ul>
						<div class="table-bottom">
							<a class="btn" href="#" data-toggle="modal" data-target="#BizcorpModal">View Now</a>
						</div>
						
					</div>
				</div>
				
				
				<div class="col-lg-4 col-md-12 col-12">
					<div class="single-table">
						
						<div class="table-head">
							<div class="icon">
								<i class="icofont icofont-eye-alt"></i>
							</div>
							<h4 class="title">Lorem ipsum</h4>
							<div class="price">
								<p class="amount">$299<span>/ Per Visit</span></p>
							</div>	
						</div>
						
						<ul class="table-list">
							<li><i class="icofont icofont-ui-check"></i>Lorem ipsum dolor sit</li>
							<li><i class="icofont icofont-ui-check"></i>Cubitur sollicitudin fentum</li>
							<li><i class="icofont icofont-ui-check"></i>Nullam interdum enim</li>
							<li class="cross"><i class="icofont icofont-ui-close"></i>Donec ultricies metus</li>
							<li class="cross"><i class="icofont icofont-ui-close"></i>Pellentesque eget nibh</li>
						</ul>
						<div class="table-bottom">
							<a class="btn" href="#" data-toggle="modal" data-target="#BizcorpModal">View Now</a>
						</div>
						
					</div>
				</div>
				
				
				<div class="col-lg-4 col-md-12 col-12">
					<div class="single-table">
						
						<div class="table-head">
							<div class="icon">
								<i class="icofont icofont-eye-alt"></i>
							</div>
							<h4 class="title">Lorem ipsum</h4>
							<div class="price">
								<p class="amount">$399<span>/ Per Visit</span></p>
							</div>	
						</div>
						
						<ul class="table-list">
							<li><i class="icofont icofont-ui-check"></i>Lorem ipsum dolor sit</li>
							<li><i class="icofont icofont-ui-check"></i>Cubitur sollicitudin fentum</li>
							<li><i class="icofont icofont-ui-check"></i>Nullam interdum enim</li>
							<li><i class="icofont icofont-ui-check"></i>Donec ultricies metus</li>
							<li><i class="icofont icofont-ui-check"></i>Pellentesque eget nibh</li>
						</ul>
						<div class="table-bottom">
							<a class="btn" href="#" data-toggle="modal" data-target="#BizcorpModal">View Now</a>
						</div>
						
					</div>
				</div>
				
			</div>	
		</div>	
		</section>	 -->
	<!--/ End Pricing Table -->

    <section class="whychoose">
	 	<div class="container">
			<section class="bizcorp-showcase">
				<div class="showcase-header">
					<h1 class="showcase-title">Why Choose BizcorpGlobal?</h1>
					<p class="showcase-subtitle">Your Gateway to U.S. Business Success</p>
				</div>
				<div class="feature-grid">
					<div class="feature-item">
						<div class="feature-icon">
						<img class="icofont-home" src="./new_icon/expert_support.png"> </img>
						</div>
						<h3 class="feature-title">Expert Support</h3>
						<p class="feature-description">Professional guidance to ensure a smooth U.S. business setup and compliance journey.</p>
					</div>
					<div class="feature-item">
						<div class="feature-icon">
						<img class="icofont-home" src="./new_icon/effortless_process.png"> </img>
						</div>
						<h3 class="feature-title">Effortless Process</h3>
						<p class="feature-description">Simplified solutions tailored for Indian companies moving into the U.S. market.</p>
					</div>
					<div class="feature-item">
						<div class="feature-icon">
						<img class="icofont-home" src="./new_icon/guaranteed_peace.png"> </img>
						</div>
						<h3 class="feature-title">Guaranteed Peace of Mind</h3>
						<p class="feature-description">Reliable services ensure your business remains compliant.</p>
					</div>
				</div>
				<div class="action-section">
					<h2 class="action-title">Get Started with Confidence</h2>
					<p class="action-description">Don't tackle U.S. business complexities alone. Contact us today for expert assistance in determining the right structure to meet your business objectives. Let BizcorpGlobal empower your U.S. expansion for enduring success!</p>
					<a href="https://api.geteliv8.com/widget/bookings/bcg-free-consultation" class="action-button">Get Free Consultation</a>
				</div>
			</section>
    	</div>
	</section>

	<!-- Start Call to action 
	<section class="call-action overlay" data-stellar-background-ratio="0.5">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-12">
					<div class="content">
						<h2>Get Started with Confidence</h2>
						<p>Our advanced technology and expert support ensures your business filing needs are met. Depending on your service tier, you'll have access to dedicated professionals 24/7 via phone, text, and email.</p>
						<div class="button">
							<a href="#." type="button" class="btn btn-primary btn-lg show-modal" data-toggle="modal" data-target="#BizcorpModal">Get Started Today !</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	End Call to action -->

	<!-- Start Blog Area -->
		<section class="blog section" id="blog">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>Expert Insights</h2>
							<img src="images/section-img.webp" alt="#">
							<p>Access expert insights to build and expand your business effectively in the U.S.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Single Blog -->
						<a href="insights.php">
							<div class="single-news">
								<div class="news-head">
									<img src="./images/choose_buisness_blog.webp" alt="#">
								</div>
								<div class="news-body">
									<div class="news-content">
										<div class="date">20-12-2024</div>
										<h2>Choosing a Business <br> Structure</h2>
										<p class="text">Selecting the right structure affects taxes, liability, and business operations; important for long-term success.</p>
									</div>
								</div>
							</div>
						</a>
						<!-- End Single Blog -->
					</div>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Single Blog -->
						<a href="insights.php">
							<div class="single-news">
								<div class="news-head">
									<img src="./images/freelance_blog.webp" alt="#">
								</div>
								<div class="news-body">
									<div class="news-content">
										<div class="date">20-12-2024</div>
										<h2>How to Start a Freelance Business</h2>
										<p class="text">Begin with a clear niche, register your business, set pricing, and market your skills effectively to clients.</p>
									</div>
								</div>
							</div>
						</a>
						<!-- End Single Blog -->
					</div>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Single Blog -->
						<a href="insights.php">
							<div class="single-news">
								<div class="news-head">
									<img src="./images/llc_blog.webp" alt="#">
								</div>
								<div class="news-body">
									<div class="news-content">
										<div class="date">20-12-2024</div>
										<h2>LLCs and S Corporations.</h2>
										<p class="text">LLCs offer personal liability protection and flexible tax options, while S Corporations allow tax advantages by passing profits and losses to shareholders.</p>
									</div>
								</div>
							</div>
						</a>
						<!-- End Single Blog -->
					</div>
				</div>
			</div>
		</section>
	<!-- End Blog Area -->
	
	<!-- Start clients 
		<div class="clients overlay">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h1 class="text-white">Join our network of successful Indian businesses thriving in the U.S.</h1>
						</div>
					</div>
				</div>
				
					<div class="row">
						<div class="col-lg-12 col-md-12 col-12">
							<div class="owl-carousel clients-slider">
								<div class="single-clients">
									<img src="https://static.vecteezy.com/system/resources/previews/008/989/031/non_2x/letter-d-logo-vector.jpg" alt="#">
								</div>
								<div class="single-clients">
									<img src="https://static.vecteezy.com/system/resources/previews/008/989/031/non_2x/letter-d-logo-vector.jpg" alt="#">
								</div>
								<div class="single-clients">
									<img src="https://static.vecteezy.com/system/resources/previews/008/989/031/non_2x/letter-d-logo-vector.jpg" alt="#">
								</div>
								<div class="single-clients">
									<img src="https://static.vecteezy.com/system/resources/previews/008/989/031/non_2x/letter-d-logo-vector.jpg" alt="#">
								</div>
								<div class="single-clients">
									<img src="https://static.vecteezy.com/system/resources/previews/008/989/031/non_2x/letter-d-logo-vector.jpg" alt="#">
								</div>
								<div class="single-clients">
									<img src="https://static.vecteezy.com/system/resources/previews/008/989/031/non_2x/letter-d-logo-vector.jpg" alt="#">
								</div>
								<div class="single-clients">
									<img src="https://static.vecteezy.com/system/resources/previews/008/989/031/non_2x/letter-d-logo-vector.jpg" alt="#">
								</div>
								<div class="single-clients">
									<img src="https://static.vecteezy.com/system/resources/previews/008/989/031/non_2x/letter-d-logo-vector.jpg" alt="#">
								</div>
								<div class="single-clients">
									<img src="https://static.vecteezy.com/system/resources/previews/008/989/031/non_2x/letter-d-logo-vector.jpg" alt="#">
								</div>
							</div>
						</div>
					</div>
				
			</div>
		</div>
Ens clients -->

	<style>
		:root {
            --primary-color: #2c3e50;
            --secondary-color: #e74c3c;
            --accent-color: #f39c12;
            --text-color: #333;
            --bg-color: #ecf0f1;
        }
		.bizcorp-showcase {
            position: relative;
            background-color: #fff;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .showcase-header {
            background-color: #3c6bb6;
            padding: 40px 20px;
            text-align: center;
            clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
        }

        .showcase-header h1,.showcase-header p{
            color: #fff;
        }

        .showcase-title {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .showcase-subtitle {
            font-size: 1.1em;
            opacity: 0.9;
        }

        .feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            padding: 60px 30px;
        }

        .feature-item {
			box-shadow: 0px 0px 2px 0px #938b8b;
            background-color: #fff;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .feature-item::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, var(--accent-color) 0%, transparent 70%);
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: 1;
        }

        .feature-item:hover::before {
            opacity: 0.1;
        }

        .feature-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }

        .feature-icon {
            font-size: 3em;
            color: var(--secondary-color);
            margin-bottom: 20px;
            position: relative;
            z-index: 2;
        }

        .feature-title {
            font-size: 1.5em;
            margin-bottom: 15px;
            color: var(--primary-color);
            position: relative;
            z-index: 2;
        }

        .feature-description {
            font-size: 1em;
            color: var(--text-color);
            position: relative;
            z-index: 2;
        }

        .action-section {
            background-color: #3c6bb6;
            padding: 60px 30px;
            text-align: center;
            clip-path: polygon(0 15%, 100% 0, 100% 100%, 0 100%);
        }

        .action-title {
            font-size: 2em;
            color: #fff;
            margin-bottom: 20px;
        }

        .action-description {
            font-size: 1.1em;
            color: rgba(255, 255, 255, 0.9);
            max-width: 800px;
            margin: 0 auto 30px;
        }

        .action-button {
            display: inline-block;
            background-color: var(--accent-color);
            color: #000!important;
            padding: 15px 30px;
            border-radius: 50px;
            font-size: 1.1em;
            font-weight: 600;
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.3s ease;
            text-transform: uppercase;
        }

        .action-button:hover {
            background-color: #e67e22;
            transform: scale(1.05);
        }

        @media (max-width: 768px) {
            .showcase-header,
            .action-section {
                clip-path: none;
            }
        }
		.benefit-item h3{
			font-size: 23px;
    		margin-bottom: 13px;
		}

		 /* .network-section {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 40px;
        } 
         .network-section h1 {
            color: #1a5f7a;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5em;
        }*/
        .benefits {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin-bottom: 40px;
        }
        .benefit-item {
            flex-basis: calc(33.333% - 20px);
            text-align: center;
            margin-bottom: 20px;
            padding: 20px;
            background-color: #f8f8f8;
            border-radius: 8px;
            transition: transform 0.3s ease;
        }
        .benefit-item:hover {
            transform: translateY(-5px);
        }
        .benefit-item i {
            font-size: 2em;
            color: #1a5f7a;
            margin-bottom: 10px;
        }
        .stats {
            display: flex;
            justify-content: space-around;
            margin-bottom: 40px;
        }
        .stat-item {
            text-align: center;
        }
        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #1a5f7a;
            margin-bottom: 10px;
        }
        .cta-form {
            background-color: #1a5f7a;
            color: #fff;
            padding: 30px;
            border-radius: 8px;
        }
        .cta-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
        }
        .submit-btn {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #ffd700;
            color: #1a5f7a;
            border: none;
            border-radius: 4px;
            font-size: 1.1em;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .submit-btn:hover {
            background-color: #ffed4a;
        }
		._builder-form{
			padding:0px;
		}
        @media (max-width: 768px) {
            .benefit-item {
                flex-basis: 100%;
            }
            .stats {
                flex-direction: column;
            }
            .stat-item {
                margin-bottom: 20px;
            }
        }
    </style>
	
	<!--join our network
	<section class="joinus section">
		<div class="container">
			<section class="network-section">
				<h1>Join our network of successful Indian businesses thriving in the U.S.</h1>
			</section>
		</div>
	</section>
	Ens join our network -->

	<!-- Start Consultation -->
	<section class="Consultation">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title">
						<h2>Get in Touch and Start Your U.S. Business Today!</h2>
						<img src="images/section-img.webp" alt="#">
						<p>Reach out to us and start your business today!</p>
						<div class="get-quote mt-5">
							<a href="#." type="button" class="btn show-modal" data-toggle="modal" data-target="#consultationModal">Get Free Consultation</a>
						</div>
					</div>
					
				</div>
			</div>
			<!-- <div class="row">
				<div class="col-lg-6 col-md-12 col-12">
					<form class="form" action="mail.php" method="post">
						<div class="row">
							<div class="col-lg-12 col-md-6 col-12">
								<div class="form-group">
									<input name="name" class="form-control" type="text" placeholder="Name">
								</div>
							</div>
							<div class="col-lg-12 col-md-6 col-12">
								<div class="form-group">
									<input name="email" class="form-control" type="email" placeholder="Email">
								</div>
							</div>
							<div class="col-lg-12 col-md-6 col-12">
								<div class="form-group">
									<input name="phone" class="form-control" type="text" placeholder="Phone">
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-12">
								<div class="form-group">
									<textarea name="message" class="form-control" placeholder="Write Your Message Here....."></textarea>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-5 col-md-4 col-12">
								<div class="form-group">
									<div class="button">
										<button type="submit" name="submit" class="btn">Book An Consultation</button>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
				<div class="col-lg-6 col-md-12 ">
					<div class="Consultation-image">
						<img src="./images/getintouch.webp" alt="#">
					</div>
				</div>
			</div>-->
		</div>
	</section>
	<!-- End Consultation -->
	 
<?php include 'footer.php';?>