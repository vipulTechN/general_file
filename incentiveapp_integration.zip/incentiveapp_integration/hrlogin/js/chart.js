google.charts.load("current", { packages: ["corechart"] });
google.charts.load("current", { packages: ["bar"] });

google.charts.setOnLoadCallback(drawChart);
google.charts.setOnLoadCallback(drawBar);

var piechartdata = [
  ['Year', 'Received', 'Processing', 'Cancel'],
  ['2022', 500, 300, 200],
  ['2023', 900, 200, 400],
  ['2024', 1100, 600, 300]
];

function drawChart() {

  var data = google.visualization.arrayToDataTable([
    ['Task', 'Hours per Day'],
    ['Work',     11],
    ['Eat',      2],
    ['Commute',  2],
    ['Watch TV', 2],
    ['Sleep',    7]
  ]);

  var options = {
    title: 'My Daily Activities'
  };

  var chart = new google.visualization.PieChart(document.getElementById('barchart_material'));

  chart.draw(data, options);
}

function drawBar() {
  var data = google.visualization.arrayToDataTable([
    ["Year", "Processing", "Received", "Cancelled"],
    ["2014", 1000, 400, 300],
    ["2015", 1170, 460, 250],
    ["2016", 660, 1120, 300],
    ["2017", 1030, 540, 350],
    ["2014", 1000, 400, 200],
    ["2015", 1170, 460, 250],
    ["2016", 660, 1120, 300],
    ["2017", 1030, 540, 350],
  ]);

  var options = {
    chart: {
      title: "Company Performance",
      subtitle: "Sales, Expenses, and Profit: 2014-2017",
    },
    bars: "vertical", // Required for Material Bar Charts.
  };

  var chart = new google.charts.Bar(
    document.getElementById("chart_line")
  );

  chart.draw(data, google.charts.Bar.convertOptions(options));
}