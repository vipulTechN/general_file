
  function openForm() {
    document.querySelector(".careerform").style.display = "block";
  }
  
  function closeForm() {
    document.querySelector(".careerform").style.display = "none";
  }

  var swiper = new Swiper(".mySwiper16", {
    effect: "coverflow",
    grabCursor: true,
    autoplay: {
      delay: 2500,
      disableOnInteraction: false,
    },
    centeredSlides: true,
    loop:true,
    spaceBetween: 40,
    slidesPerView: "auto",
    coverflowEffect: {
      rotate: 30,
      stretch: 0,
      depth: 50,
      modifier: 1,
      slideShadows: true,
    },
    pagination: {
      el: ".swiper-pagination",
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
