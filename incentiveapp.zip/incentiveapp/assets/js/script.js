new DataTable('#example', {
  scrollX: true,

});
const table = new DataTable('#example');
 
table.on('click', 'tbody tr', function (e) {
    e.currentTarget.classList.toggle('selected');
});
var sidemenuContainer = document.getElementById("side-menu");
var sidemenuli = sidemenuContainer.getElementsByClassName("sidemenuli");
for (var i = 0; i < sidemenuli.length; i++) {
  sidemenuli[i].addEventListener("click", function () {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}

var menuBar = document.querySelector(".sidebarbutt");
var sideBar = document.querySelector(".sidebar");

function toggleleftsidebar() {
  sideBar.classList.toggle("close");
}

var rightsidebar = document.querySelector("#rightsidebar");
var togglerightsidebar = document.querySelector("#togglerightsidebar");
var closebtnbar = document.querySelector("#close-btn");

togglerightsidebar.addEventListener("click", function () {
   rightsidebar.style.display="block";
});

closebtnbar.addEventListener("click", function () {
    rightsidebar.style.display="none";
 });
 
 function openSearchPopup() {
  var searchPopup = document.getElementById('search-popup');
  searchPopup.style.display = 'block';
}

function closeSearchPopup() {
  var searchPopup = document.getElementById('search-popup');
  searchPopup.style.display = 'none';
}

var toggler = document.getElementById("theme-toggle");

toggler.addEventListener("change", function () {
  if (this.checked) {
    document.body.classList.add("dark");
    document.body.style.color = "white";
    document.querySelector(".content").add("dark");
    
  } else {
    document.body.classList.remove("dark");
    document.body.style.color = "black";
  }
});

var dropcontContainer = document.getElementById("logincont");
var dropcontli = dropcontContainer.getElementsByClassName("logincontli");
for (var i = 0; i < dropcontli.length; i++) {
  dropcontli[i].addEventListener("click", function () {
    var current = document.getElementsByClassName("loginact");
    current[0].className = current[0].className.replace(" loginact", "");
    this.className += " loginact";
  });
}
var statuscontContainer = document.getElementById("statuscont");
var statuscontli = statuscontContainer.getElementsByClassName("statuscontli");
for (var i = 0; i < statuscontli.length; i++) {
  statuscontli[i].addEventListener("click", function () {
    var current = document.getElementsByClassName("statusact");
    current[0].className = current[0].className.replace(" statusact", "");
    this.className += " statusact";
  });
}

var morenotif = document.querySelector("#more_notif_btn");
var notifcontent = document.querySelector("#notif-content_box");
var morenotificon = document.querySelector("#more_notif_icon");
var moreprofileicon = document.querySelector("#more_profile_icon");
var profilecontent = document.querySelector("#profile-content_box");
var closebtn = document.querySelector(".closebtn");
var closebtn1 = document.querySelector(".closebtn1");

morenotificon.addEventListener("click", () => {
  notifcontent.style.display =
    notifcontent.style.display === "block" ? "none" : "block";
  profilecontent.style.display = "none";
});

closebtn.addEventListener("click", () => {
  profilecontent.style.display = "none";
  notifcontent.style.display = "none";
});

closebtn1.addEventListener("click", function () {
  profilecontent.style.display = "none";
});

moreprofileicon.addEventListener("click", () => {
  profilecontent.style.display =
    profilecontent.style.display === "block" ? "none" : "block";
  notifcontent.style.display = "none";
});

var originalDisplay = {};

window.onload = function() {
  var ul = document.getElementById('optionul');
  var li = ul.getElementsByClassName('optionli');
  for (var i = 0; i < li.length; i++) {
    originalDisplay[i] = li[i].style.display;
    li[i].style.display = 'none';
  }
}

function filterOptions() {
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById('searchInput');
  filter = input.value.toUpperCase();
  ul = document.getElementById('optionul');
  li = ul.getElementsByClassName('optionli');

  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName('a')[0];
    txtValue = a.textContent || a.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = originalDisplay[i];
    } else {
      li[i].style.display = 'none';
    }
  }
  
  if (filter === '') {
    for (i = 0; i < li.length; i++) {
      li[i].style.display = 'none';
    }
  }
}
