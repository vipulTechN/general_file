// this js is for audio search
const startButton = document.getElementById('startButton');
    const searchInput = document.getElementById('searchInput');

    let recognition = new webkitSpeechRecognition() || new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US'; // Set the language for speech recognition

    recognition.onresult = function(event) {
      const result = event.results[event.results.length - 1];
      const transcript = result[0].transcript;
      searchInput.value = transcript; // Input the recognized speech into the search input
    };

    recognition.onend = function() {
      startButton.textContent = '....';
    };

    startButton.addEventListener('click', function() {
      if (recognition.running) {
        recognition.stop();
        startButton.textContent = '....';
      } else {
        recognition.start();
        startButton.textContent = '...';
        searchInput.value = 'Listening...';
      }
    });
// this  script is for right sice nav bar
$(document).ready(function () {
    $(window).scroll(function () {
      var scrollY = $(window).scrollTop();
      if (scrollY > 0) {  
        $(".propdetail-right").css("top","75px");
        $(".propdetail-right").css("position", "sticky");
      } 
      if (scrollY >= 900) {  
        $(".propdetail-right").css("top", "130px");
      }
      else if (scrollY >= 2500) {  
        $(".propdetail-right").css("position", "sticky");
      }
    else{
      $(".propdetail-right").css("display", "flow");
          }
    });
  });
// this script is for keep selected city 
$(document).ready(function() {
    // Get the initial selected value
    const initialVal = $('select[name="project_city"]').val();

    // Set the initial value for all dropdowns with the same data-target
    $('select[name="project_city"]').each(function() {
        const target = $(this).data('target');
        $('select[name="project_city"][data-target="' + target + '"]').val(initialVal);
    });

    // Update other dropdowns when a dropdown changes
    $('select[name="project_city"]').change(function() {
        const currentVal = $(this).val();
        const target = $(this).data('target');
        $('select[name="project_city"][data-target="' + target + '"]').val(currentVal);
    });
});
//   this script is for filter home page as per city 
function submitForm2() {
    const propertyType = document.getElementById('propertyType1').value;
    const city = document.getElementById('city1').value;
    const query = document.getElementById('searchInput1').value;

    if (city === '' || city === 'allindia') {

      return false; // Prevent form submission

    } else {

        const trimmedCity = city.replace(/^\/|\/$/g, '');
        const form = document.getElementById('SearchForm1');
        form.action = `/${propertyType}/${trimmedCity}/`;
        return true; // Allow form submission
    }

    // const form = document.getElementById('SearchForm1');
    // form.action = `/${propertyType}/${city}/`;
    // form.submit();
}
function submitForm3() {
    const propertyType = document.getElementById('propertyType2').value;
    const city = document.getElementById('city2').value;
    const query = document.getElementById('searchInput2').value;

    if (city === '' || city === 'allindia') {

      return false; // Prevent form submission

      } else {

        const trimmedCity = city.replace(/^\/|\/$/g, '');
        const form = document.getElementById('SearchForm2');
        form.action = `/${propertyType}/${trimmedCity}/`;
        return true; // Allow form submission
      }

    // const form = document.getElementById('SearchForm2');
    // form.action = `/${propertyType}/${city}/`;
    // form.submit();
}
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('city1').addEventListener('change', function() {
        const selectedCityUrl = this.value;

        // Save the selected city in localStorage
        localStorage.setItem('selectedCity', selectedCityUrl);

        // Redirect to the selected city's listings page
        if (selectedCityUrl) {
            window.location.href = selectedCityUrl;
        } else {
            // Redirect to the "All India" page
            window.location.href = '{% url "city_listings" "allindia" %}';
        }
    });

    // Retrieve and set the selected city from localStorage
    const storedCity = localStorage.getItem('selectedCity');
    if (storedCity) {
        document.getElementById('city1').value = storedCity;
    }
});
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('city2').addEventListener('change', function() {
        const selectedCityUrl = this.value;

        // Save the selected city in localStorage
        localStorage.setItem('selectedCity', selectedCityUrl);

        // Redirect to the selected city's listings page
        if (selectedCityUrl) {
            window.location.href = selectedCityUrl;
        } else {
            // Redirect to the "All India" page
            window.location.href = '{% url "city_listings" "allindia" %}';
        }
    });

    // Retrieve and set the selected city from localStorage
    const storedCity = localStorage.getItem('selectedCity');
    if (storedCity) {
        document.getElementById('city2').value = storedCity;
    }
});
// this script is for keep selected property type
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('propertyType1').addEventListener('change', function() {
        const selectedCityUrl = this.value;

        // Save the selected city in localStorage
        localStorage.setItem('selectedCity44', selectedCityUrl);
    });

    // Retrieve and set the selected city from localStorage
    const storedCity = localStorage.getItem('selectedCity44');
    if (storedCity) {
        document.getElementById('propertyType1').value = storedCity;
    }
});
function selectPropertyType(value) {
    document.getElementById('propertyType2').value = value;
  }
  function selectPropertyTypen(value) {
    document.getElementById('propertyType3').value = value;
  }

// this Json script is for auto suggestion
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOMContentLoaded event fired');
    const searchInput = document.getElementById('searchInput1');
    const propertyTypeDropdown = document.getElementById('propertyType1');
    const cityDropdown = document.getElementById('city1');
    const suggestionsDatalist = document.getElementById('suggestionsDropdown');
    console.log(searchInput, propertyTypeDropdown, cityDropdown, suggestionsDatalist);

    searchInput.addEventListener('input', function() {
        const query = this.value;
        const rPropertyType = propertyTypeDropdown.value;
        const projectCity = cityDropdown.value;

        // Make an AJAX request to get autosuggestions
        fetch(`/get_autosuggestions/?query=${encodeURIComponent(query)}&r_property_type=${encodeURIComponent(rPropertyType)}&project_city=${encodeURIComponent(projectCity)}`, {
              headers: {
                  'Accept': 'application/json',
              },
          })
          .then(response => {
              console.log('Response status:', response.status);
              return response.json();
          })
            .then(data => {
              console.log('Data received:', data);
                // Clear previous suggestions
            if (data && data.suggestions) {
                suggestionsDatalist.innerHTML = '';

                // Update suggestions dropdown with the received suggestions
                data.suggestions.forEach(suggestion => {
                    const option = document.createElement('option');
                    option.value = suggestion;
                    suggestionsDatalist.appendChild(option);
                });
              } else {
                  console.error('Invalid JSON structure in response:', data);
              }
            })
            .catch(error => console.error('Error fetching autosuggestions:', error));
    });
});