<?php include 'header.php';?>
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
  <link href="css/services.css" rel="stylesheet"/>
  <style>
  .headerul li,.lead ul li{list-style:disc}.section-header{text-align:center;margin-bottom:4rem;max-width:800px;margin-left:auto;margin-right:auto}.subtitle{font-size:1.25rem;color:#4a5568;max-width:700px;margin:0 auto}.checklist-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:2rem}.checklist-item{background:#fff;border-radius:1rem;padding:2rem;box-shadow:0 4px 6px rgba(0,0,0,.05);transition:transform .3s,box-shadow .3s;position:relative;overflow:hidden;animation:.5s ease-out forwards fadeIn;animation-delay:calc(var(--animation-order) * .1s);opacity:0}.checklist-item:hover{transform:translateY(-5px);box-shadow:0 8px 15px rgba(0,0,0,.1)}.checklist-item::before{content:'';position:absolute;top:0;left:0;width:4px;height:100%;background:#4299e1;opacity:.7}.step-number{position:absolute;top:1rem;right:1rem;background:#ebf4ff;color:#4299e1;width:2.5rem;height:2.5rem;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.1rem}.checklist-item h3{color:#2b6cb0;font-size:1.25rem;margin-bottom:1rem;padding-right:3rem;font-weight:600}.checklist-item p{color:#4a5568;font-size:1rem;margin:0}@keyframes fadeIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}.headerul,.lead ul{padding-left:2rem}.tabs{display:flex;gap:1rem;margin-bottom:2rem}.tab-button{padding:10px 20px;font-size:1.1rem;border:none;background-color:#e0e0e0;color:#333;cursor:pointer;border-radius:8px;transition:.3s;font-weight:500}.tab-button:hover{background-color:#d0d0d0}.tab-button.active{background-color:#3498db;color:#fff}.business-services .tab-content{display:none}.business-services .tab-content.active{display:block}.business-services .service-card{background-color:#fff;padding:2rem;border-radius:8px;box-shadow:0 2px 15px rgba(0,0,0,.1)}.business-services h2{color:#2c3e50;margin-bottom:1.5rem;font-size:1.8rem;position:relative;padding-bottom:.5rem}.business-services h2::after{content:'';position:absolute;left:0;bottom:0;width:50px;height:3px;background-color:#3498db}.business-services p{margin-bottom:1rem;color:#666}.business-services p:last-child{margin-bottom:0}@media (max-width:768px){.checklist-section{padding:3rem 0}.checklist-grid{grid-template-columns:1fr;gap:1.5rem}.subtitle{font-size:1.1rem}.checklist-item{padding:1.5rem}.business-services{padding:2rem 1rem}.tabs{flex-direction:column;gap:.5rem}.tab-button{width:100%}}.lead ul li{font-size:14px;font-weight:500}
 .about-2 .content-title,.stats .content-title,.services-2 .content-subtitle,.services-2 .content-title,.service-contents h4 {
    font-weight:600;
}
  </style>
<main class="main">
  <!-- About Section -->
  <section id="about" class="about section">
    <div class="container">
      <div class="row align-items-center justify-content-between">
        <div class="col-lg-6 mb-5 mb-lg-0 order-lg-2"  >
          <div class="swiper init-swiper">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <img src="./images/syb-first-img.webp" alt="Image" class="img-fluid">
              </div>
            </div>
            <div class="swiper-pagination"></div>
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <!-- <span class="section-subtitle" >Welcome</span> -->
          <h1 class="mb-4">
          Start Your Business Hassle-Free in the U.S. with BizCorpGlobal
          </h1>
          <p class="text-justify">
          From LLCs and corporations to Non-Profits, Our Experts Handle Your Paperwork Quickly, Affordably, and with a 100% Satisfaction Guarantee!
          </p>
          <ul class="headerul">
            <li>Tailored Solutions for U.S. market entry</li>
            <li> Fast & Affordable</li>
            <li>Guaranteed Satisfaction</li>
          </ul>
          <p class="mt-5" >
            <a href="https://mktg.bizcorpglobal.com/bsw-survey-page" class="btn btn-get-started">Get Started</a>
          </p>
        </div>
      </div>
    </div>
  </section><!-- /About Section -->

  <!-- About 2 Section -->
  <section id="about-2" class="about-2 section light-background">

    <div class="container">
      <div class="content">
        <div class="row justify-content-center">
        <div class="col-lg-6" >
            <div class="px-3">
              <h2 class="content-title text-start">
              Select the Right Business Structure for Your Success
              </h2>
              <p class="lead">
              Choosing the right business structure is crucial for managing liability and taxes. Use the BizCorpGlobal Business Structure Wizard, designed by experts, to find the best option for your business needs.
              </p>
             <div class="tabs">
                      <button class="tab-button active" data-tab="llc">LLC Formations</button>
                      <button class="tab-button" data-tab="inc">Incorporations</button>
                  </div>
            </div>
          </div>
        <div class="col-lg-6">
              <div class="business-services">
                  <div class="tab-content active" id="llc">
                      <div class="service-card">
                          <h2>LLC Formations</h2>
                          <p>An LLC is a business structure that offers asset protection like a corporation but with fewer formalities. It blends features of corporations and sole proprietorships or partnerships, making it a popular choice for business owners.</p>
                          <p>To learn more about <a href="llc_business">LLC business </a> structures, the benefits of forming an LLC, and where to create one, visit our Form an LLC section.</p>
                      </div>
                  </div>

                  <div class="tab-content" id="inc">
                      <div class="service-card">
                          <h2>Incorporations</h2>
                          <p>Incorporating a business can be a quick, straightforward, and cost-effective way to start. Explore the benefits of incorporation and understand the various business structures available, such as C Corporations, S Corporations, and more.</p>
                          <p>Explore everything you need to know about starting a business in our detailed <a href="incorporation_section">incorporation section</a>.</p>
                      </div>
                  </div>
              </div>
          </div>

         
        </div>
      </div>
    </div>
  </section><!-- /About 2 Section -->

  <!-- Services Section -->
  <section id="services" class="services section light-background">
        <div class="container">
            <header class="section-header">
                <h1>Starting a Business Checklist</h1>
                <p class="subtitle">The BizCorpGlobal Checklist offers expert insights on business naming, structure selection, tax ID registration, and more in one comprehensive guide.</p>
            </header>

            <div class="checklist-grid">
                <div class="checklist-item">
                    <span class="step-number">1</span>
                    <h3>Verify Name Availability</h3>
                    <p>Before launching your business, select a unique name. Conduct a thorough search to ensure the name isn't already used, avoiding potential legal conflicts.</p>
                </div>

                <div class="checklist-item">
                    <span class="step-number">2</span>
                    <h3>Designate a Registered Agent</h3>
                    <p>Appoint a registered agent to receive legal notices on behalf of your company. This individual or service must reside in the state where your business is incorporated.</p>
                </div>

                <div class="checklist-item">
                    <span class="step-number">3</span>
                    <h3>Submit Formation Documents</h3>
                    <p>Choose the appropriate legal structure for your business, such as an LLC, C Corporation, S Corporation, or sole proprietorship, and file the necessary formation documents with the state.</p>
                </div>

                <div class="checklist-item">
                    <span class="step-number">4</span>
                    <h3>File Beneficial Ownership Information (BOI) Report</h3>
                    <p>Businesses established on or after January 1, 2024, must file a BOI report within 90 days of formation. This applies to both domestic and foreign entities.</p>
                </div>

                <div class="checklist-item">
                    <span class="step-number">5</span>
                    <h3>Obtain an EIN</h3>
                    <p>Secure an Employer Identification Number (EIN), a federal tax ID, to identify your business for tax purposes. This is mandatory for hiring employees or managing tax-related activities.</p>
                </div>

                <div class="checklist-item">
                    <span class="step-number">6</span>
                    <h3>Acquire Business Licenses and Permits</h3>
                    <p>Depending on your industry and location, you may need various licenses and permits, such as general business licenses, health permits, zoning approvals, or professional certifications.</p>
                </div>

                <div class="checklist-item">
                    <span class="step-number">7</span>
                    <h3>Register for Payroll Taxes</h3>
                    <p>If hiring employees, register for payroll taxes, including State Unemployment Insurance Tax (SUI) and State Income Tax (SIT), to comply with employment regulations.</p>
                </div>

                <div class="checklist-item">
                    <span class="step-number">8</span>
                    <h3>Stay Compliant</h3>
                    <p>After establishing your business, ensure ongoing compliance by maintaining necessary filings and adhering to corporate regulations. Tools like compliance portals can simplify this process.</p>
                </div>
            </div>
        </div>
  </section>
  <!-- /Services Section -->

  <!-- Stats Section -->
  <section id="stats" class="stats section light-background">
    <div class="container">
      <div class="row gy-4 justify-content-center">
        <div class="col-lg-5">
          <div class="images-overlap">
            <img src="./images/syb-second-img.webp" alt="student" class="img-fluid img-1" >
          </div>
        </div>
         
        <div class="col-lg-5">
        <h2 class="content-title">Why Choose BizCropGlobal for Starting a Business in the U.S.?</h2>
          <!-- <h2 class="content-title">Far far away Behind the Word Mountains</h2> -->
          <div class="lead">
            <h5>1. Hassle-Free Market Entry
            </h5>
            <ul>
              <li>
              Customized strategies to simplify your transition into the U.S. market.
              </li>
              <li>
              Comprehensive compliance support to meet all legal and regulatory requirements.
              </li>
            </ul>
          </div>
          <div class="lead">
            <h5>2. Transparent and Reliable Services</h5>
            <ul>
              <li>
                Upfront, itemized pricing with no hidden fees or unnecessary upsells.
              </li>
              <li>
              Affordable solutions designed to meet your specific needs efficiently.
              </li>
            </ul>
          </div>
          <div class="lead">
            <h5>3. Customer-Centric Approach</h5>
            <ul>
              <li>
                Risk-free service with a money-back guarantee for your assurance.
              </li>
              <li>
              Access to live experts for real-time assistance and support at every step.
              </li>
            </ul>
          </div>
        
          <div class="row mb-5 count-numbers">
           
            <div class="col-lg-12"  >
              <span data-purecounter-separator="true" data-purecounter-start="0" data-purecounter-end="3919" data-purecounter-duration="1" class="purecounter number"></span>
              <span class="d-block" style="font-weight:600;font-size:14px">Trust BizCropGlobal to make your U.S. business expansion seamless, efficient, and successful.</span>
            </div>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- /Stats Section -->
  
 

  <!-- Services 2 Section -->
  <section id="services-2" class="services-2 section">
    <div class="container">
      <div class="row justify-content-center" >
        <span class="content-subtitle">Additional Services </span>
        <div class="col-lg-6">
            <h2 class="content-title">
            1. File a DBA for Sole Proprietorship
            </h2>
            <p class="lead text-justify" style="font-size: 16px;">
            A <a href="#.">"Doing Business As" (DBA) filing </a>, also known as a Fictitious Business Name (FBN), is essential when operating your business under a name different from your own. Filing a DBA in the relevant jurisdiction allows small businesses to use a fictitious name legally.
            <br><br>
            To explore pricing and processing times for registering a Sole Proprietorship or filing a DBA in your state and county, refer to our detailed guidance.
            </p>
           
        </div>

        <div class="col-lg-6">
            <h2 class="content-title">
            2. Business Licenses, Permits, and Taxes
            </h2>
            <p class="lead text-justify" style="font-size: 16px;">
              While not all <a href="#.">businesses require a license </a> to operate in the United States, licensing requirements vary depending on your industry and location. It's crucial to understand the specific licenses or permits your business may need.
              <br> <br>
               Additionally, ensure compliance by obtaining a Federal Tax ID Number and registering with the appropriate State Revenue Department. Visit our Business Licenses section for comprehensive details on licensing, permits, and tax registration.  
            </p>
        </div>
        <div class="col-lg-12 mx-auto">
            <p>
              <a href="https://mktg.bizcorpglobal.com/bsw-survey-page" class="btn btn-get-started">Get Started</a>
            </p>
        </div>
        <!-- <div class="col-md-6 col-lg-6 ps-lg-5">
          <div class="row">
            <div class="col-6 col-sm-6 col-md-6 col-lg-6">
              <div class="services-item">
                <div class="services-icon">
                  <i class="bi bi-search"></i>
                </div>
                <div>
                  <h3>Square</h3>
                  <p>Separated they live in Bookmarksgrove right at the coast</p>
                </div>
              </div>
            </div>
            <div class="col-6 col-sm-6 col-md-6 col-lg-6">
              <div class="services-item"  >
                <div class="services-icon">
                  <i class="bi bi-command"></i>
                </div>
                <div>
                  <h3>Technology</h3>
                  <p>Separated they live in Bookmarksgrove right at the coast</p>
                </div>
              </div>
            </div>
            <div class="col-6 col-sm-6 col-md-6 col-lg-6">
              <div class="services-item"  >
                <div class="services-icon">
                  <i class="bi bi-grid"></i>
                </div>
                <div>
                  <h3>Brilliant Ideas</h3>
                  <p>Separated they live in Bookmarksgrove right at the coast</p>
                </div>
              </div>
            </div>

            <div class="col-6 col-sm-6 col-md-6 col-lg-6">
              <div class="services-item"  >
                <div class="services-icon">
                  <i class="bi bi-globe"></i>
                </div>
                <div>
                  <h3>Blueprint</h3>
                  <p>Separated they live in Bookmarksgrove right at the coast</p>
                </div>
              </div>
            </div>
          </div>
        </div> -->
      </div>
    </div>
  </section><!-- /Services 2 Section -->

   <!-- Tabs Section -->
   <section id="tabs" class="tabs section light-background">

<div class="container">
  <div class="row gap-x-lg-4 justify-content-between">
    <div class="col-lg-5 js-custom-dots ">
      <a href="#" class="service-item link horizontal d-flex active ">
        <div class="service-icon color-1 mb-4 p-3">
          <i class="bi bi-briefcase"></i>
        </div>
        <!-- /.icon -->
        <div class="service-contents p-3">
          <h4>Effortless U.S. Expansion with Expert Business Filing Support</h4>
          <p class="mt-4 text-justify">
            BizCropGlobal makes your transition from India to the U.S. smooth and successful, ensuring compliance at every stage of your business journey. Whether you're on a basic or premium service tier, our dedicated business filing experts are available 24/7 via phone, text, and email to provide seamless, real-time support whenever you need it. We combine advanced technology with exceptional professionals to guide you through every step of the process.
          </p>
        </div>
        <!-- /.service-contents-->
      </a>
      <!-- /.service -->
    </div>

    <div class="col-lg-7">
      <div class="swiper init-swiper-tabs">
      
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <img src="./images/syb-third-img.webp" alt="Image" class="img-fluid">
          </div>
          
        </div>
      </div>
    </div>
  </div>
</div>
</section><!-- /Tabs Section -->

  <!-- Faq Section
  <section id="faq" class="faq section">
    <div class="container section-title" >
      <p>Plans</p>
      <h2>Frequently Asked Questions</h2>
    </div>

    <div class="container" >
      <div class="row">
        <div class="col-12">
          <div class="custom-accordion" id="accordion-faq">
            <div class="accordion-item">
              <h2 class="mb-0">
                <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-faq-1">
                  How to download and register?
                </button>
              </h2>

              <div id="collapse-faq-1" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion-faq">
                <div class="accordion-body">
                  Far far away, behind the word mountains, far from the countries
                  Vokalia and Consonantia, there live the blind texts. Separated
                  they live in Bookmarksgrove right at the coast of the Semantics,
                  a large language ocean.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="mb-0">
                <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-faq-2" "="">
                  How to create your paypal account?
                </button>
              </h2>
              <div id="collapse-faq-2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion-faq">
                      <div class="accordion-body">
                        A small river named Duden flows by their place and supplies it
                        with the necessary regelialia. It is a paradisematic country, in
                        which roasted parts of sentences fly into your mouth.
                      </div>
                </div>
            </div>

          <div class="accordion-item">
            <h2 class="mb-0">
              <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-faq-3">
                How to link your paypal and bank account?
              </button>
            </h2>

            <div id="collapse-faq-3" class="collapse" aria-labelledby="headingThree" data-parent="#accordion-faq">
              <div class="accordion-body">
                When she reached the first hills of the Italic Mountains, she
                had a last view back on the skyline of her hometown
                Bookmarksgrove, the headline of Alphabet Village and the subline
                of her own road, the Line Lane. Pityful a rethoric question ran
                over her cheek, then she continued her way.
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
    </div>
  </section>
  /Faq Section -->

</main>

<!-- Scroll Top -->
<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <script src="vendor/bootstrap/css/bootstrap.bundle.min.js"></script>
  <script>
    // Wait for DOM to be fully loaded
      document.addEventListener('DOMContentLoaded', () => {
          // Get all tab elements
          const tabs = document.querySelectorAll('.tab-button');
          const contents = document.querySelectorAll('.tab-content');

          // Function to show selected tab content
          function showTab(tabId) {
              // Hide all content sections
              contents.forEach(content => {
                  content.classList.remove('active');
              });

              // Remove active class from all tabs
              tabs.forEach(tab => {
                  tab.classList.remove('active');
              });

              // Show selected content and activate tab
              document.getElementById(tabId).classList.add('active');
              document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
          }

          // Add click handlers to all tabs
          tabs.forEach(tab => {
              tab.addEventListener('click', () => {
                  const tabId = tab.getAttribute('data-tab');
                  showTab(tabId);
              });
          });
      });
  </script>
<?php include 'footer.php';?>