  </div>
  <!-- incentive main close -->
  <script type="text/javascript" src="./assets/js/chartloader.js"></script>
  <script src="./assets/js/jquery3.7.1.js"></script>
  <script src="./assets/js/chart.js"></script>
  <script src="./assets/js/datatable.js"></script>
  <script src="./assets/js/semantic.js"></script>
  <script src="./assets/js/bootstrap5.3.2.js"></script>
  <script src="./assets/js/script.js"></script>
</body>
</html>