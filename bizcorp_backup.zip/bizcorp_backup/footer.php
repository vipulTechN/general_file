<!-- consultation Free Modal Start-->
<div class="modal fade" id="consultationModal" tabindex="-1" role="dialog" aria-labelledby="consultationModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
		<div class="modal-header clearfix">
			<h5 class="modal-title" id="consultationModalLabel">Get Free Consultation</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
		</div>
		<div class="modal-body">
			<iframe src="https://api.geteliv8.com/widget/bookings/bcg-free-consultation" width="100%" height="500px" frameborder="0"></iframe>
		</div>
		<div class="modal-footer mx-auto">
			<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		</div>
		</div>
	</div>
</div>
<!-- consultation Free Modal End-->
 
<style>
.quicklinks{
	padding-left:100px;
}
@media only screen and (max-width:768px){
	.quicklinks{
		padding-left:0px;
	}
}
</style>
		
		<section class="newsletter">
			<div class="container">
				<div class="row ">
					<div class="col-lg-6  col-12 d-flex align-items-center justify-content-center">
						<!-- Start Newsletter Form -->
						<div class="subscribe-text ">
							<h6>Stay ahead with our newsletter</h6>
							<p class="text-justify">Get exclusive insights, tips, and updates delivered straight to your inbox. <br> Join our community today!</p>
						</div>
						<!-- End Newsletter Form -->
					</div>
					<div class="col-lg-6  col-12">
						<!-- Start Newsletter Form -->
						<div class="subscribe-form ">
							<iframe
							src="https://api.geteliv8.com/widget/form/YWKMbbHr4Fd4tHmPWbpD"
							style="width:100%;height:100%;border:none;border-radius:3px"
							id="inline-YWKMbbHr4Fd4tHmPWbpD" 
							data-layout="{'id':'INLINE'}"
							data-trigger-type="alwaysShow"
							data-trigger-value=""
							data-activation-type="alwaysActivated"
							data-activation-value=""
							data-deactivation-type="neverDeactivate"
							data-deactivation-value=""
							data-form-name="Newsletter Signup"
							data-height="432"
							data-layout-iframe-id="inline-YWKMbbHr4Fd4tHmPWbpD"
							data-form-id="YWKMbbHr4Fd4tHmPWbpD"
							title="Newsletter Signup"
								>
							</iframe>
						</div>
						<!-- End Newsletter Form -->
					</div>
				</div>
			</div>
		</section>
		<!-- Footer Area -->
		<footer id="footer" class="footer">
			<!-- Footer Top -->
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer">
								<h2>About Us</h2>
								<p class="text-justify">BizCorpGlobal empowers Indian businesses to thrive in the U.S. With tailored solutions for entrepreneurs, accountants, lawyers, and corporations, we ensure a seamless, efficient, and stress-free journey to starting, growing, and managing your business.</p>
								<!-- Social
									<ul class="social">
										<li><a href="#"><i class="icofont-facebook"></i></a></li>
										<li><a href="#"><i class="icofont-linkedin"></i></a></li>
										<li><a href="#"><i class="icofont-twitter"></i></a></li>
										<li><a href="#"><i class="icofont-instagram"></i></a></li>
										<li><a href="#"><i class="icofont-pinterest"></i></a></li>
									</ul>
								End Social -->
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer f-link">
								<h2>Quick Links</h2>
								<div class="row">
									<div class="col-lg-6 col-md-6 col-12">
										<ul>
											<li><a href="index.php"><i class="fa fa-caret-right" aria-hidden="true"></i>Home</a></li>
											<li><a href="about.php"><i class="fa fa-caret-right" aria-hidden="true"></i>About Us</a></li>
											<li><a href="start_your_business"><i class="fa fa-caret-right" aria-hidden="true"></i>Services</a></li>
											<li><a href="blog-single.php"><i class="fa fa-caret-right" aria-hidden="true"></i>Blog</a></li>
											<li><a href="contact.php"><i class="fa fa-caret-right" aria-hidden="true"></i>Contact Us</a></li>	
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer">
								<h2>Open Hours</h2>
								<ul class="time-sidual">
									<li class="day">Monday<span>10.00-07:00</span></li>
									<li class="day">Tuesday<span>10.00-07:00</span></li>
									<li class="day">Wednesday<span>10.00-07:00</span></li>
									<li class="day">Thursday<span>10.00-07:00</span></li>
									<li class="day">Friday<span>10.00-07:00</span></li>
									<li class="day">Saturday<span>9.00-6:30</span></li>
									<li class="day">Sunday <span>Off</span></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer">
								<h2>Address</h2>
								<div class="iframe">
									<iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d2790.091372138308!2d77.6325833!3d12.9134167!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMTLCsDU0JzQ4LjMiTiA3N8KwMzcnNTcuMyJF!5e1!3m2!1sen!2sin!4v1735213004404!5m2!1sen!2sin" style="border:0;width:100%;height:200px" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
			<!--/ End Footer Top -->
			<!-- Copyright -->
			<div class="copyright">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-12">
							<div class="copyright-content">
								<p>© Copyright 2024  |  All Rights Reserved by BizCorpGlobal </p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Copyright -->
		</footer>
		<!--/ End Footer Area -->
		
		<!-- jquery Min JS -->
        <script src="js/jquery.min.js"></script>
		<!-- jquery Migrate JS -->
		<script src="js/jquery-migrate-3.0.0.js"></script>
		<!-- jquery Ui JS -->
		<script src="js/jquery-ui.min.js"></script>
		<!-- Easing JS -->
        <script src="js/easing.js"></script>
		<!-- Color JS -->
		<script src="js/colors.js"></script>
		<!-- Popper JS -->
		<script src="js/popper.min.js"></script>
		<!-- Bootstrap Datepicker JS -->
		<script src="js/bootstrap-datepicker.js"></script>
		<!-- Jquery Nav JS -->
        <script src="js/jquery.nav.js"></script>
		<!-- Slicknav JS -->
		<script src="js/slicknav.min.js"></script>
		<!-- ScrollUp JS 
        <script src="js/jquery.scrollUp.min.js"></script>-->
		<!-- Niceselect JS -->
		<script src="js/niceselect.js"></script>
		<!-- Tilt Jquery JS -->
		<script src="js/tilt.jquery.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="js/owl-carousel.js"></script>
		<!-- counterup JS -->
		<script src="js/jquery.counterup.min.js"></script>
		<!-- Steller JS -->
		<script src="js/steller.js"></script>
		<!-- Wow JS -->
		<script src="js/wow.min.js"></script>
		<!-- Magnific Popup JS -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		 <!-- Vendor JS Files -->
  		<script src="vendor/swiper/swiper-bundle.min.js"></script>
		<!--newsletter cdn -->
		<script src="https://api.geteliv8.com/js/form_embed.js"></script>
		<!--chatbot cdn -->
		<script defer src="https://chatcdn.geteliv8.com/assets/widget.min.js"></script> 
		<!-- Main JS -->
		<script src="js/main.js"></script>
    </body>
</html>