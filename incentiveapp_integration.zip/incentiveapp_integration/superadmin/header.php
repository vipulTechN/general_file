</head>

<body>
  <!-- incentive main start -->
  <div class="incentivemain">

    <!-- Navbar -->
    <nav class="navbar">

      <i class="bi bi-sliders2 dashopen" onclick="toggleleftsidebar()"></i>

      <div class="incentivelogo">
        <a href="#" class="logo">
          <img class="shilogo" src="../assets/images/shilogo.png" alt="applogo" />
        </a>
      </div>

      <form action="#" id="lapserach">
        <div class="inputwrap d-block position-relative">
          <div class="form-input d-flex">
            <input type="text" id="searchInput" placeholder="Search..." onkeyup="filterOptions()" />
            <button class="search-btn" type="submit">
              <i class="bx bx-search"></i>
            </button>
          </div>

          <ul id="optionul">
            <li class="optionli">
              <a href="/user/superadmin/">
                Dashboard - (Admin-Login)
              </a>
            </li>
            <li class="optionli">
              <a href="/user/userlogin">
                Dashboard - (User-Login)
              </a>
            </li>
            <li class="optionli">
              <a href="/user/hrlogin">
                Dashboard - (Hr-Login)
              </a>
            </li>
            <li class="optionli">
              <a href="/user/paid.php">
                Check-status - (Paid)
              </a>
            </li>
            <li class="optionli">
              <a href="/user/processing.php">
                Check-status - (Processing)
              </a>
            </li>
            <li class="optionli">
              <a href="/user/cancelled.php">
                Check-status - (Cancelled)
              </a>
            </li>
            <li class="optionli">
              <a href="/user/superadmin/database.php">
                Database
              </a>
            </li>
            <li class="optionli">
              <a href="/user/superadmin/expenses.php">
                Expenses
              </a>
            </li>
            <li class="optionli">
              <a href="/user/superadmin/tracking.php">
                Tracking
              </a>
            </li>
            <li class="optionli">
              <a href="/user/superadmin/payment_table.php">
                Payment table
              </a>
            </li>
            <li class="optionli">
              <a href="/company-assets">
                C-assets
              </a>
            </li>
          </ul>
        </div>
      </form>

      <div id="mob_search_icon" onclick="openSearchPopup()">
        <i class="bx bx-search"></i>
      </div>

      <div id="search-popup" class="search-popup">
        <form>
          <input type="text" placeholder="Type your search...">
          <div class="mob-pop-flex">
            <button type="submit">Search</button>
            <button onclick="closeSearchPopup()">Close</button>
          </div>
        </form>
      </div>

      <a href="#" class="notif" id="more_notif_icon">
        <i class="bx bx-bell"></i>
        <span class="count">0</span>
      </a>

      <div class="notif-content" id="notif-content_box">
        <ul>
          <div class="closebtn"><i class="bi bi-x-circle-fill"></i></div>
          <li>
            <span>
              <h6>You have 3 notification</h6>
            </span>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>today</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>yesterday</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
          <li>
            <span>
              <i class="bx bx-envelope"></i>
              Lorem ipsum, dolor sit amet consectetur adipisicing.
            </span>
            <p>11:00 Am</p>
          </li>
        </ul>
      </div>

      <a href="#" class="profile" id="more_profile_icon">
        <i class="bi bi-person-fill"></i>
      </a>

      <div class="profile-content" id="profile-content_box">
        <ul>
          <div class="closebtn1"><i class="bi bi-x-circle-fill"></i></div>
          <li>
            <span>
              <i class="bi bi-person-fill"></i>
              Welcome Pratham!
            </span>
          </li>
          <li>
            <span>
              <i class="bi bi-lock-fill"></i>
              Forget Password
            </span>
          </li>
          <li>
            <span>
              <i class="bi bi-box-arrow-right"></i>
              User-login
            </span>
          </li>

          <li>
            <button class="profile-logout">
              <i class="bx bx-log-out-circle"></i>
              Logout
            </button>
          </li>
        </ul>
      </div>

      <a href="#" class="setting" id="togglerightsidebar">
        <i class="bi bi-sliders"></i>
      </a>

      <!-- Right Sidebar -->
      <aside id="rightsidebar" class="pmd-sidebar">
        <i class="bi bi-x-circle-fill close-btn" id="close-btn"></i>
        <ul class="pmd-sidebar-ul">
          <li class="pmd-sidebar-li" type="button" data-toggle="modal" data-target="#addNewUserModal">
            <i class="bi bi-person-fill-add"></i>
            <span>Add Booking</span>
          </li>
          <!-- Add New User Modal Start -->
          <div class="modal fade" tabindex="-1" id="addNewUserModal">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Add New Booking</h5>
                  <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form id="add-user-form" name="myform" class="p-2" novalidate>
                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="date" name="bdate" class="form-control form-control-lg" required>
                        <div class="invalid-feedback">Date is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="month" name="bmonth" class="form-control form-control-lg" required>
                        <div class="invalid-feedback">Month is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="text" name="developer" class="form-control form-control-lg" placeholder="Enter Builder Name" required>
                        <div class="invalid-feedback">Builder name is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="text" name="bproject" class="form-control form-control-lg" placeholder="Enter Project Name" required>
                        <div class="invalid-feedback">Project name is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="username" name="cname" class="form-control form-control-lg" placeholder="Enter Customer Name" required>
                        <div class="invalid-feedback">Customer name is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="number" name="cnumber" class="form-control form-control-lg" placeholder="Enter Contact Number" required>
                        <div class="invalid-feedback">Contact Number is required!</div>
                      </div>
                    </div>

                    <div class="col-11 mb-3 mx-auto">
                      <input type="email" name="cemail" class="form-control form-control-lg" placeholder="Enter E-mail" required>
                      <div class="invalid-feedback">E-mail is required!</div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="text" name="tproject" class="form-control form-control-lg" placeholder="Enter Project Tpye" required>
                        <div class="invalid-feedback">Project Tpye is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="text" name="unitno" class="form-control form-control-lg" placeholder="Enter Unit Number" required>
                        <div class="invalid-feedback">Unit Number is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="number" name="psize" class="form-control form-control-lg" placeholder="Enter Project Size" required>
                        <div class="invalid-feedback">Project Size is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="number" name="cagreement" class="form-control form-control-lg" placeholder="Enter Agreement Value" required>
                        <div class="invalid-feedback">Agreement Value is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="text" name="ccashback" class="form-control form-control-lg" placeholder="Enter Commission %" onkeyup="addCalculate(this.value)" required>
                        <div class="invalid-feedback">Commission % is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="number" name="crevenue" class="form-control form-control-lg" placeholder="Total Revenue Amount" required>
                        <div class="invalid-feedback">Revenue Amount is required!</div>
                      </div>
                    </div>

                    <div class="row mb-3 gx-3">
                      <div class="col-6">
                        <input type="text" name="cccashback" class="form-control form-control-lg" placeholder="Enter Cashback %" onkeyup="addCalculate(this.value)" required>
                        <div class="invalid-feedback">Cashback % is required!</div>
                      </div>

                      <div class="col-6">
                        <input type="number" name="ccrevenue" class="form-control form-control-lg" placeholder="Actual Revenue Amount" required>
                        <div class="invalid-feedback">Actual Amount is required!</div>
                      </div>
                    </div>

                    <div class="mb-3">
                      <input type="checkbox" class="btn-check Processing" name="cstatus" id="btn-check-2-outlined" value="Processing" checked>
                      <label class="btn btn-outline-primary" for="btn-check-2-outlined">Processing</label><br><br>

                      <input type="radio" class="btn-check Received" name="cstatus" id="success-outlined" value="Received">
                      <label class="btn btn-outline-success" for="success-outlined">Received</label>

                      <input type="radio" class="btn-check Cancled" name="cstatus" id="danger-outlined" value="Cancled">
                      <label class="btn btn-outline-danger" for="danger-outlined">Cancled</label>
                      <div class="invalid-feedback">Status is required!</div>
                    </div>

                    <div class="mb-3">
                      <input type="number" name="brecived" class="form-control form-control-lg" placeholder="Enter Enter Received Amt.">
                      <div class="invalid-feedback">Enter Received Amt. is required!</div>
                    </div>

                    <div class="mb-3">
                      <input type="submit" value="Add Booking" class="btn btn-primary btn-block btn-lg" id="add-user-btn">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <!-- Add New User Modal End -->

          <li class="pmd-sidebar-li" data-toggle="modal" data-target="#filterModal">
            <i class="bi bi-funnel-fill"></i>
            <span>Filter</span>
          </li>

          <li class="pmd-sidebar-li" data-toggle="modal" data-target="#calculatorModal">
            <i class="bi bi-calculator"></i>
            <span>Calculator</span>
          </li>
          <!-- Calculator Modal -->
          <div class="modal fade" id="calculatorModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Incentive Calculator</h5>
                  <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>

                </div>
                <div class="modal-body">
                  <form id="calculator-form">
                    <div class="form-group">
                      <label for="d1" class="font-weight-bold">Current Salary:</label>
                      <input type="number" class="form-control" id="d1" required>
                    </div>
                    <div class="form-group">
                      <label for="d2" class="font-weight-bold">Generated Revenue</label>
                      <input type="number" class="form-control" id="d2" required>
                    </div>
                  </form>
                  <div class="mt-3">
                    <!-- <p>Incentive:</p> -->
                    <div class="border border-dark d-inline p-2 m-1 bg-success text-white font-weight-bold">Amount:
                      ₹<span id="result">0.00</span></div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" form="calculator-form" class="btn btn-primary">Calculate</button>
                </div>
              </div>
            </div>
          </div>
          <!-- calculator modal End -->
          <li class="pmd-sidebar-li" type="button" id="downloadCsvBtn">
            <i class="bi bi-cloud-arrow-down-fill"></i>
            <span>Download</span>
          </li>
        </ul>

      </aside>

    </nav>
    <!-- End of Navbar -->

    <!--Left Sidebar -->
    <div class="sidebar" id="sidebar">
      <ul class="side-menu" id="side-menu">

        <li class="sidemenuli sideactive">
          <div class="dropdown logindrop">
            <a href="#"><i class="bx bxs-dashboard"></i>Dashboard</a>
            <div class="dropdown-content logindropcont" style="left:10px">
              <ul id="logincont">
                <li class="logincontli loginact">
                  <a href="/user/superadmin/"><i class="bx bx-user"></i>Admin-Login</a>
                </li>
                <li class="logincontli">
                  <a href="/user/hrlogin"><i class="bx bx-user"></i>Hr-Login</a>
                </li>
                <li class="logincontli">
                  <a href="/user/userlogin"><i class="bx bx-user"></i>User-Login</a>
                </li>
              </ul>
            </div>
          </div>
        </li>

        <li class="sidemenuli">
          <a href="/user/superadmin/database.php"><i class='bx bxl-postgresql'></i>Databases</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/superadmin/expenses.php"><i class='bx bxs-bank'></i>Expenses</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/superadmin/tracking.php"><i class="bx bx-message-square-dots"></i>Incentive-Tracker</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/superadmin/payment_table.php"><i class='bx bx-rupee'></i>Payment-Tracker</a>
        </li>

        <li class="sidemenuli">
          <a href="/user/superadmin/companyassets.php"><i class='bx bx-laptop'></i>C-Assets</a>
        </li>

        <li class="sidemenuli">
          <div class="dropdown statusdrop">
            <a href="#"><i class="bx bxs-bookmarks"></i>Check Status</a>
            <div class="dropdown-content statusdropcont" style="left: 10px">
              <ul id="statuscont">
                <li class="statuscontli statusact">
                  <a href="#"><i class="bx bx-wallet"></i>Paid</a>
                </li>
                <li class="statuscontli">
                  <a href="#"><i class="bx bx-loader-circle"></i>Processing</a>
                </li>
                <li class="statuscontli">
                  <a href="#"><i class="bx bx-error-alt"></i>Cancelled</a>
                </li>
              </ul>
            </div>
          </div>
        </li>

        <li class="sidemenuli">
          <a href="#"><i class="bi bi-lightbulb-fill"></i>
            <input type="checkbox" id="theme-toggle" hidden />
            <label for="theme-toggle" class="theme-toggle"></label>
          </a>
        </li>

        <li class="sidemenuli">
          <a href="#" class="logout"><i class="bx bx-log-out-circle"></i>Logout</a>
        </li>

      </ul>
    </div>
    <!-- End of Left Sidebar -->
    <script>
      var dropcontContainer = document.getElementById("logincont");
      var dropcontli = dropcontContainer.getElementsByClassName("logincontli");
      for (var i = 0; i < dropcontli.length; i++) {
        dropcontli[i].addEventListener("click", function() {
          var current = document.getElementsByClassName("loginact");
          current[0].className = current[0].className.replace(" loginact", "");
          this.className += " loginact";
        });
      }
      var statuscontContainer = document.getElementById("statuscont");
      var statuscontli = statuscontContainer.getElementsByClassName("statuscontli");
      for (var i = 0; i < statuscontli.length; i++) {
        statuscontli[i].addEventListener("click", function() {
          var current = document.getElementsByClassName("statusact");
          current[0].className = current[0].className.replace(" statusact", "");
          this.className += " statusact";
        });
      }
    </script>