$(document).ready(function () {
  $(window).scroll(function () {
    var scrollY = $(window).scrollTop();
    var viewPort = window.innerWidth >= 768 ? 375 : 183;
    if (scrollY > viewPort) {
      $("#header").css("top", "-65px")
      $("#header1").css("top", "0px");
    } else {
      $("#header").css("top", "0px");
      $("#header1").css("top", "-65px");
    }
  });
});
function commonNav(navId, widthValue) {
  const navElement = document.getElementById(navId);
  navElement.style.width = widthValue;
  navElement.style.display = widthValue === "0%" ? "none" : "block";
}
// sidenav end =============================================  
var containerElement = document.getElementById("up22");
var buttonElements = containerElement.getElementsByClassName("btnsss2");
for (var i = 0; i < buttonElements.length; i++) {
  buttonElements[i].addEventListener("click", function() {
    var activeElements = document.getElementsByClassName("activeElement");
    activeElements[0].className = activeElements[0].className.replace(" activeElement", "");
    this.className += " activeElement";
  });
}   
//Ripple Event Handler
// var drawRipple = function(ev) {
//   var x = ev.clientX;
//   var y = ev.clientY;
//   var node = document.querySelector(".ripple");
//   var newNode = node.cloneNode(true);
//   newNode.classList.add("animate");
//   newNode.style.left = ev.clientX - 5 + "px";
//   newNode.style.top = ev.clientY - 5 + "px";
//   node.parentNode.replaceChild(newNode, node);
// };

// //Ripple Triggers
// window.addEventListener("click", drawRipple); 