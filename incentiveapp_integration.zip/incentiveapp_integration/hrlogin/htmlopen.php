<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>IncentiveApp</title>
  <script src="../assets/js/bootstrap_alpha2.js"></script>
  <script src="../assets/js/jquery3.7.1.js"></script>
  <link rel="stylesheet" href="../assets/css/dataTable2.0.4.css" />
  <link rel="stylesheet" href="../assets/css/button_dataTable3.0.2.css" />
  <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" />
  <link rel="stylesheet" href="../assets/css/bootstrap5.3.2.css"/>
  <link rel="stylesheet" href="../assets/css/fixed_dataTable5.0.0.css"/>
  <link rel="stylesheet" href="../assets/css/jquery_dataTable.css">
  <link rel="stylesheet" href="../assets/css/style.css"/>
