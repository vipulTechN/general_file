document.querySelector('html,body').scrollIntoView({
  behavior: 'smooth'
});
// midright part of middle start==========================
$(document).ready(function () {
  $(window).scroll(function () {
    var scrollY = $(window).scrollTop();
    if (scrollY > 1250) {  
      $(".midright").css("top","60px");
      $(".midright").css("position", "sticky");
    } 
    else if (scrollY >= 3300) {  
      $(".midright").css("position", "sticky");
    }
  else{
    $(".midright").css("display", "flow");
        }
  });
});
// midright part of middle end===============================================================
// propright start==============================
$(document).ready(function () {
  $(window).scroll(function () {
    var scrollY = $(window).scrollTop();
    if (scrollY > 60) {  
      $(".propdetail-right").css("top","20px");
      $(".propdetail-right").css("position", "sticky");
    } 
    if (scrollY >= 850) {  
      $(".propdetail-right").css("display", "none");
    }
  else{
    $(".propdetail-right").css("display", "flow");
    }
  });
});
// property detail end============================
// propdetail header=================================
$(document).ready(function () {
  $(window).scroll(function () {
    var scrollY = $(window).scrollTop();
    if (scrollY > 900) {  
      $(".propdethead").css("position", "sticky");
      $(".propdethead").css("top","10px");
      $(".propdetail-left").css("width","100%");
      $(".propdetail-right").css("display","none");
    }
  });
});
// propdetail header end==============================
//nav2 slider line--------------------------------------------------------------------------------------
$(document).ready(function () {
  $(".menu--item__one").click(function () {
    $(".bottom__line").removeClass("bottom__active1 bottom__active2 bottom__active3 bottom__active4 bottom__active5 ");
  });
  //  Second active item
  $(".menu--item__two").click(function () {
    $(".bottom__line").addClass("bottom__active1");
    $(".bottom__line").removeClass("bottom__active bottom__active2 bottom__active3 bottom__active4 bottom__active5 ");
  });
  // Third active item
  $(".menu--item__three").click(function () {
    $(".bottom__line").addClass("bottom__active2");
    $(".bottom__line").removeClass("bottom__active bottom__active1 bottom__active3 bottom__active4 bottom__active5");
  });
  // Fourth active item
  $(".menu--item__four").click(function () {
    $(".bottom__line").addClass("bottom__active3")
    $(".bottom__line").removeClass("bottom__active bottom__active1 bottom__active2 bottom__active4 bottom__active5");
  });
  // Five active item
  $(".menu--item__five").click(function () {
    $(".bottom__line").addClass("bottom__active4")
    $(".bottom__line").removeClass("bottom__active bottom__active1 bottom__active2 bottom__active3 bottom__active5");
  });
  // Six active item
  $(".menu--item__six").click(function () {
    $(".bottom__line").addClass("bottom__active5")
    $(".bottom__line").removeClass("bottom__active bottom__active1 bottom__active2 bottom__active3 bottom__active4 ");
  });
});

//nav2 slider line end--------------------------------------------
// sidenav  only for desktop start =============================================
function commonNav(navId, widthValue) {
  const navElement = document.getElementById(navId);
  navElement.style.width = widthValue;
  navElement.style.display = widthValue === "0%" ? "none" : "block";
}
// ==============================================================================

const counters = document.querySelectorAll('.counter');
const speed = 2000;
counters.forEach( counter => {
   const animate = () => {
      const value = +counter.getAttribute('data-target');
      const data = +counter.innerText;
      const time = value / speed;
     if(data < value) {
          counter.innerText = Math.ceil(data + time);
          setTimeout(animate, 1);
        }else{
          counter.innerText = value;
        }
   }
   animate();
});

var container = document.getElementById("up");
var buttons = container.getElementsByClassName("btnsss");
for (var i = 0; i < buttons.length; i++) {
  buttons[i].addEventListener("click", function() {
    var currentActive = document.getElementsByClassName("active");
    currentActive[0].className = currentActive[0].className.replace(" active", "");
    this.className += " active";
  });
}

  function initializeSwiper(selector, slidesPerView, spaceBetween, autoplayDelay) {
    return new Swiper(selector, {
      slidesPerView: slidesPerView, // preview slider
      spaceBetween: spaceBetween,
      loop: true,
      lazy: true,
    freemode:true,
      speed: 400,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
        dynamicBullets: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
      breakpoints: {
        768: {
          slidesPerView: 3.2, 
        },
        540:{
          slidesPerView:2,
        },
        320: {
          slidesPerView: 1.2,
        },
      },
    });
  }
  // Initialize your sliders
  var swiper1 = initializeSwiper(".mySwiper", 3.2, 30, 2000);
  var swiper2 = initializeSwiper(".mySwiper1", 2, 20, 2500);
  var swiper3 = initializeSwiper(".mySwiper2", 4, 30, 3000);
 
  
  function initializeSwiper1(selector, slidesPerView, spaceBetween) {
    return new Swiper(selector, {
      slidesPerView: slidesPerView, 
      spaceBetween: spaceBetween,
      lazy: true,
      loop: true,
    freemode:true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
        dynamicBullets: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  }
  var swiper4 = initializeSwiper1(".mySwiper3", 1, 30);

  var swiper = new Swiper(".mySwiper4", {
    slidesPerView:3,
    spaceBetween:10,
    loop:false,
    lazy: true,
    freemode:true,
    breakpoints:{
      1650:{
        slidesPerView:4.4,
      },
      1100:{
        slidesPerView:3,
      },
      910:{
        slidesPerView:3.4,
      },
      620: {
        slidesPerView: 3, 
      },
      420: {
        slidesPerView: 2, 
      },
      310:{
        slidesPerView:1.5,
      },
      200:{
        slidesPerView:1,
      },
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },

  });

  function initializeSwiper3(selector, slidesPerView, spaceBetween) {
    return new Swiper(selector, {
      slidesPerView: slidesPerView, 
      spaceBetween: spaceBetween,
      lazy: true,
    freemode:true,
    breakpoints: {
      768: {
        slidesPerView: 6.3,
        spaceBetween:20, 
      },
      520:{
        slidesPerView:2.6,
        spaceBetween:20, 
      },
      320: {
        slidesPerView: 1.8, 
        spaceBetween:20, 
      },
    },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  }
  var swiper5 = initializeSwiper3(".mySwiper5",6.3, 20);


// grid start ==========================================
  function initializeSwiper4(selector, slidesPerView, spaceBetween) {
    return new Swiper(selector, {
      slidesPerView: slidesPerView, 
      spaceBetween: spaceBetween,
      lazy: true,
    freemode:true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
        dynamicBullets: true,
      },
      breakpoints:{
        768:{
          slidesPerView:4,
        },
        500:{
          slidesPerView:2.3,
        },
        250:{
          slidesPerView:1.2,
        }
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  }
  var swiper7 = initializeSwiper4(".mySwiper7", 3, 30);
  var swiper8 = initializeSwiper4(".mySwiper8", 3, 20);
  var swiper9 = initializeSwiper4(".mySwiper9", 3, 20);
// -==========================================================================================
function initializeSwiper6(selector, slidesPerView, spaceBetween) {
  return new Swiper(selector, {
    slidesPerView: slidesPerView,
    spaceBetween: spaceBetween,
    lazy: true,
 
  freemode:true,
    pagination: {
      el: ".swiper-pagination",
      type: "fraction",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
}
var swiper11 = initializeSwiper6(".mySwiper11", 1,30);
// =======================================
function initializeSwiper7(selector, slidesPerView, spaceBetween) {
  return new Swiper(selector, {
    slidesPerView: slidesPerView, // preview slider
    spaceBetween: spaceBetween,
    lazy: true,
  freemode:true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
      dynamicBullets: true,
    },
    breakpoints:{
      768:{
        slidesPerView:4,
      },
      500:{
        slidesPerView:2.3,
      },
      250:{
        slidesPerView:1.6,
        spaceBetween:10,
      }
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
}
  var swiper6 = initializeSwiper7(".mySwiper6", 4, 25);
// grid end==========================================
function initializeSwiper8(selector, slidesPerView, spaceBetween) {
  return new Swiper(selector, {
    slidesPerView: slidesPerView,
    spaceBetween: spaceBetween,
    loop:true,
    lazy: true,
  freemode:true,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    }
  });
}
var swiper12 = initializeSwiper8(".mySwiper12", 1,20);
// ===================================================================
function initializeSwiper9(selector, slidesPerView, spaceBetween) {
  return new Swiper(selector, {
    slidesPerView: slidesPerView,
    spaceBetween: spaceBetween,
    loop:true,
    lazy: true,
  freemode:true,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    }
  });
}
var swiper13 = initializeSwiper9(".mySwiper13", 1,20);
// This for new section Builder
var swiper20 = new Swiper(".mySwiper20", {
    spaceBetween: 40,
    speed: 700,
    autoplay: {
        delay: 2000,
        disableOnInteraction: false,
    },
    breakpoints: {
        1100: {
            slidesPerView: 4,
        },
        768: {
            spaceBetween: 10,
            slidesPerView: 4,
        },
        500: {
            spaceBetween: 10,
            slidesPerView: 3,
        },
        250: {
            spaceBetween: 10,
            slidesPerView: 2,
        }
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});
// this is for why choose us section
document.addEventListener('DOMContentLoaded', function () {
  const tabs = document.querySelectorAll('.easystep_activenumber');
  const dots = document.querySelectorAll('.completeHomeInteriro_tabs_Dots__1tRqA');
  const details = document.querySelectorAll('.completeHomeInteriro_selectedTab_details__1VTVk');
  let currentIndex = 0;

  function activateTab(index) {
      // Reset all tabs, dots, and details to initial style
      tabs.forEach(tab => tab.classList.remove('easystepactive'));
      dots.forEach(dot => dot.classList.remove('easystepactive'));
      details.forEach(detail => detail.classList.remove('easystepactive'));

      // Activate the current tab, dot, and detail with red background
      tabs[index].classList.add('easystepactive');
      dots[index].classList.add('easystepactive');
      details[index].classList.add('easystepactive');

      // Update the currentIndex for the next iteration
      currentIndex = (currentIndex + 1) % tabs.length;
  }

  function startLoop() {
      // Initial activation
      activateTab(currentIndex);

      // Set interval to activate tabs, dots, and details every 3 seconds
      setInterval(function () {
          activateTab(currentIndex);
      }, 4000);
  }

  // Start the loop when the DOM is ready
  startLoop();
});
const maxCharacters = 200;
const limitedTextElements =
    document.querySelectorAll(".limited-text");
limitedTextElements.forEach((element) => {
    const longText = element.textContent;
    const trimmedText = longText.slice(0, maxCharacters);
    element.textContent = trimmedText;
    if (longText.length > maxCharacters) {
        element.title = longText;
    }
});
var swiper21 = new Swiper(".mySwiper21", {
  spaceBetween: 30,
  slidesPerView: 3,
  speed: 900,
  autoplay: {
      delay: 3300,
      disableOnInteraction: false,
  },
  breakpoints: {
      900: {
          slidesPerView: 3,
      },
      560: {
          slidesPerView: 2,
      },
      200: {
          slidesPerView: 1,
      }
  },
  pagination: {
      el: ".swiper-pagination",
      clickable: true,
  },
  navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
  },
});
var swiper23 = new Swiper(".mySwiper23", {
  spaceBetween: 15,
  speed: 900,
  autoplay: {
      delay: 3700,
      disableOnInteraction: false,
  },
  breakpoints: {
      1050: {
          slidesPerView: 4,
      },
      780: {
          slidesPerView: 3,
      },
      500: {
          slidesPerView: 2,
      },
      250: {
          slidesPerView: 1,
      }
  },
  pagination: {
      el: ".swiper-pagination",
      clickable: true,
  },
  navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
  },
});
$(document).ready(function () {
  function AddReadMore() {
      var carLmt = 200;
      var readMoreTxt = " ...Read more";
      var readLessTxt = " Read less";
      $(".add-read-more").each(function () {
          if ($(this).find(".first-section").length)
              return;

          var allstr = $(this).text();
          if (allstr.length > carLmt) {
              var firstSet = allstr.substring(0, carLmt);
              var secdHalf = allstr.substring(carLmt, allstr.length);
              var strtoadd = firstSet + "<span class='second-section'>" + secdHalf + "</span><br><span class='read-more'  title='Click to Show More'>" + readMoreTxt + "</span> <br> <span class='read-less' title='Click to Show Less'>" + readLessTxt + "</span>";
              $(this).html(strtoadd);
          }
      });
      $(document).on("click", ".read-more,.read-less", function () {
          $(this).closest(".add-read-more").toggleClass("show-less-content show-more-content");
      });
  }

  AddReadMore();
});
var swiper25 = new Swiper(".mySwiper25", {
  spaceBetween: 5,
  slidesPerView: 1,
  speed: 800,
  autoplay: {
      delay: 4000,
      disableOnInteraction: false,
  },
  pagination: {
      el: ".swiper-pagination",
      clickable: true,
  },
  navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
  },
});
var swiper22 = new Swiper(".mySwiper22", {
  spaceBetween: 40,
  speed: 700,
  autoplay: {
      delay: 2700,
      disableOnInteraction: false,
  },
  breakpoints: {
      1100: {
          slidesPerView: 4,
      },
      768: {
          spaceBetween: 10,
          slidesPerView: 4,
      },
      500: {
          spaceBetween: 10,
          slidesPerView: 3,
      },
      250: {
          spaceBetween: 10,
          slidesPerView: 2,
      }
  },
  pagination: {
      el: ".swiper-pagination",
      clickable: true,
  },
  navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
  },
});