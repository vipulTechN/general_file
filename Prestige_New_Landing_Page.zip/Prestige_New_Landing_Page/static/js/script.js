// img full screen script 
function openFullscreen(imgElement) {
    var fullscreenImg = document.getElementById('fullscreenImg');
    fullscreenImg.src = imgElement.src;
}
// img full screen script end


// otp script start 
let otpSent = {};
    let otpVerified = {};
    let generatedOtp = {};

    function generateOtp() {
        return Math.floor(1000 + Math.random() * 9000).toString();
    }

    function sendOtp(formId) {
        const userPhone = document.getElementById(`intTelInput-mob${formId}`).value;
        if (userPhone === "") {
            document.getElementById(`intTelInput-mob${formId}`).style.borderBottom = "2px solid red";
            document.getElementById(`phoneError${formId}`).innerText = "Enter your phone number to send OTP";
            document.getElementById(`phoneError${formId}`).style.display = "block";
        } else {
            generatedOtp[formId] = generateOtp();
            otpSent[formId] = true;

            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    var response = this.responseText;
                    if (response.includes("success")) {
                        document.getElementById(`verifyotpdiv${formId}`).style.display = "flex";
                        document.getElementById(`otpResult${formId}`).style.color = "green";
                        document.getElementById(`otpResult${formId}`).innerText = "OTP sent successfully!";
                        
                        // Hide the mobile number input and display the OTP input
                        document.getElementById(`sendotpdiv${formId}`).style.display = "none";
                        document.getElementById(`verifyotpdiv${formId}`).style.display = "block";
                        
                        // Hide Send OTP button and show Verify & Submit button
                        document.querySelector(`#sendotpbutton${formId}`).style.display = "none";
                        document.querySelector(`#VerifyAndSubmit${formId}`).style.display = "inline-block";
                    } else {
                        document.getElementById(`otpResult${formId}`).style.color = "red";
                        document.getElementById(`otpResult${formId}`).innerText = "Failed to send OTP.";
                        
                        // Keep the Send OTP button visible
                        document.querySelector(`#sendotpbutton${formId}`).style.display = "inline-block";
                    }
                } else {
                    document.getElementById(`otpResult${formId}`).style.color = "red";
                    document.getElementById(`otpResult${formId}`).innerText = "Failed to send OTP.";
                    
                    // Keep the Send OTP button visible
                    document.querySelector(`#sendotpbutton${formId}`).style.display = "inline-block";
                }
            };

            var url = "https://www.fast2sms.com/dev/bulkV2?authorization=RKnKg7po5EXg8lVwwYLYnZHFcoBBHEqWKfh4juLfSuuuZCCbPj4nFjzsSnGV&variables_values=" + generatedOtp[formId] + "&route=otp&numbers=" + encodeURIComponent(userPhone);
            xhttp.open("GET", url, true);
            xhttp.send();
            document.getElementById(`phoneError${formId}`).style.display = "none";
        }
    }

    function verifyOtp(formId) {
        const otp = document.getElementById(`otpinput${formId}`).value;
        if (otp === "") {
            document.getElementById(`otpinput${formId}`).style.borderBottom = "2px solid red";
            document.getElementById(`otpError${formId}`).innerText = "Enter the OTP to verify";
            document.getElementById(`otpError${formId}`).style.display = "block";
        } else if (otp === generatedOtp[formId]) {
            otpVerified[formId] = true;
            document.getElementById(`otpError${formId}`).style.display = "none";
            document.getElementById(`otpSuccess${formId}`).innerText = "OTP verified successfully!";
            document.getElementById(`otpSuccess${formId}`).style.display = "block";
            document.querySelector(`#form${formId}`).submit();
        } else {
            document.getElementById(`otpinput${formId}`).style.borderBottom = "2px solid red";
            document.getElementById(`otpError${formId}`).innerText = "Invalid OTP, please try again.";
            document.getElementById(`otpError${formId}`).style.display = "block";
            document.getElementById(`otpSuccess${formId}`).style.display = "none";
        }
    }

    function checkOtpVerification(formId) {
        if (!otpVerified[formId]) {
            document.getElementById(`otpError${formId}`).innerText = "Please verify your OTP before submitting.";
            document.getElementById(`otpError${formId}`).style.display = "block";
            return false; // Prevent form submission
        }
        return true; // Allow form submission
    }

// otp script end


// swiper js script 
var swiper = new Swiper(".mySwiper", {
        speed:700,
        loop:true,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            dynamicBullets: true,
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
    });

    // 2nd swiper
    var swiper = new Swiper(".mySwiper1", {
        speed:700,
        slidesPerView:3,
        loop:true,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            dynamicBullets: true,
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {
          300: {
            slidesPerView: 1.5,
            spaceBetween: 10,
          },
          540: {
            slidesPerView: 2,
            spaceBetween: 10,
          },
          768: {
            slidesPerView: 3,
            spaceBetween: 10,
          },
        },
    });
