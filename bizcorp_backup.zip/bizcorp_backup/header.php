<?php
$current_page = basename($_SERVER['PHP_SELF']); 

$request_uri = $_SERVER['REQUEST_URI']; // e.g., "/" for root

// Define meta information for each page
if ($request_uri === '/' || $current_page === 'index.php') {
    $title = "Seamless Expansion for Indian Businesses in U.S. | BizCorpGlobal";
    $keywords = "Indian businesses USA expansion, U.S. market entry strategies, compliance support for Indian businesses, expand business USA, affordable business transition services, BizcorpGlobal U.S. expansion, Indian entrepreneurs USA, business setup in USA, U.S. compliance solutions, expert guidance for USA business setup";
    $description = "Expand your Indian business in the U.S. with BizcorpGlobal—tailored market entry, complete compliance support, fast, affordable services, and expert guidance
";
} else {
    switch ($current_page) {
        case 'about.php':
            $title = "About Us | Your Trusted Partner for U.S. Business Expansion";
            $description = "About Us | BizCorpGlobal - Trusted partner for Indian businesses expanding to the U.S. We offer tailored strategies, compliance support, and expert guidance.";
            $keywords = "About BizcorpGlobal, U.S. business expansion partner, Indian businesses U.S. solutions, expert compliance support USA, U.S. market entry strategies, tailored business solutions USA, BizcorpGlobal expertise, reliable U.S. expansion partner, seamless business transition USA, U.S. business growth solutions";
            break;
        case 'contact.php':
            $title = "Contact Us | BizCorpGlobal  Your U.S. Partner Business Expansion";
            $description = "Get in touch with BizCorpGlobal for expert guidance on expanding your Indian business in the U.S. Contact us today for tailored solutions and seamless support.";
            $keywords = "BizcorpGlobal contact, U.S. business expansion support, Indian businesses U.S. entry, expert guidance USA business, compliance support contact, tailored U.S. business solutions, contact BizcorpGlobal, affordable U.S. business services, expand business in USA, U.S. market entry consultation";
            break;
        case 'insights.php':
            $title = "Blog | News, Insights & Strategies for U.S. Business Expansion ";
            $description = "Discover our Blogs, expert insights, strategies, and tips on expanding your Indian business into the U.S. with BizCorpGlobal. Stay updated with our solutions.";
            $keywords = "BizcorpGlobal blog, U.S. business expansion strategies, Indian businesses USA insights, market entry tips, U.S. compliance advice, business growth in USA, expert U.S. business guidance, tailored expansion solutions, expand business in USA blog, U.S. market entry strategies blog.";
            break;
        case 'start_your_business.php':
            $title = "Start Your Business with Hassle-Free in the U.S. | BizCorpGlobal";
            $description = " Launch your new business in the U.S. with BizCorpGlobal. From LLCs to Non-Profits, quick paperwork, affordable services, and guaranteed satisfaction.";
            $keywords = "start a business in the U.S., hassle-free business setup USA, LLC formation USA, Non-Profit registration USA, affordable U.S. business setup, BizCorpGlobal business solutions, tailored U.S. market entry, U.S. corporation registration, business paperwork services USA, expert guidance USA startups";
            break;
        case 'existing_us_buisness.php':
            $title = "Effortless Compliance Management for Existing U.S. Business";
            $description = "BizCorpGlobal ensures U.S. business compliance with expert guidance,  Compliance portal, filing, deadline tracking, tax management, and document access.";
            $keywords = "U.S. business compliance management, BizCorpGlobal compliance portal, annual report filing USA, U.S. tax deadline management, business compliance support USA, free compliance portal, U.S. business tax filings, manage filings USA, expert compliance guidance, business document management USA";
            break;

        default:
            $title = "default";
            $keywords = "default";
            $description = "default";
            break;
    }
}
?>
<!doctype html>
 <html>
    <head>
        <!-- Meta Tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name='copyright' content=''>

		<!-- Title -->
		<title><?php echo $title; ?></title>
		<meta name="keywords" content="<?php echo $keywords; ?>">
		<meta name="description" content="<?php echo $description; ?>">
		<!-- Favicon -->
        <link rel="icon" href="./images/favicon.png">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Nice Select CSS -->
		<link rel="stylesheet" href="css/nice-select.css">
		<!-- Font Awesome CSS -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- icofont CSS -->
        <link rel="stylesheet" href="css/icofont.css">
		<!-- Slicknav -->
		<link rel="stylesheet" href="css/slicknav.min.css">
		<!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="css/owl-carousel.css">
		<!-- Datepicker CSS -->
		<link rel="stylesheet" href="css/datepicker.css">
		<!-- Animate CSS -->
        <link rel="stylesheet" href="css/animate.min.css">
		<!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css"/>
		<link href="vendor/swiper/swiper-bundle.min.css" rel="stylesheet" />
		<!--chatbot cdn-->
		<link rel="stylesheet" href="https://chatcdn.geteliv8.com/assets/widget.min.css">
    </head>
    <body>
		<!-- code for chat widget -->
		<script>
			const widget_id = "0193e206-d1c8-7f7e-baeb-f1db0db334d7"
		</script>
		
		<!-- end of chat widget code -->
		<!-- Preloader
		<div class="preloader">
			<div class="loader">
				<div class="loader-outter"></div>
				<div class="loader-inner"></div>

				<div class="indicator"> 
					<svg width="16px" height="12px">
						<polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
						<polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
					</svg>
				</div>
			</div>
		</div>
		< End Preloader -->

		<!-- Get Pro Button
		<ul class="pro-features">
			<a class="get-pro" href="#">Reach Us</a>
			<li class="big-title">Lorem ipsum dolor sit amet lorem </li>
			<li class="title">Get Premium Features</li>
			<li>Lorem ipsum dolor sit</li>
			<li>Lorem ipsum</li>
			<li>Lorem ipsum dolor sit amet</li>
			<li>Lorem ipsum dolor sit amet consectetur adipisicing</li>
			<div class="button">
				<a href="" target="_blank" class="btn">Know More</a>
			</div>
		</ul>
		End Get Pro Button -->

		<!-- Header Area -->
		<header class="header" >
			<!-- Header Inner -->
			<div class="header-inner">
				<div class="container">
					<div class="inner">
						<div class="row" style="align-items:center; justify-content:center;">

							<div class="col-lg-3 col-md-3 col-12">
								<!-- Start Logo -->
								<div class="logo">
									<a href="index"><img src="images/logo.webp" alt="#"></a>
								</div>
								<!-- End Logo -->
								<!-- Mobile Nav -->
								<div class="mobile-nav"></div>
								<!-- End Mobile Nav -->
							</div>

							<div class="col-lg-7 col-md-9 col-12">
								<!-- Main Menu -->
								<div class="main-menu">
									<nav class="navigation">
										<ul class="nav menu">
											<li class="active"><a href="index">Home</a></li>
											<li><a href="about">About US</a></li>
											<li><a href="#">Services <i class="icofont-rounded-down"></i></a>
												<ul class="dropdown">
													<li><a href="start_your_business">Start Your Business</a></li>
													<li><a href="existing_us_buisness">Existing U.S. Business </a></li>
												</ul>
											</li>
											<li><a href="insights">Blogs</a>
												<!--<ul class="dropdown">
													<li><a href="blog-single">Blog Details</a></li>
												</ul>-->
											</li>
											<li><a href="contact">Contact Us</a></li>
										</ul>
									</nav>
								</div>
								<!--/ End Main Menu -->
							</div>

							<div class="col-lg-2 col-12">
								<div class="get-quote">
									<a href="#." type="button" class="btn show-modal"  data-toggle="modal" data-target="#consultationModal">Get Free Consultation</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Header Inner -->
		</header>
		<!-- End Header Area -->