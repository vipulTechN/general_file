<?php
session_start();

// Check if the user is logged in and is a superadmin
if (!(isset($_SESSION['loggedin']) && isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] === true)) {
    header('Location: access_denied.html'); // Redirect to an access denied page or another page
    exit;
}

$servername = "localhost"; // Change this to your MySQL server name
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$dbname = "insentive_app"; // Change this to your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the ggdata table
$sql = "SELECT id, month, gen_revenue, recent_pay, remaning_amt, user_name, bookin_number, send_amt FROM tracking_table";
$result = $conn->query($sql);          
?>

<?php include('htmlopen.php'); ?>
<?php include('header.php'); ?>
<!-- Main Content -->
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="table-container">
          <table id="example" class="stripe row-border order-column display" cellspacing="0" style="width:100%">
            <thead>
              <tr>
                <th>ID</th>
                <th>Month</th>
                <th>Generated Revenue</th>
                <th>Recent Payment</th>
                <th>Remaining Amount</th>
                <th>Build Amount</th>
                <th>User Name</th>
                <th>Booking Number</th>
              </tr>
            </thead>
            <tbody id="trackings">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['month'] . "</td>";
                    echo "<td>₹ " . $row['gen_revenue'] . "</td>";
                    echo "<td>₹ " . $row['recent_pay'] . "</td>";
                    echo "<td>₹ " . $row['remaning_amt'] . "</td>";
                    echo "<td>₹ " . $row['send_amt'] . "</td>";
                    echo "<td>" . $row['user_name'] . "</td>";
                    echo "<td>" . $row['bookin_number'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No data found</td></tr>";
            }
            ?>
        </tbody>
            <tfoot>
              <tr>
                <th>ID</th>
                <th>Month</th>
                <th>Generated Revenue</th>
                <th>Recent Payment</th>
                <th>Remaining Amount</th>
                <th>Build Amount</th>
                <th>User Name</th>
                <th>Booking Number</th>
              </tr>
            </tfoot>
          </table>
          <button id="scroll-left"><i class='bx bx-left-arrow-alt'></i></button>
          <button id="scroll-right"><i class='bx bx-right-arrow-alt'></i></button>
        </div>
      </div>
    </div>
     <!-- Filter Rows Modal Start -->
     <div class="modal fade" tabindex="-1" id="filterModal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Filter Data</h5>
            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close" id="closeFilter"></button>
          </div>
          <div class="modal-body">
            <div class="container p-0">
              <div class="row">
                <!-- Filter inputs -->
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="filterID" placeholder="ID">
                  <input type="text" class="form-control mb-2" id="Month" placeholder="Month">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="RecentPay" placeholder="Recent Pay">
                  <input type="text" class="form-control mb-2" id="Remainingamt" placeholder="Remaining amount">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="Username" placeholder="User name">
                  <input type="text" class="form-control mb-2" id="Bookingno" placeholder="Booking number">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="Sentamount" placeholder="Sent amount">
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <!-- Close Modal button -->
            <button type="button" class="btn btn-secondary" data-dismiss="modal" id="cancleFilter">Close</button>
            <!-- Clear Filters button -->
            <button type="button" class="btn btn-danger" id="clearFiltersBtn">Clear Filters</button>
            <!-- Apply Filters button -->
            <button type="button" class="btn btn-primary" id="applyFiltersBtn">Apply Filters</button>
          </div>
        </div>
      </div>
    </div>
    <!-- filter rows Modal End -->
  </div>
</div>
<!--End Main Content -->
<script>
  function applyFilters() {
    var filterInputs = [{
        id: "filterID",
        columnIndex: 0
      },
      {
        id: "Month",
        columnIndex: 1
      },
      {
        id: "RecentPay",
        columnIndex: 2
      },
      {
        id: "Remainingamt",
        columnIndex: 3
      },
      {
        id: "Username",
        columnIndex: 4
      },
      {
        id: "Bookingno",
        columnIndex: 5
      },
      {
        id: "Sentamount",
        columnIndex: 6
      },
    ];
    activeFilters = [];
    $("#trackings tr").each(function() {
      var row = $(this);
      var showRow = true;
      filterInputs.forEach(function(inputInfo) {
        var input = $("#" + inputInfo.id);
        var filterValue = input.val().toLowerCase();
        var cellValue = row.find("td:eq(" + inputInfo.columnIndex + ")").text().toLowerCase();
        if (cellValue.indexOf(filterValue) === -1) {
          showRow = false;
          return false;
        }
        if (filterValue.trim() !== "") {
          activeFilters.push(filterValue);
        }
      });
      if (showRow) {
        row.addClass("custom-filtered-row");
      } else {
        row.removeClass("custom-filtered-row");
      }
    });

    $("#trackings tr").hide();
    applyCustomFilter();
  };
  applyCustomFilter();  

  function applyCustomFilter() {
    $(".custom-filtered-row").show();
  }
  $(".filterable .btn-filter1").click(function() {
    $("#filterModal").modal("show");
  });
  $("#applyFiltersBtn").click(function() {
    $("#filterModal").modal("hide");
    applyFilters();
  });
  $("#filterModal").on("hidden.bs.modal", function() {
    $(".filterable .filters input").val("");
    applyFilters();
  });
  $("#closeFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $("#cancleFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $(document).ready(function() {
    $("#clearFiltersBtn").click(function() {
      $("#filterID,#Month,#RecentPay,#Remainingamt,#Username,#Bookingno,#Sentamount").val("");
    });
  });
  $("#clearFiltersBtn").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
</script>
<?php include('htmlclose.php'); ?>
<?php
// Close the connection
$conn->close();
?>