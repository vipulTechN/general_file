function hiddenfield(){
    var hiddenblock = document.getElementById("hiddendatablock");
    var propertyTypeselect = document.getElementById("propertyType");

    propertyTypeselect.addEventListener("click",function(){
       hiddenblock.style.display="block";
    })
   };