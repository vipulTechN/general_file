function openForm() {
    document.querySelector(".careerform1").style.display = "block"
}

function closeForm() {
    document.querySelector(".careerform1").style.display = "none"
}

function greet() {
    document.querySelector(".careerform1").style.display = "block", document.querySelector(".careerform1").style.cursor = "pointer"
}
setInterval(greet, 6e4);
var images = document.querySelectorAll(".image-click"),
    modal = document.getElementById("myModal"),
    modalImg = document.getElementById("modalImg"),
    closeButton = document.querySelector(".close");

function showPricing(e) {
    let t = ["oneBHKDetails", "twoBHKDetails", "threeBHKDetails", "fourBHKDetails", "fiveBHKDetails"];
    t.forEach(e => {
        let t = document.getElementById(e);
        t && (t.style.display = "none")
    });
    let n = e - 1;
    if (n >= 0 && n < t.length) {
        let s = t[n],
            l = document.getElementById(s);
        l && (l.style.display = "flex")
    }
}

function showSwipess(e) {
    let t = ["Gallery", "MasterPlan", "TypicalPlan", "Location", "1bhkdetails", "2bhkdetails", "3bhkdetails", "4bhkdetails", "5bhkdetails", "villadetails"];
    t.forEach(e => {
        let t = document.getElementById(e);
        t && (t.style.display = "none")
    });
    let n = e - 1;
    if (n >= 0 && n < t.length) {
        let s = t[n],
            l = document.getElementById(s);
        l && (l.style.display = "block")
    }
}

function myFunction() {
    var e = document.getElementById("dots"),
        t = document.getElementById("more"),
        n = document.getElementById("myBtn");
    "none" === e.style.display ? (e.style.display = "inline", n.innerHTML = "Read more", t.style.display = "none") : (e.style.display = "none", n.innerHTML = "Read less", t.style.display = "inline")
}
images.forEach(function(e) {
    e.onclick = function() {
        modal.style.display = "block", modalImg.src = this.src
    }
}), closeButton.onclick = function() {
    modal.style.display = "none"
}, window.onclick = function(e) {
    e.target == modal && (modal.style.display = "none")
};
for (var buttonContainer = document.getElementById("hshighlight1"), neobutton = buttonContainer.getElementsByClassName("btns"), i = 0; i < neobutton.length; i++) neobutton[i].addEventListener("click", function() {
    var e = document.getElementsByClassName("hsactive");
    e[0].className = e[0].className.replace(" hsactive", ""), this.className += " hsactive"
});
for (var buttonContainer = document.getElementById("up1"), neobutton = buttonContainer.getElementsByClassName("btnsss1"), i = 0; i < neobutton.length; i++) neobutton[i].addEventListener("click", function() {
    var e = document.getElementsByClassName("neonn");
    e[0].className = e[0].className.replace(" neonn", ""), this.className += " neonn"
});

function initializeSwiper6(e, t, n) {
    return new Swiper(e, {
        slidesPerView: t,
        spaceBetween: n,
        lazy: !0,
        freemode: !0,
        pagination: {
            el: ".swiper-pagination",
            type: "fraction",
            clickable: !0
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        }
    })
}
$(document).ready(function() {
    $(window).scroll(function() {
        var e = $(window).scrollTop();
        e > 0 && ($(".shiform").css("top", "65px"), $(".shiform").css("position", "sticky")), e >= 1100 ? ($(".shiform").css("top", "115px"), $(".brand-logo").css("display", "flow"), $(".shiform").css("height", "auto")) : e >= 2500 ? $(".shiform").css("position", "sticky") : ($(".shiform").css("display", "flow"), $(".brand-logo").css("display", "flow"), $(".shiform").css("height", "auto"))
    })
}), $(document).ready(function() {
    $(window).scroll(function() {
        var e = $(window).scrollTop(),
            t = window.innerWidth,
            n = $(".propdethead");
        e >= 1e3 && t >= 1e3 && (n.css("position", "sticky"), n.css("width", "140%"), n.css("top", "65px")), e >= 750 && t <= 1e3 && (n.css("width", "100%"), n.css("position", "sticky"), n.css("top", "65px"), n.css("z-index", "39")), e <= 1060 && (n.css("position", "static"), n.css("width", "100%"))
    })
});
var swiper11 = initializeSwiper6(".mySwiper11", 1, 30);

function commonNav(e, t) {
    let n = document.getElementById(e);
    n.style.width = t, n.style.display = "0%" === t ? "none" : "block"
}

function initializeSwiper13(e, t, n) {
    return new Swiper(e, {
        slidesPerView: t,
        spaceBetween: n,
        lazy: !0,
        freemode: !0,
        pagination: {
            el: ".swiper-pagination",
            clickable: !0,
            dynamicBullets: !0
        },
        breakpoints: {
            768: {
                slidesPerView: 3
            },
            500: {
                slidesPerView: 2.5,
                spaceBetween: 15
            },
            250: {
                slidesPerView: 2
            }
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        }
    })
}
var swiper14 = initializeSwiper13(".mySwiper13", 3, 25),
    swiper15 = initializeSwiper13(".mySwiper14", 3, 25);

function shareOnWhatsApp() {
    var e = `https://wa.me/?text=${encodeURIComponent(window.location.href)}`;
    window.open(e, "_blank")
}

function shareOnTwitter() {
    var e = `https://twitter.com/intent/tweet?text=${encodeURIComponent("Check out this link:")}&url=${encodeURIComponent(window.location.href)}`;
    window.open(e, "_blank")
}