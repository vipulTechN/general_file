<?php include('htmlopen.php'); ?>
<?php include('header.php'); ?>
<!-- Main Content -->
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="table-container">
          <table id="example" class="stripe row-border order-column display" cellspacing="0" style="width:100%">
            <thead>
              <tr>
                <th>ID</th>
                <th>Date Of Joining</th>
                <th>Date Of Birth</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact No.</th>
                <th>Password</th>
                <th>In Hand Salary</th>
                <th>Designation</th>
                <th>Employee Id</th>
                <th>1st Amount</th>
                <th>2nd Amount</th>
                <th>3rd Amount</th>
                <th>4th Amount</th>
                <th>5th Amount</th>
                <th>6th Amount</th>
                <th>Project Name</th>
                <th>Project Type</th>
                <th>Code</th>
              </tr>
            </thead>
            <tbody id="incentiveuser">
              <tr>
                <td>1</td>
                <td>2022-01-15</td>
                <td>1990-05-20</td>
                <td>John Doe</td>
                <td>john.doe@email.com</td>
                <td>123-456-7890</td>
                <td>password1</td>
                <td>5000</td>
                <td>Employee</td>
                <td>E001</td>
                <td>1000</td>
                <td>1500</td>
                <td>2000</td>
                <td>2500</td>
                <td>3000</td>
                <td>3500</td>
                <td>Project X</td>
                <td>Development</td>
                <td>ABC</td>
              </tr>
              <tr>
                <td>2</td>
                <td>2021-11-30</td>
                <td>1985-08-12</td>
                <td>Jane Smith</td>
                <td>jane.smith@email.com</td>
                <td>987-654-3210</td>
                <td>secretword</td>
                <td>6000</td>
                <td>Employee</td>
                <td>E002</td>
                <td>1200</td>
                <td>1800</td>
                <td>2400</td>
                <td>3000</td>
                <td>3600</td>
                <td>4200</td>
                <td>Project Y</td>
                <td>Design</td>
                <td>DEF</td>
              </tr>
              <tr>
                <td>3</td>
                <td>2023-03-25</td>
                <td>1995-02-28</td>
                <td>Alex Johnson</td>
                <td>alex.johnson@email.com</td>
                <td>111-222-3333</td>
                <td>p@ssw0rd</td>
                <td>5500</td>
                <td>Employee</td>
                <td>E003</td>
                <td>1100</td>
                <td>1650</td>
                <td>2200</td>
                <td>2750</td>
                <td>3300</td>
                <td>3850</td>
                <td>Project Z</td>
                <td>Marketing</td>
                <td>GHI</td>
              </tr>
              <tr>
                <td>4</td>
                <td>2020-09-12</td>
                <td>1980-11-15</td>
                <td>Emily Davis</td>
                <td>emily.davis@email.com</td>
                <td>444-555-6666</td>
                <td>securepass</td>
                <td>7000</td>
                <td>Employee</td>
                <td>E004</td>
                <td>1400</td>
                <td>2100</td>
                <td>2800</td>
                <td>3500</td>
                <td>4200</td>
                <td>4900</td>
                <td>Project A</td>
                <td>Research</td>
                <td>JKL</td>
              </tr>
              <tr>
                <td>5</td>
                <td>2022-05-08</td>
                <td>1992-04-03</td>
                <td>Michael Brown</td>
                <td>michael.brown@email.com</td>
                <td>777-888-9999</td>
                <td>12345678</td>
                <td>4800</td>
                <td>Employee</td>
                <td>E005</td>
                <td>960</td>
                <td>1440</td>
                <td>1920</td>
                <td>2400</td>
                <td>2880</td>
                <td>3360</td>
                <td>Project B</td>
                <td>Sales</td>
                <td>MNO</td>
              </tr>
              <tr>
                <td>6</td>
                <td>2021-12-19</td>
                <td>1989-07-22</td>
                <td>Sarah Wilson</td>
                <td>sarah.wilson@email.com</td>
                <td>666-777-8888</td>
                <td>letmein123</td>
                <td>5100</td>
                <td>Employee</td>
                <td>E006</td>
                <td>1020</td>
                <td>1530</td>
                <td>2040</td>
                <td>2550</td>
                <td>3060</td>
                <td>3570</td>
                <td>Project C</td>
                <td>Support</td>
                <td>PQR</td>
              </tr>
              <tr>
                <td>7</td>
                <td>2023-02-14</td>
                <td>1996-10-18</td>
                <td>Kevin Lee</td>
                <td>kevin.lee@email.com</td>
                <td>333-444-5555</td>
                <td>changeme</td>
                <td>5300</td>
                <td>Employee</td>
                <td>E007</td>
                <td>1060</td>
                <td>1590</td>
                <td>2120</td>
                <td>2650</td>
                <td>3180</td>
                <td>3710</td>
                <td>Project D</td>
                <td>Training</td>
                <td>STU</td>
              </tr>
              <tr>
                <td>8</td>
                <td>2020-08-03</td>
                <td>1983-12-25</td>
                <td>Olivia Garcia</td>
                <td>olivia.garcia@email.com</td>
                <td>999-888-7777</td>
                <td>mypassword</td>
                <td>6200</td>
                <td>Employee</td>
                <td>E008</td>
                <td>1240</td>
                <td>1860</td>
                <td>2480</td>
                <td>3100</td>
                <td>3720</td>
                <td>4340</td>
                <td>Project E</td>
                <td>Consulting</td>
                <td>VWX</td>
              </tr>
              <tr>
                <td>9</td>
                <td>2022-03-10</td>
                <td>1991-06-30</td>
                <td>Daniel Rodriguez</td>
                <td>daniel.rodriguez@email.com</td>
                <td>222-333-4444</td>
                <td>dani123</td>
                <td>5800</td>
                <td>Employee</td>
                <td>E009</td>
                <td>1160</td>
                <td>1740</td>
                <td>2320</td>
                <td>2900</td>
                <td>3480</td>
                <td>4060</td>
                <td>Project F</td>
                <td>Management</td>
                <td>YZA</td>
              </tr>
              <tr>
                <td>10</td>
                <td>2021-10-05</td>
                <td>1987-09-08</td>
                <td>Sophia Martinez</td>
                <td>sophia.martinez@email.com</td>
                <td>555-666-7777</td>
                <td>password123</td>
                <td>4900</td>
                <td>Employee</td>
                <td>E010</td>
                <td>980</td>
                <td>1470</td>
                <td>1960</td>
                <td>2450</td>
                <td>2940</td>
                <td>3430</td>
                <td>Project G</td>
                <td>Analysis</td>
                <td>BCD</td>
              </tr>
            </tbody>
            <tfoot>
              <td>ID</td>
              <td>Date Of Joining</td>
              <td>Date Of Birth</td>
              <td>Name</td>
              <td>Email</td>
              <td>Contact No.</td>
              <td>Password</td>
              <td>In Hand Salary</td>
              <td>Designation</td>
              <td>Employee Id</td>
              <td>1st Amount</td>
              <td>2nd Amount</td>
              <td>3rd Amount</td>
              <td>4th Amount</td>
              <td>5th Amount</td>
              <td>6th Amount</td>
              <td>Project Name</td>
              <td>Project Type</td>
              <td>Code</td>
            </tfoot>
          </table>
          <button id="scroll-left"><i class='bx bx-left-arrow-alt'></i></button>
          <button id="scroll-right"><i class='bx bx-right-arrow-alt'></i></button>
        </div>
      </div>
    </div>
    <!-- Filter Rows Modal Start -->
    <div class="modal fade" tabindex="-1" id="filterModal">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Filter Data</h5>
              <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close" id="closeFilter"></button>
            </div>
            <div class="modal-body">
              <div class="container p-0">
                <div class="row">
                  <!-- Filter inputs -->
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="filterID" placeholder="ID">
                    <input type="text" class="form-control mb-2" id="EmployeeId" placeholder="Employee Id">
                  </div>
                  <div class="col-md-6">
                  <input type="text" class="form-control mb-2" id="DateOfJoining" placeholder="Date Of Joining">
                    <input type="text" class="form-control mb-2" id="DateOfBirth" placeholder="Date Of Birth">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="username" placeholder="User name">
                    <input type="text" class="form-control mb-2" id="email" placeholder="Email Id">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="Contactnumber" placeholder="Contact No.">
                    <input type="text" class="form-control mb-2" id="Password" placeholder="Password">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="inhandsalary" placeholder="In hand salary">
                    <input type="text" class="form-control mb-2" id="designation" placeholder="Designation">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="firstamount" placeholder="1st amount">
                    <input type="text" class="form-control mb-2" id="scndamount" placeholder="2nd amount">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="thirdamount" placeholder="3rd amount">
                    <input type="text" class="form-control mb-2" id="fourthamount" placeholder="4th amount">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="fifthamount" placeholder="5th amount">
                    <input type="text" class="form-control mb-2" id="sixthamount" placeholder="6th amount">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="Projectname" placeholder="Project Name">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="Projecttype" placeholder="Project Type">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control mb-2" id="Code" placeholder="Code">
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <!-- Close Modal button -->
              <button type="button" class="btn btn-secondary" data-dismiss="modal" id="cancleFilter">Close</button>
              <!-- Clear Filters button -->
              <button type="button" class="btn btn-danger" id="clearFiltersBtn">Clear Filters</button>
              <!-- Apply Filters button -->
              <button type="button" class="btn btn-primary" id="applyFiltersBtn">Apply Filters</button>
            </div>
          </div>
        </div>
      </div>
      <!-- filter rows Modal End -->
  </div>
</div>
<!--End Main Content -->
<script>
  function applyFilters() {
    var filterInputs = [{
        id: "filterID",
        columnIndex: 0
      },
      {
        id: "EmployeeId",
        columnIndex: 1
      },
      {
        id: "DateOfJoining",
        columnIndex: 2
      },
      {
        id: "DateOfBirth",
        columnIndex: 3
      },
      {
        id: "username",
        columnIndex: 4
      },
      {
        id: "email",
        columnIndex: 5
      },
      {
        id: "Contactnumber",
        columnIndex: 6
      },
      {
        id: "Password",
        columnIndex: 7
      },
      {
        id: "inhandsalary",
        columnIndex: 8
      },
      {
        id: "designation",
        columnIndex: 9
      },
      {
        id: "firstamount",
        columnIndex: 10
      },
      {
        id: "scndamount",
        columnIndex: 11
      },
      {
        id: "thirdamount",
        columnIndex: 12
      },
      {
        id: "fourthamount",
        columnIndex: 13
      },
      {
        id: "fifthamount",
        columnIndex: 14
      },
      {
        id: "sixthamount",
        columnIndex: 15
      },
      {
        id: "Projectname",
        columnIndex: 16
      },
      {
        id: "Projecttype",
        columnIndex: 17
      },
      {
        id: "Code",
        columnIndex: 18
      },
    ];
    activeFilters = [];
    $("#incentiveuser tr").each(function() {
      var row = $(this);
      var showRow = true;
      filterInputs.forEach(function(inputInfo) {
        var input = $("#" + inputInfo.id);
        var filterValue = input.val().toLowerCase();
        var cellValue = row.find("td:eq(" + inputInfo.columnIndex + ")").text().toLowerCase();
        if (cellValue.indexOf(filterValue) === -1) {
          showRow = false;
          return false;
        }
        if (filterValue.trim() !== "") {
          activeFilters.push(filterValue);
        }
      });
      if (showRow) {
        row.addClass("custom-filtered-row");
      } else {
        row.removeClass("custom-filtered-row");
      }
    });
    $("#incentiveuser tr").hide();
    applyCustomFilter();
  }
  applyCustomFilter();

  function applyCustomFilter() {
    $(".custom-filtered-row").show();
  }
  $(".filterable .btn-filter1").click(function() {
    $("#filterModal").modal("show");
  });
  $("#applyFiltersBtn").click(function() {
    $("#filterModal").modal("hide");
    applyFilters();
  });
  $("#filterModal").on("hidden.bs.modal", function() {
    $(".filterable .filters input").val("");
    applyFilters();
  });
  $("#closeFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $("#cancleFilter").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
  $(document).ready(function() {
    $("#clearFiltersBtn").click(function() {
      $("#filterID, #EmployeeId, #DateOfJoining, #DateOfBirth, #username, #email, #Contactnumber, #Password, #inhandsalary, #designation, #firstamount, #scndamount, #thirdamount, #fourthamount, #fifthamount, #sixthamount, #Projectname, #Projecttype, #Code").val("");
    });
  });
  $("#clearFiltersBtn").click(function() {
    applyFilters();
    $("#filterModal").modal("hide");
  });
</script>
<?php include('htmlclose.php'); ?>