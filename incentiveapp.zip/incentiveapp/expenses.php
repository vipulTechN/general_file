<?php include('htmlopen.php'); ?>
  <?php include('header.php'); ?>
    <!-- Main Content -->
    <div class="content">
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Facebook Exp.</th>
                <th>Google Exp.</th>
                <th>Hr Exp.</th>
                <th>Accountant Exp.</th>
                <th>IT Exp.</th>
                <th>Total Exp.</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>1</td>
                <td>130000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>7600000</td>
            </tr>
            <tr>
               <td>2</td>
                <td>150000</td>
                <td>6500000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200460</td>
            </tr>
            <tr>
                 <td>3</td>
                <td>1530</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>32876000</td>
            </tr>
            <tr>
                 <td>4</td>
                <td>150000</td>
                <td>3009800</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3202300</td>
            </tr>
            <tr>
            <td>5</td>
                <td>150000</td>
                <td>30065400</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>320340</td>
            </tr>
            <td>6</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
            </tr>
            <tr>
            <td>7</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
            </tr>
            <tr>
            <td>8</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
            </tr>
            <tr>
            <td>9</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
            </tr>
            <tr>
            <td>10</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
            </tr>
            <tr>
            <td>11</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
            </tr>
            <tr>
            <td>12</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
            <tr>
            <td>13</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
            </tr>
            <tr>
            <td>14</td>
                <td>150000</td>
                <td>3000000</td>
                <td>10000</td>
                <td>21000</td>
                <td>1000</td>
                <td>3200000</td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
            <th>ID</th>
                <th>Facebook Exp.</th>
                <th>Google Exp.</th>
                <th>Hr Exp.</th>
                <th>Accountant Exp.</th>
                <th>IT Exp.</th>
                <th>Total Exp.</th>

            </tr>
        </tfoot>
    </table>
    </div>
<?php include('htmlclose.php'); ?>