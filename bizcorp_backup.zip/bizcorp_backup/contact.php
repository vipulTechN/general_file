<?php include 'header.php';?>
	
		<!-- Breadcrumbs -->
		<div class="breadcrumbs overlay contactus">
			<div class="container">
				<div class="bread-inner">
					<div class="row">
						<div class="col-12">
							<h2>Contact Us</h2>
							<ul class="bread-list">
								<li><a href="index.php">Home</a></li>
								<li><i class="icofont-simple-right"></i></li>
								<li class="active">Contact Us</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Breadcrumbs -->
				
		<!-- Start Contact Us -->
		<section class="contact-us section">
			<div class="container">
				<div class="inner">
					<div class="row"> 
						<div class="col-lg-12 mt-1 mb-3 p-4">
							<div class="single-content">
								<h4 class="mt-3 mb-3">Contact Us</h4>
								<p class="text-justify">
Ready to expand your business to the USA? We're here to make it seamless and stress-free. Whether you need guidance on compliance, tailored market entry strategies, or expert assistance, BizcorpGlobal is your trusted partner.								</p>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="contact-us-left">
								<div id="myMap"><img class="icofont-home" src="./images/contact.jpg"> </img></div>
							</div>
						</div>
						<style>
						.contact-us .contact-us-form{
							padding:0px;
						}
						</style>
						<div class="col-lg-6">
							<div class="contact-us-form">
								<!--<h2>Get in Touch with Us</h2>
								<p>If you have any questions please fell free to contact with us.</p>-->
								<!-- Form 
								<form class="form" method="post" action="mail.php">
									<div class="row">
										<div class="col-lg-12">
											<div class="form-group">
												<input type="text" name="name" placeholder="Name" required="">
											</div>
										</div>
										<div class="col-lg-12">
											<div class="form-group">
												<input type="email" name="email" placeholder="Email" required="">
											</div>
										</div>
										<div class="col-lg-12">
											<div class="form-group">
												<input type="number" name="phone" placeholder="Phone" required="">
											</div>
										</div>
										<div class="col-lg-12">
											<div class="form-group">
												<textarea name="message" placeholder="Your Message" required=""></textarea>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group login-btn">
												<button class="btn" type="submit">Send</button>
											</div>
										</div>
									</div>
								</form> End Form -->
								<iframe
									src="https://api.geteliv8.com/widget/form/20tk4fpO9cT7etMUbfrv"
									style="width:100%;height:100%;border:none;border-radius:4px"
									id="inline-20tk4fpO9cT7etMUbfrv" 
									data-layout="{'id':'INLINE'}"
									data-trigger-type="alwaysShow"
									data-trigger-value=""
									data-activation-type="alwaysActivated"
									data-activation-value=""
									data-deactivation-type="neverDeactivate"
									data-deactivation-value=""
									data-form-name="Contact Us"
									data-height="530"
									data-layout-iframe-id="inline-20tk4fpO9cT7etMUbfrv"
									data-form-id="20tk4fpO9cT7etMUbfrv"
									title="Contact Us"
									>
								</iframe>

							</div>
						</div>
						<div class="col-lg-12 mt-5 mb-5 text-center">
							<div class="single-content">
								<h4>
									Your success is our priority—let’s build your business together!
								</h4>
							</div>
						</div>
					</div>
				</div>
				<div class="contact-info">
					<div class="row">
						<!-- single-info -->
						<div class="col-lg-4 col-12 ">
							<div class="single-info">
								<i class="icofont icofont-ui-call"></i>
								<div class="content">
									<h3>+91 9840777207 </h3>
									<p>Info@bizcorpglobal.com</p>
								</div>
							</div>
						</div>
						<!--/End single-info -->
						<!-- single-info -->
						<div class="col-lg-4 col-12 ">
							<div class="single-info">
								<i class="icofont-google-map"></i>
								<div class="content">
									<p style="margin-top:-15px"> 4th Floor, No 280, 5th Main Rd, 6th Sector, HSR Layout, Bengaluru, Karnataka 560102</p>
								</div>
							</div>
						</div>
						<!--/End single-info -->
						<!-- single-info -->
						<div class="col-lg-4 col-12 ">
							<div class="single-info">
								<i class="icofont icofont-wall-clock"></i>
								<div class="content">
									<h3>Mon - Sat : <br>09 AM - 06 PM</h3>
									<p>Sunday OFF</p>
								</div>
							</div>
						</div>
						<!--/End single-info -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Contact Us -->
		<script src="https://api.geteliv8.com/js/form_embed.js"></script>
		<?php include 'footer.php';?>