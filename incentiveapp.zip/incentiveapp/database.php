<?php include('htmlopen.php'); ?>

  <?php include('header.php'); ?>

    <!-- Main Content -->
    <div class="content">
            <div class="panel-body">
              <table id="example" class="display" style="width:100%">
                <thead class="maintheading">
                  <tr class="filters">
                    <th>ID</th>
                    <th>Booking Date</th>
                    <th>Month</th>
                    <th>Builder</th>
                    <th>Project</th>
                    <th>Customer Name.</th>
                    <th>Contact No.</th>
                    <th>Email Id</th>
                    <th>Type</th>
                    <th>Unit No.</th>
                    <th>Size</th>
                    <th>Agreement Value</th>
                    <th>Commission %</th>
                    <th>Total Revenue</th>
                    <th>CashBack %</th>
                    <th>Actual Revenue</th>
                    <th>Status</th>
                    <th>Received Amt.</th>
                    <th>Sales Person</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <thead class="scndhead">
                  <tr class="group-header">
                    <td colspan="20">
                      <div class="wrappsps d-flex justify-content-start">
                        <div class="border border-dark d-inline p-2 bg-warning text-dark font-weight-bold">Financial
                          Year/Bookings: 2023-2024/(15)</div>
                        <div class="border border-dark d-inline p-2 bg-primary text-white font-weight-bold">Total
                          Revenue: ₹ 35406666</div>
                        <div class="border border-dark d-inline p-2 bg-info text-white font-weight-bold">Actual Revenue:
                          ₹ 28292188</div>
                        <div class="border border-dark d-inline p-2 bg-primary text-white font-weight-bold">Remaning
                          Revenue: ₹ 0</div>
                        <div class="border border-dark d-inline p-2 bg-success text-white font-weight-bold">Recived
                          Amount: ₹ 28292188</div>
                        <div class="border border-dark d-inline p-2 bg-secondary text-white font-weight-bold">Amount To
                          be Pay: ₹ 2107215</div>
                        <div class="border border-dark d-inline p-2 bg-info text-white font-weight-bold">Total Paid Amt:
                          ₹ 2107213</div>
                      </div>
                    </td>
                  </tr>
                </thead>
                
                <tbody id="pagedata">
                
                  <tr data-status="Received">
                    <td>1</td>
                    <td>2024-03-09</td>
                    <td>March</td>
                    <td>ABC Builders</td>
                    <td>Project XYZ</td>
                    <td>John Doe</td>
                    <td>1234567890</td>
                    <td>john.doe@example.com</td>
                    <td>Residential</td>
                    <td>101</td>
                    <td>1200 sqft</td>
                    <td>$200,000</td>
                    <td>5%</td>
                    <td>$10,000</td>
                    <td>2%</td>
                    <td>$9,800</td>
                    <td>
                      <p class="status delivered">Processed</p>
                    </td>
                    <td>$5,000</td>
                    <td>Jane Doe</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli" data-toggle="modal" data-target="#editUserModal">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                          <!-- Edit User Modal Start -->
                          <div class="modal fade" tabindex="-1" id="editUserModal">
                            <div class="modal-dialog modal-dialog-centered">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title">Edit This Booking</h5>
                                  <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                  <form id="edit-user-form" name="myform" class="p-2" novalidate>
                                    <input type="hidden" name="id" id="id">
                                    <div class="row mb-3 gx-3">
                                      <div class="col-6">
                                        <input type="date" name="bdate" id="bdate" class="form-control form-control-lg" required>
                                        <div class="invalid-feedback">Date is required!</div>
                                      </div>

                                      <div class="col-6">
                                        <input type="month" name="bmonth" id="bmonth" class="form-control form-control-lg" placeholder="Enter Last Name" required>
                                        <div class="invalid-feedback">Month is required!</div>
                                      </div>
                                    </div>

                                    <div class="row mb-3 gx-3">
                                      <div class="col-6">
                                      <input type="text" name="developer" id="developer" class="form-control form-control-lg" placeholder="Enter Builder Name" required>
                                        <div class="invalid-feedback">Builder name is required!</div>
                                      </div>

                                      <div class="col-6">
                                        <input type="text" name="bproject" id="bproject" class="form-control form-control-lg" placeholder="Enter Project Name" required>
                                        <div class="invalid-feedback">Project name is required!</div>
                                      </div>
                                    </div>

                                    <div class="row mb-3 gx-3">
                                      <div class="col-6">
                                      <input type="username" name="cname" id="cname" class="form-control form-control-lg" placeholder="Enter Customer Name" required>
                                        <div class="invalid-feedback">Customer name is required!</div>
                                      </div>

                                      <div class="col-6">
                                        <input type="number" name="cnumber" id="cnumber" class="form-control form-control-lg" placeholder="Enter Contact Number" required>
                                        <div class="invalid-feedback">Contact Number is required!</div>
                                      </div>
                                    </div>

                                    <div class="col-11 mb-3 mx-auto">
                                      <input type="email" name="cemail" id="cemail" class="form-control form-control-lg" placeholder="Enter E-mail" required>
                                      <div class="invalid-feedback">E-mail is required!</div>
                                    </div>

                                    <div class="row mb-3 gx-3">
                                      <div class="col-6">
                                      <input type="text" name="tproject" id="tproject" class="form-control form-control-lg" placeholder="Enter Project Type" required>
                                        <div class="invalid-feedback">Project Type is required!</div>
                                      </div>

                                      <div class="col-6">
                                        <input type="text" name="unitno" id="unitno" class="form-control form-control-lg" placeholder="Enter Unit Number" required>
                                        <div class="invalid-feedback">Unit Number is required!</div>
                                      </div>
                                    </div>

                                    <div class="row mb-3 gx-3">
                                      <div class="col-6">
                                      <input type="number" name="psize" id="psize" class="form-control form-control-lg" placeholder="Enter Project Size" required>
                                        <div class="invalid-feedback">Project Size is required!</div>
                                      </div>

                                      <div class="col-6">
                                        <input type="number" name="cagreement" id="cagreement" class="form-control form-control-lg" placeholder="Enter Agreement Value" required>
                                        <div class="invalid-feedback">Agreement Value is required!</div>
                                      </div>
                                    </div>

                                    <div class="row mb-3 gx-3">
                                      <div class="col-6">
                                      <input type="text" name="ccashback" id="ccashback" class="form-control form-control-lg" placeholder="Enter Commission %" onkeyup="updateCalculate(this.value)" required>
                                        <div class="invalid-feedback">Commission % is required!</div>
                                      </div>

                                      <div class="col-6">
                                        <input type="number" name="crevenue" id="crevenue" class="form-control form-control-lg" placeholder="Total Revenue Amount" required>
                                        <div class="invalid-feedback">Total Revenue Amount is required!</div>
                                      </div>
                                    </div>

                                    <div class="row mb-3 gx-3">
                                      <div class="col-6">
                                      <input type="text" name="cccashback" id="cccashback" class="form-control form-control-lg" placeholder="Enter CashBack %" onkeyup="updateCalculate(this.value)" required>
                                        <div class="invalid-feedback">CashBack % is required!</div>
                                      </div>

                                      <div class="col-6">
                                        <input type="number" name="ccrevenue" id="ccrevenue" class="form-control form-control-lg" placeholder="Actual Revenue Amount" required>
                                        <div class="invalid-feedback">Actual Revenue Amount is required!</div>
                                      </div>
                                    </div>

                                    <div class="mb-3">
                                    <input type="checkbox" class="btn-check Processing" name="cstatus" id="btn-check-3-outlined" value="Processing" required>
                                    <label class="btn btn-outline-primary" for="btn-check-3-outlined">Processing</label><br><br>

                                    <input type="radio" class="btn-check Received" name="cstatus" id="2success-outlined" value="Received" required>
                                    <label class="btn btn-outline-success" for="2success-outlined">Received</label>

                                    <input type="radio" class="btn-check Cancled" name="cstatus" id="2danger-outlined" value="Cancled" required>
                                    <label class="btn btn-outline-danger" for="2danger-outlined">Cancled</label>
                                      <div class="invalid-feedback">Please Select the staus of booking!</div>
                                    </div>

                                    <div class="mb-3">
                                      <input type="number" name="brecived" id="brecived" class="form-control form-control-lg disable" placeholder="Enter Received Amt." readonly>
                                      <div class="invalid-feedback">Received Amt. is required!</div>
                                    </div>

                                    <div class="mb-3">
                                      <input type="submit" value="Update Booking" class="btn btn-success btn-block btn-lg" id="edit-user-btn" onclick="validateForm()">
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                          </div>
                          <!-- Edit User Modal End -->
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>2</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>
                      <p class="status cancelled">Cancelled</p>
                    </td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>3</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>poiu Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>4</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>qwe Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>5</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>asd Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>6</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>lkjh Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>7</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>cv Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>8</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>9</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>10</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>11</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>12</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>13</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>14</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>dfgh Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>15</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>mn Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>16</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>qas Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>17</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jacxvne Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>18</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>JZxcane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>19</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jafdsne Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>20</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>bnb Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>21</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>vbv Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>22</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>vcbane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>23</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>bgtJane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>24</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>eeJane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>25</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>ccJane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>26</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>ssJane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>27</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jxcane Smith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>28</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane cSmith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>29</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane Smfgith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                  <tr data-status="Received">
                    <td>30</td>
                    <td>2024-03-10</td>
                    <td>April</td>
                    <td>XYZ Developers</td>
                    <td>Project ABC</td>
                    <td>Jane fmith</td>
                    <td>9876543210</td>
                    <td>jane.smith@example.com</td>
                    <td>Commercial</td>
                    <td>202</td>
                    <td>1500 sqft</td>
                    <td>$300,000</td>
                    <td>7%</td>
                    <td>$21,000</td>
                    <td>3%</td>
                    <td>$20,400</td>
                    <td>Inactive</td>
                    <td>$15,000</td>
                    <td>John smith</td>
                    <td>
                      <ul class="tableul">
                        <li class="tableli">
                          <i class="bi bi-cloud-arrow-down-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-trash-fill"></i>
                        </li>
                        <li class="tableli">
                          <i class="bi bi-clipboard-check-fill"></i>
                        </li>
                      </ul>
                    </td>
                  </tr>
                </tbody>

                <tfoot>
                  <th>ID</th>
                  <th>Booking Date</th>
                  <th>Month</th>
                  <th>Builder</th>
                  <th>Project</th>
                  <th>Customer Name.</th>
                  <th>Contact No.</th>
                  <th>Email Id</th>
                  <th>Type</th>
                  <th>Unit No.</th>
                  <th>Size</th>
                  <th>Agreement Value</th>
                  <th>Commission %</th>
                  <th>Total Revenue</th>
                  <th>CashBack %</th>
                  <th>Actual Revenue</th>
                  <th>Status</th>
                  <th>Received Amt.</th>
                  <th>Sales Person</th>
                </tfoot>
              </table>
            </div>
    </div>
    <!--End Main Content -->
    <?php include('htmlclose.php'); ?>
